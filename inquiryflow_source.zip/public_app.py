"""Shareable interview demo. No local history or server API credentials."""
from __future__ import annotations
import html
import json
import tempfile
from datetime import datetime
from zoneinfo import ZoneInfo
import streamlit as st
from inquiryflow.public_demo import PublicWorkspace, load_samples, SAMPLE_DIR
from inquiryflow.public_ui import theme_css, reply_html, case_state, case_heading_html, facts_html, extraction_rows, decision_html, overview_html, sample_edit_label
from inquiryflow.review import current_revision, ReviewError
from inquiryflow.presentation import internal_notes_html, email_text_html
from inquiryflow.ui_i18n import followup_title
from inquiryflow.retrieval import load_knowledge
from inquiryflow.knowledge_i18n import translated_document

st.set_page_config(page_title='InquiryFlow | 海外営業の問い合わせ対応', page_icon='✉️', layout='wide',initial_sidebar_state='collapsed')

def move(page):
    st.session_state['public_nav'] = page

def reset():
    old = st.session_state.pop('public_temp', None)
    if old:
        old.cleanup()
    for key in list(st.session_state):
        if key.startswith(('case_', 'edit_', 'input_', 'sample_', 'selected_', 'public_key', 'active_case_', 'record_case_', 'pending_')):
            del st.session_state[key]
    st.session_state['public_nav'] = '問い合わせ対応'

if 'public_temp' not in st.session_state:
    st.session_state.public_temp = tempfile.TemporaryDirectory(prefix='inquiryflow-public-')
workspace = PublicWorkspace(st.session_state.public_temp.name)
samples = load_samples()
# Keep the active record separate from widget-owned selection state.
if 'active_case_id' not in st.session_state and st.session_state.get('selected_case'):
    st.session_state.active_case_id=st.session_state.selected_case

def toggle_theme():
    st.session_state.ui_dark_mode=not st.session_state.get('ui_dark_mode',False)

if 'ui_dark_mode' not in st.session_state:
    st.session_state.ui_dark_mode=bool(st.session_state.get('public_dark',False))
dark=st.session_state.ui_dark_mode
st.markdown(theme_css(dark),unsafe_allow_html=True)
with st.container(key='public_theme_control'):
    st.button('☀' if dark else '☾',help='ライトモードに切り替え' if dark else 'ダークモードに切り替え',on_click=toggle_theme)
with st.container(key='public_settings'):
    with st.popover('⚙',help='設定・APIキー'):
        st.subheader('設定')
        st.write('合成データによる公開デモです。メール送信・外部CRMへの登録は行いません。')
        st.button('この接続のデータをリセット',on_click=reset,width='stretch')
        st.caption('操作記録は接続ごとの一時保存です。再接続や再起動で消える場合があります。')
        with st.expander('APIキーとモデル（任意）'):
            st.write('APIを使う場合、入力した原文をOpenAIへ送信します。実在する顧客情報は入力しないでください。')
            st.text_input('OpenAI APIキー',type='password',key='public_key')
            st.text_input('モデルID',value='gpt-6.1-sol',key='public_model')
            st.caption('保存済みの例はキー不要。キーはこの接続内のみで使用し、保存・ダウンロードには含めません。')

st.markdown('<div class="hero"><small>AI OPERATIONS WORKSPACE</small><h1>InquiryFlow</h1><p>海外からの問い合わせを整理し、返信の確認から案件登録・フォローまで。</p></div>', unsafe_allow_html=True)
pages = ['問い合わせ対応','案件・対応履歴','ナレッジ・ルール','検証と改善']
if 'pending_page' in st.session_state:
    st.session_state.public_nav = st.session_state.pop('pending_page')
page = st.radio('ワークスペース', pages, key='public_nav', horizontal=True, label_visibility='collapsed')

def summary(case):
    with st.expander('社内向けメモ・確認事項'):
        st.markdown(internal_notes_html(current_revision(case)['summary_ja']), unsafe_allow_html=True)

def extracted_fields(case):
    rows=extraction_rows(case['extraction'])
    with st.container(border=True,key='request_panel'):
        st.subheader('読み取った依頼内容')
        intent={'Sales':'購入・見積もり','Support':'破損・アフターサービス','FAQ':'一般的なお問い合わせ','Other':'その他'}.get(case['extraction'].get('intent'),'確認が必要')
        st.markdown('<span class="chip">'+intent+'</span>',unsafe_allow_html=True)
        compact=[(r['項目'],r['読み取った内容'] if len(r['読み取った内容'])<100 else '複数の条件あり — 原文との照合で確認') for r in rows]
        st.markdown(facts_html(compact),unsafe_allow_html=True)
        with st.expander('原文と抽出結果を照合する'):
            st.table(rows)
            st.caption('AIが読み取った値と原文の引用です。人が正しさを確認するための表示であり、自動採点結果ではありません。')

def source_for_case(case):
    source=case.get('source_run_id','')
    if source.startswith('public-sample:'):
        return next((s['analysis'] for s in samples if 'public-sample:'+s['id']==source),{})
    runs=workspace.root/'runs'
    if runs.exists():
        for path in runs.glob('*.json'):
            run=json.loads(path.read_text())
            if run.get('workflow_id')==source and run.get('output') and run.get('retrieval'):
                return run
    return {}

def source_draft_for_case(case):
    source=case.get('source_run_id','')
    if source.startswith('public-sample:'):
        return next((s['draft']['output'] for s in samples if 'public-sample:'+s['id']==source),{})
    analysis=source_for_case(case)
    runs=workspace.root/'runs'
    if runs.exists() and analysis.get('run_id'):
        for path in runs.glob('*.json'):
            run=json.loads(path.read_text())
            if run.get('mode')=='live_api_draft' and run.get('source_analysis_run_id')==analysis['run_id']:
                return run.get('output') or {}
    return {}

def decision_and_sources(case):
    d=case.get('decision_snapshot',{})
    with st.container(border=True,key='decision_panel'):
        st.markdown(decision_html(d,source_draft_for_case(case).get('clarifying_questions')),unsafe_allow_html=True)
        analysis=source_for_case(case)
        hits=analysis.get('retrieval',{}).get('hits',[])
        if hits:
            st.markdown('<div class="section-eyebrow">参照した社内資料</div>'+''.join('<span class="chip">'+html.escape(hit.get('citation',''))+'</span>' for hit in hits),unsafe_allow_html=True)
        for item in d.get('missing_information',[]):
            st.write('確認事項：'+(item.get('label_ja') or item.get('field') or item.get('code') or '詳細を原文と確認'))
        with st.expander('この判断の根拠・参照資料を確認'):
            st.write('適用したルール')
            for rule in d.get('escalation_reasons',[]):
                st.write(str(rule.get('rule_id',''))+'｜'+str(rule.get('title_ja') or '担当者の確認'))
                st.write(rule.get('detail_ja') or '最新の取引条件を担当者が確認します。')
            if not hits:
                st.warning('この分析に参照できる資料は保存されていません。資料に基づく回答ができるとは扱いません。')
            else:
                st.write('検索で取得した資料（取引の可否を保証するものではありません）')
                _,documents=load_knowledge()
                for hit in hits:
                    citation=hit.get('citation','')
                    doc=next((x for x in documents if x['document_id']==hit['document_id'] and str(x['version'])==str(hit['document_version'])),None)
                    chunk=None
                    if doc:
                        translated,_=translated_document(doc,'ja')
                        chunk=next((c for c in translated['chunks'] if c['chunk_id']==hit['chunk_id']),None)
                    st.markdown('**'+citation+'**')
                    st.write((chunk or {}).get('content') or hit.get('excerpt',''))
            st.caption('問い合わせと有効なKBの該当箇所をAIに渡し、返信案を生成します。登録可否はルールと承認処理でも制御します。')

def format_date(value):
    if not value:
        return '—'
    try:
        return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(ZoneInfo('Asia/Tokyo')).strftime('%Y-%m-%d %H:%M JST')
    except ValueError:
        return '日時を確認してください'

def review_ui(case):
    cid = case['case_id']
    rev = current_revision(case)
    blocked = case.get('decision_snapshot',{}).get('automatic_actions_blocked',False)
    st.markdown(overview_html(case,source_draft_for_case(case).get('clarifying_questions')),unsafe_allow_html=True)
    with st.expander('原文との照合・判断の根拠を詳しく見る'):
        extracted_fields(case)
        decision_and_sources(case)
    st.markdown('<div id="reply-review"></div>',unsafe_allow_html=True)
    with st.container(border=True,key='reply_panel'):
        st.subheader('顧客への返信案')
        st.markdown(reply_html(rev['reply_text']),unsafe_allow_html=True)
        summary(case)
    if case['status'] in ('ACTIONED','APPROVED','CLOSED'):
        st.success('返信内容は承認済みです。案件・対応履歴でCRMとタスクを確認できます。')
        st.button('この案件を開く →', key='open_'+cid, on_click=move, args=('案件・対応履歴',))
    else:
        with st.container(border=True,key='approval_panel'):
            st.subheader('初回返信の確認')
            st.write('承認するのは返信内容です。価格・出荷の確定やメール送信は行いません。')
            actor = st.text_input('確認者の氏名', key='case_actor_'+cid, placeholder='例：デモ担当者')
            if st.button('返信内容を承認して登録 →', type='primary', disabled=blocked or not actor.strip(), key='approve_'+cid):
                try:
                    workspace.approve_and_create(cid,actor)
                    st.session_state['active_case_id'] = cid
                    st.session_state['pending_case_id'] = cid
                    st.session_state['pending_page'] = '案件・対応履歴'
                    st.rerun()
                except ValueError:
                    st.error('登録できませんでした。内容と案件の状態を確認してください。')
            with st.expander('返信案を編集・差し戻す'):
                with st.form('edit_form_'+cid):
                    memo = st.text_area('社内向けメモ',rev['summary_ja'],height=180,key='edit_memo_'+rev['revision_id'])
                    reply = st.text_area('顧客への返信案',rev['reply_text'],height=280,key='edit_reply_'+rev['revision_id'])
                    reason = st.text_input('変更・差し戻しの理由',key='edit_reason_'+rev['revision_id'])
                    save = st.form_submit_button('変更を保存（新しい版を作成）')
                    reject = st.form_submit_button('差し戻す')
                if save or reject:
                    if not actor.strip() or not reason.strip():
                        st.warning('確認者の氏名と理由を入力してください。')
                    else:
                        try:
                            if save:
                                workspace.save_edit(cid,memo,reply,actor,reason)
                            else:
                                workspace.reject(cid,actor,reason)
                            st.rerun()
                        except ValueError:
                            st.error('保存できませんでした。最新の版を確認してください。')

if page == pages[0]:
    current_id=st.session_state.get('active_case_id')
    # Widget keys are removed when their page is not rendered. Keep the user's
    # chosen sample and typed inquiry in independent model state across tabs.
    if 'sample_choice' not in st.session_state:
        remembered=st.session_state.get('selected_sample_index',0)
        st.session_state.sample_choice=remembered if remembered in range(len(samples)) else 0
    saved_inputs=st.session_state.setdefault('selected_input_values',{})
    selected_sample=samples[st.session_state.get('sample_choice',0)]
    selected_message=st.session_state.get('input_'+selected_sample['id'],saved_inputs.get(selected_sample['id'],selected_sample['inquiry']))
    working=bool(current_id and workspace.case(current_id)['inquiry']==selected_message)
    if not working:
        st.header('問い合わせを確認する')
        st.write('海外営業の問い合わせ整理・返信準備・案件登録を支援します。')
    with st.container(key='demo_start'):
        choice_col,start_col=st.columns([3,2],vertical_alignment='bottom')
        with choice_col:
            chosen = st.selectbox('展示ケースを選択',range(len(samples)),format_func=lambda i: samples[i]['id']+'｜'+samples[i]['title_ja'],key='sample_choice')
        st.session_state.selected_sample_index=chosen
        sample=samples[chosen]
        input_key='input_'+sample['id']
        current_message=st.session_state.get(input_key,saved_inputs.get(sample['id'],sample['inquiry']))
        with start_col:
            if st.button('このケースを開く',type='primary',disabled=current_message!=sample['inquiry'],width='stretch'):
                case=workspace.open_sample(sample)
                st.session_state['active_case_id']=case['case_id']
                st.session_state['selected_source']=sample['id']
                st.rerun()
    purpose={'01A':('購入・見積もり相談','240本・予算・到着希望を読み取り、見積手順を参照。確認後のCRM登録まで試せます。'),
             '04A':('破損商品の対応','写真の補足依頼と費用・発送日の社内確認を分けます。「発送」と「到着」の違いも確認できます。'),
             '06A':('自動化できない依頼の検知','商品と配送先が2組ある依頼。情報を1件に潰さず、登録を止める判断を確認できます。')}
    purpose_title,purpose_text=purpose.get(sample['id'],('問い合わせ対応','原文と結果を確認します。'))
    loaded=bool(current_id and workspace.case(current_id)['inquiry']==current_message)
    if not loaded:
        st.markdown('<div class="sample-brief"><span>'+html.escape(sample['id'])+' / '+html.escape(purpose_title)+'</span><p>'+html.escape(purpose_text)+'</p></div>',unsafe_allow_html=True)
        st.caption('保存済みの合成サンプルです。キーの入力や新たなAPI利用は不要です。')
    with st.expander('顧客の原文・APIでの再分析'):
        message=st.text_area('顧客からの問い合わせ（合成データ）',saved_inputs.get(sample['id'],sample['inquiry']),height=230,key=input_key)
        saved_inputs[sample['id']]=message
        if message != sample['inquiry']:
            st.info('原文を変更した場合、保存済み結果は使えません。新しい原文はAPIで分析してください。')
        with st.expander('入力した原文をAPIで分析する（任意・有料）'):
            ready = bool(st.session_state.get('public_key','').strip()) and st.session_state.get('api_attempts',0)<3
            if st.button('APIで分析し、返信案を作成',disabled=not ready):
                st.session_state.api_attempts = st.session_state.get('api_attempts',0)+1
                try:
                    from inquiryflow.service import analyze, generate_response_draft, save_run
                    with st.spinner('問い合わせを分析し、返信案を作成しています…'):
                        a = analyze(message,st.session_state.public_key,st.session_state.public_model)
                        save_run(a,directory=workspace.root/'runs')
                        if not a.get('output') or not a.get('decision'):
                            raise ValueError('analysis failed')
                        d = generate_response_draft(message,a['output'],a['retrieval'],a['decision'],st.session_state.public_key,st.session_state.public_model,source_analysis_run_id=a['run_id'])
                        save_run(d,directory=workspace.root/'runs')
                        case = workspace.open_live(a,d)
                    st.session_state.active_case_id = case['case_id']
                    st.session_state.selected_source = 'live'
                    st.rerun()
                except Exception:
                    st.error('API処理が完了しませんでした。キー・モデル・利用枠を確認してください。保存済みの例は引き続き利用できます。')
            st.caption('この接続では最大3回まで。ボタンを押したときだけ呼び出し、失敗時の自動再試行は行いません。')
    if not working:
        with st.expander('想定する業務と、このデモでできること'):
            st.write('想定利用者：日本酒を扱う貿易会社の海外営業担当と、その確認者。実企業への導入実績ではなく、合成データでの業務仮説です。')
            st.table([{'作業':'依頼の理解','手作業':'届いたメールを読み、商品・数量・期限を書き出す','このシステム':'構造化して原文の引用と一緒に確認'},
                      {'作業':'返信の準備','手作業':'社内規定を探し、返信を起草','このシステム':'参照資料と確認事項を付けて初稿を準備'},
                      {'作業':'記録と追跡','手作業':'顧客情報を転記し、フォローを設定','このシステム':'承認した版から模擬CRMとタスクを作成'}])
            st.write('省ける可能性があるのは整理・起草・転記の作業です。在庫照会や他部署の回答待ちは、この版では短縮できません。')
            st.caption('原文の日付は検証当時の想定を保持しています。')
    cid = st.session_state.get('active_case_id')
    if cid and workspace.case(cid)['inquiry']==message:
        case = workspace.case(cid)
        st.markdown(case_heading_html(case,workspace.snapshot(cid)),unsafe_allow_html=True)
        source_run=case.get('source_run_id','')
        source=source_run.split('public-sample:',1)[1] if source_run.startswith('public-sample:') else 'live'
        if source=='live':
            st.info('APIで作成した返信案です。内容の承認後、デモ用CRMとタスクを作成できます。メールは送信しません。')
        else:
            original=next((s for s in samples if s['id']==source),None)
            edit_label=sample_edit_label(original) if original else '保存内容を確認'
            st.markdown('<span class="chip">保存済みAPI結果</span><span class="chip">'+html.escape(edit_label)+'</span><span class="chip">未送信</span>',unsafe_allow_html=True)
        review_ui(case)
        with st.expander('抽出データ・引用元・元のAPI出力'):
            st.json(case['extraction'])
            original = next((s for s in samples if s['id']==source),None)
            if original:
                st.write('使用したモデルとバージョン')
                st.json(original['provenance'])
                st.write('編集前のAPI返信（保存時のまま）')
                st.markdown(reply_html(original['draft']['output']['customer_reply']),unsafe_allow_html=True)
                reply_edited=(original.get('edited') or {}).get('reply_text',original['draft']['output']['customer_reply'])!=original['draft']['output']['customer_reply']
                st.caption('上の返信案には人手編集が含まれます。下記は編集前のAPI出力です。' if reply_edited else '顧客への返信案はAPI生成時のままです。展示用の編集は社内メモに分けて記録しています。')
                st.write('編集前のAPI出力（保存時のまま）')
                st.json(original['draft']['output'])

elif page == pages[1]:
    st.header('案件・対応履歴')
    cases = workspace.cases()
    labels={c['case_id']:case_state(c,workspace.snapshot(c['case_id']))[0] for c in cases}
    metrics=[('承認待ち',sum(v=='承認待ち' for v in labels.values())),('フォロー中',sum(v in ('フォロー中','案件の完了待ち') for v in labels.values())),('対応完了',sum(v=='対応完了' for v in labels.values())),('担当者が分割',sum(v=='担当者が分割' for v in labels.values()))]
    st.markdown('<div class="record-stats">'+''.join('<div><span>'+label+'</span><b>'+str(count)+'</b></div>' for label,count in metrics)+'</div>',unsafe_allow_html=True)
    if not cases:
        st.info('この接続の案件はまだありません。問い合わせ対応で例を開いてください。')
        st.button('問い合わせ対応へ →',on_click=move,args=(pages[0],))
    else:
        focus=st.session_state.pop('pending_case_id',None)
        if focus or 'case_status_filter' not in st.session_state:
            st.session_state.case_status_filter='すべて'
        status_filter=st.pills('案件の状態',['すべて','承認待ち','フォロー中','対応完了','担当者が分割'],key='case_status_filter') or 'すべて'
        filtered=[c for c in cases if status_filter=='すべて' or labels[c['case_id']]==status_filter or (status_filter=='フォロー中' and labels[c['case_id']]=='案件の完了待ち')]
        if not filtered:
            st.info('この状態の案件はありません。上の条件を「すべて」にすると一覧に戻れます。')
            st.stop()
        ids = [c['case_id'] for c in sorted(filtered,key=lambda c:c['created_at'],reverse=True)]
        if st.session_state.get('active_case_id') not in ids:
            st.session_state.active_case_id=ids[0]
        if focus in ids or st.session_state.get('record_case_picker') not in ids:
            st.session_state.record_case_picker=focus if focus in ids else st.session_state.active_case_id
        lookup = {c['case_id']:c for c in cases}
        cid=st.selectbox('開く案件を選択',ids,key='record_case_picker',format_func=lambda c: lookup[c]['display_id']+'｜'+labels[c]+'｜'+(lookup[c]['extraction'].get('company_name') or lookup[c]['extraction'].get('product') or '問い合わせ'))
        st.session_state.active_case_id=cid
        case=workspace.case(cid)
        snap=workspace.snapshot(cid)
        st.markdown(case_heading_html(case,snap),unsafe_allow_html=True)
        if not snap.get('crm'):
            with st.expander('顧客の原文'):
                st.write(case['inquiry'])
            review_ui(case)
        else:
            crm=snap['crm']
            has_pending_followup=any(t.get('task_status')!='COMPLETED' for t in snap.get('tasks',[]))
            next_label=('この案件の対応は完了しています。' if case['status']=='CLOSED' else
                        '返信の承認・模擬CRM登録が完了しました。次はフォローアップを確認します。' if has_pending_followup else
                        '未完了のフォローはありません。内容を確認して案件を完了できます。')
            st.markdown('<div class="statusbar">'+next_label+'</div>',unsafe_allow_html=True)
            st.subheader('次にすること' if has_pending_followup else 'フォロー履歴')
            for task in snap.get('tasks',[]):
                with st.container(border=True,key='followup_'+task['task_id']):
                    task_status={'TODO':'未着手','IN_PROGRESS':'対応中','WAITING_CUSTOMER':'顧客の返信待ち','WAITING_INTERNAL':'社内確認中','FOLLOW_UP_DUE':'フォロー予定','OVERDUE':'期限超過','COMPLETED':'完了'}.get(task.get('track_status'),'未着手')
                    st.markdown('<span class="chip">'+html.escape(task.get('display_id','タスク'))+'</span><span class="chip">'+task_status+'</span>',unsafe_allow_html=True)
                    st.write(followup_title(task,case,'ja'))
                    st.markdown(facts_html([('担当者',task.get('owner') or '未設定'),('期限',format_date(task.get('due_at')))]),unsafe_allow_html=True)
                    done=task.get('task_status')=='COMPLETED'
                    if done:
                        st.success('完了')
                    elif st.button('このフォローを完了',key='task_'+task['task_id']):
                        workspace.complete(task['task_id'],crm.get('owner') or 'デモ担当者')
                        st.rerun()
            can_close=all(t.get('task_status')=='COMPLETED' for t in snap.get('tasks',[]))
            if case['status']=='CLOSED':
                st.success('案件は完了しています。')
            elif st.button('案件を完了',disabled=not can_close):
                workspace.close(cid,crm.get('owner') or 'デモ担当者')
                st.rerun()
            with st.expander('進捗・担当者を変更'):
                with st.form('owner_'+cid):
                    owner=st.text_input('新しい担当者',value=crm.get('owner') or '')
                    statuses={'TODO':'未着手','IN_PROGRESS':'対応中','WAITING_CUSTOMER':'顧客の返信待ち','WAITING_INTERNAL':'社内確認中','FOLLOW_UP_DUE':'フォロー予定','OVERDUE':'期限超過'}
                    open_tasks=[t for t in snap.get('tasks',[]) if t.get('task_status')!='COMPLETED']
                    current_status=(open_tasks[0].get('track_status') if open_tasks else 'TODO') or 'TODO'
                    options=list(statuses)
                    track=st.selectbox('フォローの状態',options,index=options.index(current_status) if current_status in options else 0,format_func=lambda v:statuses[v],disabled=not open_tasks)
                    sales_stage=None
                    if crm.get('intent')=='Sales':
                        stages={'NEW':'受付済み','QUALIFYING':'条件を確認中','QUOTING':'見積準備中','NEGOTIATION':'商談中','WON':'受注','LOST':'見送り'}
                        stage_options=list(stages)
                        sales_stage=st.selectbox('商談状況',stage_options,index=stage_options.index(crm.get('sales_stage')) if crm.get('sales_stage') in stages else 0,format_func=lambda v:stages[v])
                    tracking_reason=st.text_input('変更メモ（任意）')
                    update=st.form_submit_button('進捗・担当者を保存',disabled=case['status']=='CLOSED')
                if update and owner.strip():
                    workspace.update_tracking(cid,crm.get('owner') or 'デモ担当者',owner.strip(),track if open_tasks else None,sales_stage,tracking_reason)
                    st.rerun()
            with st.expander('案件の詳細・承認した返信を確認'):
                with st.container(border=True,key='crm_panel'):
                    st.subheader('CRM・案件情報')
                    fields=[('会社',crm.get('company_name')),('商品',crm.get('product')),('配送先',{'TW':'台湾','HK':'香港'}.get(crm.get('country'),crm.get('country')))]
                    if crm.get('intent')=='Sales':
                        fields.append(('商談状況',{'NEW':'受付済み','QUALIFYING':'条件を確認中','QUOTING':'見積準備中','NEGOTIATION':'商談中','WON':'受注','LOST':'見送り'}.get(crm.get('sales_stage'),'確認中')))
                    fields.append(('優先度',{'HIGH':'優先対応','NORMAL':'通常','LOW':'低','NEEDS_INFO':'情報確認が必要'}.get(crm.get('priority'),'未設定')))
                    st.markdown(facts_html(fields),unsafe_allow_html=True)
                    st.caption('CRM参照番号：'+str(crm.get('display_id','—'))+' ／ この画面内の模擬登録です。')
                summary(case)
                with st.expander('原文と抽出結果を照合する'):
                    st.table(extraction_rows(case['extraction']))
                with st.expander('承認した返信・顧客の原文'):
                    st.markdown(reply_html(current_revision(case)['reply_text']),unsafe_allow_html=True)
                    st.divider()
                    st.write(case['inquiry'])
        with st.expander('変更・承認履歴を見る'):
            st.json({'revisions':case['revisions'],'reviews':case['reviews']})
        st.download_button('この接続の操作記録をダウンロード',json.dumps(workspace.export(),ensure_ascii=False,indent=2),file_name='inquiryflow-demo-records.json',mime='application/json')

elif page==pages[2]:
    st.header('ナレッジ・ルール')
    st.write('AIは問い合わせを整理し、参照資料とルールに沿って返信案を作ります。価格・在庫・納期の実データは接続していません。')
    st.subheader('AIに任せる処理と、プログラムで止める処理')
    st.table([{'役割':'AIによる抽出','入力・制約':'顧客原文・分類方針・固定JSON形式','担当者が確認できるもの':'抽出値と原文の引用'},
              {'役割':'資料の検索','入力・制約':'有効な社内KBの該当箇所を取得','担当者が確認できるもの':'文書ID・版・参照箇所'},
              {'役割':'AIによる返信案','入力・制約':'原文・抽出結果・規則の判定・取得したKB','担当者が確認できるもの':'初稿と人が編集した版を分けて保存'},
              {'役割':'登録の制御','入力・制約':'担当者の承認・対応版・構造上の制約','担当者が確認できるもの':'承認した版から1回だけ模擬CRMとタスクを作成'}])
    with st.expander('実際にAIへ渡した情報を見る（保存済みの例）'):
        context_sample=st.selectbox('入力内容を確認するケース',samples,format_func=lambda s:s['id']+'｜'+s['title_ja'])
        st.write('返信生成時の入力項目')
        st.write('顧客原文 / 抽出した情報 / 規則の判定 / 回答言語 / 取得したKBの該当箇所')
        st.json(context_sample['draft']['input'])
        st.write('抽出時の指示文（当時の原文を保存）')
        st.code(context_sample['analysis']['prompt'],language=None)
        st.caption('顧客のメールは分析するデータとして扱い、メール内の「規則を無視して」という指示で承認や実行条件を変えません。検索は語句・IDF等を用いる方式で、ベクトルDBは使用していません。')
    st.subheader('承認・登録のルール')
    st.write('• 返信案は担当者が確認して承認します。メールは送信しません。\n\n• 承認した版に対してCRMとフォローを1回だけ作成します。\n\n• 複数商品・配送先など、現在の形式で扱えない案件は自動登録を止めます。\n\n• 根拠が不足する場合、価格・輸出可否・到着日は確約しません。')
    _,documents=load_knowledge()
    for doc in documents:
        if doc['status']!='active' or doc.get('authority')=='untrusted':
            continue
        translated,_=translated_document(doc,'ja')
        with st.expander(translated['title']+'｜v'+str(doc['version'])):
            st.caption(doc['document_id']+'｜合成資料・デモ用の社内規定')
            for chunk in translated['chunks']:
                st.write(chunk.get('title',''))
                st.write(chunk['content'])

else:
    st.header('検証と改善')
    evidence=json.loads((SAMPLE_DIR/'presentation_evidence.json').read_text())
    st.write('現在の展示、修正の証拠、過去のテスト結果を分けて確認できます。')
    st.subheader('現在の展示で確認できること')
    st.table([
        {'ケース':'01A 見積依頼','処理の範囲':'依頼と見積手順を確認。初回返信の承認後に模擬CRMとタスクを作成。'},
        {'ケース':'04A 破損対応','処理の範囲':'写真の補足を依頼。費用負担と発送可否は社内で別途確認。'},
        {'ケース':'06A 複数条件','処理の範囲':'自動登録を停止。担当者による分割対応は未完了。'}])
    st.caption('3例とも実際に保存したAPI結果です。対外返信は保存時のまま、社内メモのみ展示用に編集しています。価格・出荷を確定した結果ではありません。')
    with st.expander('3ケースの使用バージョンと未実装の範囲'):
        for row in evidence['cases']:
            st.write(row['id']+'｜'+row['role_ja'])
            st.write(row['limitation_ja'])
            st.caption(row['extract_prompt']+' / '+row['draft_prompt']+' / '+row['rules']+' / '+row['retrieval'])
        st.write('実在庫・価格表・注文配送システムとの接続、実際のメール送信、外部CRMへの登録は行いません。')
    story=evidence['iteration_story']
    st.subheader('改善例｜見積手順の資料を取得できなかった')
    st.markdown('<span class="chip danger">修正前：資料が見つからない</span> → <span class="chip">修正後：見積手順の資料を取得</span>',unsafe_allow_html=True)
    st.write('原因：長い問い合わせで、見積手順の資料の検索スコアが弱くなっていました。')
    st.write('修正：見積依頼の表現と手順の本文の照合を見直し、同じメールで再テストしました。')
    st.caption('確認できたのは資料検索の改善です。在庫・実価格・船期は引き続き担当者が確認します。')
    with st.expander('同じ原文による修正前後の証拠'):
        st.table([{'比較':'修正前','検索の版':story['before']['retrieval_version'],'結果':'参照資料なし'}, {'比較':'修正後','検索の版':story['after']['retrieval_version'],'結果':'見積手順の資料を取得'}])
        st.write(story['change_ja'])
        st.write('取得した資料')
        st.write(story['after']['citations'])
        st.json({'same_input':story['same_input'],'input_sha256':story['input_sha256'],'before':story['before'],'after':story['after']})
    with st.expander('他の改善と、残る問題の扱い'):
        st.write('04A：破損SOPを参照し、写真の補足依頼と社内の費用・発送確認を分けています。写真が未提出でも「追加質問なし」と表示していた総覧を修正しました。')
        st.write('06A：原文にある2件の条件を保ち、自動登録を禁止。複数明細を分割登録する機能は未実装です。')
        st.write('画面操作：案件一覧からの承認で選択状態が衝突する問題を修正し、両画面からの承認を回帰テストに追加しました。')
        for row in evidence['remaining_disposition']:
            st.write(row['case_id']+'：'+row['reason_ja'])
            st.write(row['disposition_ja'])
        st.caption('別ケースの成功を、そのケース自体の再テストの代わりにしません。過去の失敗は履歴として残します。')
    report=json.loads((SAMPLE_DIR/'evaluation_snapshot.json').read_text())
    historical=evidence['historical_evaluation']
    st.subheader('過去の18件の再テスト｜2026年11月3日')
    st.markdown('<div class="evaluation-scoreboard">'+''.join('<div class="'+tone+'"><span>'+label+'</span><strong>'+str(historical['totals'][key])+'</strong></div>' for key,label,tone in [('PASS','基準を満たした','pass'),('FAIL','修正が必要','fail'),('INCOMPLETE','処理が未完了','pending')])+'</div>',unsafe_allow_html=True)
    st.caption('AI評価・改善に使用済みのケースの再テスト。未見問題の成績ではありません。現在の版の正解率や、人による最終検収とは分けて扱います。')
    hard=historical['high_complexity_all']
    st.write('高難度8件：'+str(hard['PASS'])+'件が基準を満たし、'+str(hard['FAIL'])+'件は修正が必要、'+str(hard['INCOMPLETE'])+'件は未完了。')
    with st.expander('ケース別の結果・5つの評価項目'):
        verdicts={'PASS':'適合','FAIL':'要修正','INCOMPLETE':'未完了'}
        st.table([{'ケース':r['case_id'],'結果':verdicts[r['verdict']],'抽出':verdicts.get(r['dimensions'].get('extraction'),'未評価'),'参照資料':verdicts.get(r['dimensions'].get('source'),'未評価'),'ルール':verdicts.get(r['dimensions'].get('rules'),'未評価'),'返信':verdicts.get(r['dimensions'].get('draft'),'未評価'),'登録制御':verdicts.get(r['dimensions'].get('actions'),'未評価')} for r in report['cases']])
        st.caption('18件は旧保留ケース15件と開発再テスト3件。高難度8件は旧保留群5件と開発群3件を合算しています。元の「高難度5件」は旧保留15件内の集計です。')
        st.download_button('この評価記録をダウンロード',json.dumps({'historical_evaluation':historical,'cases':report['cases']},ensure_ascii=False,indent=2),file_name='inquiryflow-evaluation-snapshot.json',mime='application/json')
    with st.expander('手作業との比較条件・データの出所'):
        st.write('本人の自己申告時間は01Aが12分34秒、04Aが6分02秒、06Aが4分42秒。日本語版の再計測ではありません。確認・修正・CRM操作・外部回答待ちを揃えた比較ではないため、API生成時間から削減率は計算していません。')
        st.write('D8・D9の完全な原始出力と再テストは本機版で保管し、公開版には合成例と改善の証拠を抜粋しています。日常案件の承認履歴とは分けています。')
        for sample in samples:
            st.write(sample['id'])
            st.json(sample['provenance'])
        st.download_button('公開用の成果・改善記録をダウンロード',json.dumps(evidence,ensure_ascii=False,indent=2),file_name='inquiryflow-presentation-evidence.json',mime='application/json')
