"""Shareable interview demo. No local history or server API credentials."""
from __future__ import annotations
import html
import json
import tempfile
from datetime import datetime
from zoneinfo import ZoneInfo
import streamlit as st
from inquiryflow.public_demo import PublicWorkspace, load_samples
from inquiryflow.review import current_revision, ReviewError
from inquiryflow.presentation import internal_notes_html, email_text_html
from inquiryflow.ui_i18n import followup_title
from inquiryflow.retrieval import load_knowledge
from inquiryflow.knowledge_i18n import translated_document

st.set_page_config(page_title='InquiryFlow | 海外営業の問い合わせ対応', page_icon='✉️', layout='wide',initial_sidebar_state='collapsed')

def move(page):
    st.session_state['public_nav'] = page

def reset():
    old = st.session_state.pop('public_temp', None)
    if old:
        old.cleanup()
    for key in list(st.session_state):
        if key.startswith(('case_', 'edit_', 'input_', 'sample_', 'selected_', 'public_key')):
            del st.session_state[key]
    st.session_state['public_nav'] = '問い合わせ対応'

if 'public_temp' not in st.session_state:
    st.session_state.public_temp = tempfile.TemporaryDirectory(prefix='inquiryflow-public-')
workspace = PublicWorkspace(st.session_state.public_temp.name)
samples = load_samples()
dark = st.session_state.get('public_dark', False)
bg, paper, ink, line = ('#10231f','#19332c','#e4f1eb','#36584c') if dark else ('#f4f7f4','#ffffff','#173e36','#d5e3db')
st.markdown(f'''<style>
.stApp {{background:{bg};color:{ink};}}
[data-testid="stSidebar"] {{background:{paper};color:{ink};}}
.block-container {{max-width:980px;padding:2rem 1.3rem 4rem;}}
[data-testid="stHeader"] {{background:transparent;}}
h1,h2,h3,p,label {{color:{ink};}}
textarea,input {{background:{paper}!important;color:{ink}!important;}}
[data-baseweb="input"],[data-baseweb="textarea"],[data-baseweb="base-input"], [data-baseweb="select"]>div {{background:{paper}!important;color:{ink}!important;}}
[data-testid="stAlert"] {{background:{paper};color:{ink};border:1px solid {line};}}
[data-testid="stExpander"] details,[data-testid="stForm"] {{background:{paper};color:{ink};border-color:{line};}}
[data-testid="stTable"] table,[data-testid="stTable"] th,[data-testid="stTable"] td {{color:{ink};background:{paper};border-color:{line};}}
h1 {{font-size:2rem!important;}} h2 {{font-size:1.4rem!important;}} h3 {{font-size:1.12rem!important;}}
[data-testid="stVerticalBlockBorderWrapper"]>div {{border-color:{line}!important;background:{paper};border-radius:14px;}}
.hero {{background:linear-gradient(115deg,#103b32,#116b5d);padding:1.6rem 1.8rem;border-radius:20px;color:#eefbf6;margin:.5rem 0 1.2rem;}}
.hero h1,.hero p {{color:#eefbf6;}} .hero p {{margin:0;font-size:.95rem;}} .hero small {{color:#a4e2cf;letter-spacing:.12em;}}
.reply {{background:{bg};border-left:3px solid #79bcaa;border-radius:10px;padding:1rem 1.2rem;line-height:1.85;overflow-wrap:anywhere;}}
.if-internal-section {{line-height:1.75;}} .if-draft-label {{font-weight:600;color:#268c75;}}
.tag {{display:inline-block;background:#e7f3ed;color:#245c49;border-radius:20px;padding:.2rem .65rem;font-size:.8rem;margin:.15rem .4rem .3rem 0;}}
.stButton button {{border-radius:10px;min-height:42px;background:{paper};color:{ink};border-color:{line};}}
.stButton button p {{color:inherit;}}
.stButton button[kind="primary"] {{background:#145c4d;border:0;color:white;}}
button[kind="primary"] * {{color:#fff!important;}}
[role="radiogroup"] {{gap:.45rem;padding:.25rem 0 1rem;border-bottom:1px solid {line};margin-bottom:.75rem;}}
[role="radiogroup"] label {{background:{paper};border:1px solid {line};border-radius:9px;padding:.45rem .65rem;}}
[role="radiogroup"] label:has(input:checked) {{background:#145c4d;color:#fff!important;}}
[role="radiogroup"] label:has(input:checked) * {{color:#fff!important;}}
.statusbar {{padding:.6rem .85rem;background:#e7f3ed;border-radius:9px;color:#245c49;margin:.5rem 0 1rem;font-size:.9rem;}}
[data-baseweb="select"]>div {{border:1px solid #7cae9e;border-radius:10px;}}
@media(max-width:600px) {{.block-container {{padding:1rem .8rem 3rem;}} .hero {{padding:1.25rem;}}}}
@media(prefers-reduced-motion:no-preference) {{.stButton button {{transition:transform .15s,box-shadow .15s;}} .stButton button:hover {{transform:translateY(-1px);box-shadow:0 4px 12px #103b3218;}}}}
</style>''', unsafe_allow_html=True)

with st.sidebar:
    st.title('InquiryFlow')
    st.write('海外営業の問い合わせ対応')
    st.toggle('ダークモード', key='public_dark', on_change=lambda: None)
    st.divider()
    st.write('合成データを使った公開デモです。実際のメール送信・外部CRMへの登録は行いません。')
    st.button('この接続のデータをリセット', on_click=reset, width='stretch')
    st.caption('操作データは接続ごとの一時保存です。再接続やサーバー再起動で消える場合があります。')
    with st.expander('自分のAPIキーで試す（任意）'):
        st.write('入力した問い合わせをOpenAIへ送信します。実在する顧客情報は入力しないでください。1回につき分析と返信作成の最大2回を呼び出します。')
        st.text_input('OpenAI APIキー', type='password', key='public_key')
        st.text_input('モデルID', value='gpt-6.1-sol', key='public_model')
        st.caption('キーはこの接続内だけで使用し、ファイル・ダウンロードには含めません。キーがなくても保存済みの3例を操作できます。')

st.markdown('<div class="hero"><small>AI OPERATIONS WORKSPACE</small><h1>InquiryFlow</h1><p>海外からの問い合わせを整理し、返信の確認から案件登録・フォローまで。</p></div>', unsafe_allow_html=True)
pages = ['問い合わせ対応','案件・対応履歴','ナレッジ・ルール','検証と改善']
if 'pending_page' in st.session_state:
    st.session_state.public_nav = st.session_state.pop('pending_page')
page = st.radio('ワークスペース', pages, key='public_nav', horizontal=True, label_visibility='collapsed')

def summary(case):
    with st.expander('社内向けメモ・確認事項'):
        st.markdown(internal_notes_html(current_revision(case)['summary_ja']), unsafe_allow_html=True)

def extracted_fields(case):
    e=case['extraction']
    q=e.get('purchase_quantity') or {}
    b=e.get('budget') or {}
    t=e.get('timeline') or {}
    rows=[('会社',e.get('company_name') or '未記載'),('商品',e.get('product') or '未記載'),
          ('数量（原文）',q.get('raw') or '未記載'),('予算（原文）',b.get('raw') or '未記載'),
          ('配送先',e.get('country') or '未記載'),('希望日（原文）',t.get('raw') or '未記載')]
    with st.expander('読み取った依頼内容を確認'):
        st.table([{'項目':k,'内容':v} for k,v in rows])
        st.caption('配送先が複数ある場合など、この一覧だけでは依頼全体を表せないことがあります。原文と社内メモも確認してください。')

def format_date(value):
    if not value:
        return '—'
    try:
        return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(ZoneInfo('Asia/Tokyo')).strftime('%Y-%m-%d %H:%M JST')
    except ValueError:
        return '日時を確認してください'

def review_ui(case):
    cid = case['case_id']
    rev = current_revision(case)
    blocked = case.get('decision_snapshot',{}).get('automatic_actions_blocked',False)
    extracted_fields(case)
    with st.container(border=True):
        st.subheader('返信案を確認')
        st.markdown('<div class="reply">'+email_text_html(rev['reply_text'])+'</div>',unsafe_allow_html=True)
        summary(case)
    if blocked:
        st.warning('この例は商品・配送先を分けて扱う必要があります。現在のデータ構造では一括登録できないため、CRM・タスクの自動作成を止めています。担当者による分割対応が必要です。')
    if case['status'] in ('ACTIONED','APPROVED','CLOSED'):
        st.success('承認済みです。案件・対応履歴でCRMとフォローを確認できます。')
        st.button('この案件を開く →', key='open_'+cid, on_click=move, args=('案件・対応履歴',))
    else:
        with st.container(border=True):
            st.subheader('担当者の確認・承認')
            actor = st.text_input('確認者の氏名', key='case_actor_'+cid, placeholder='例：デモ担当者')
            if st.button('承認してCRM・フォローを作成 →', type='primary', disabled=blocked or not actor.strip(), key='approve_'+cid):
                try:
                    workspace.approve_and_create(cid,actor)
                    st.session_state['selected_case'] = cid
                    st.session_state['pending_page'] = '案件・対応履歴'
                    st.rerun()
                except ValueError:
                    st.error('登録できませんでした。内容と案件の状態を確認してください。')
            with st.expander('返信案を編集・差し戻す'):
                with st.form('edit_form_'+cid):
                    memo = st.text_area('社内向けメモ',rev['summary_ja'],height=180,key='edit_memo_'+rev['revision_id'])
                    reply = st.text_area('顧客への返信案',rev['reply_text'],height=280,key='edit_reply_'+rev['revision_id'])
                    reason = st.text_input('変更・差し戻しの理由',key='edit_reason_'+rev['revision_id'])
                    save = st.form_submit_button('変更を保存（新しい版を作成）')
                    reject = st.form_submit_button('差し戻す')
                if save or reject:
                    if not actor.strip() or not reason.strip():
                        st.warning('確認者の氏名と理由を入力してください。')
                    else:
                        try:
                            if save:
                                workspace.save_edit(cid,memo,reply,actor,reason)
                            else:
                                workspace.reject(cid,actor,reason)
                            st.rerun()
                        except ValueError:
                            st.error('保存できませんでした。最新の版を確認してください。')

if page == pages[0]:
    st.header('問い合わせから返信・登録まで')
    st.write('例を選ぶ → 保存済み結果を開く → 返信を確認して承認')
    chosen = st.selectbox('展示ケースを選択',range(len(samples)),format_func=lambda i: samples[i]['id']+'｜'+samples[i]['title_ja'],key='sample_choice')
    sample = samples[chosen]
    message = st.text_area('顧客からの問い合わせ（合成データ）',sample['inquiry'],height=230,key='input_'+sample['id'])
    if st.button('保存済みのAPI結果を開く（キー不要）',type='primary',disabled=message!=sample['inquiry']):
        case = workspace.open_sample(sample)
        st.session_state['selected_case'] = case['case_id']
        st.session_state['selected_source'] = sample['id']
        st.rerun()
    if message != sample['inquiry']:
        st.info('原文を変更した場合、保存済み結果は使えません。新しい原文はAPIで分析してください。')
    with st.expander('入力した原文をAPIで分析する（任意・有料）'):
        ready = bool(st.session_state.get('public_key','').strip()) and st.session_state.get('api_attempts',0)<3
        if st.button('APIで分析し、返信案を作成',disabled=not ready):
            st.session_state.api_attempts = st.session_state.get('api_attempts',0)+1
            try:
                from inquiryflow.service import analyze, generate_response_draft, save_run
                with st.spinner('問い合わせを分析し、返信案を作成しています…'):
                    a = analyze(message,st.session_state.public_key,st.session_state.public_model)
                    save_run(a,directory=workspace.root/'runs')
                    if not a.get('output') or not a.get('decision'):
                        raise ValueError('analysis failed')
                    d = generate_response_draft(message,a['output'],a['retrieval'],a['decision'],st.session_state.public_key,st.session_state.public_model,source_analysis_run_id=a['run_id'])
                    save_run(d,directory=workspace.root/'runs')
                    case = workspace.open_live(a,d)
                st.session_state.selected_case = case['case_id']
                st.session_state.selected_source = 'live'
                st.rerun()
            except Exception:
                st.error('API処理が完了しませんでした。キー・モデル・利用枠を確認してください。保存済みの例は引き続き利用できます。')
        st.caption('この接続では最大3回まで。ボタンを押したときだけ呼び出し、失敗時の自動再試行は行いません。')
    cid = st.session_state.get('selected_case')
    if cid and workspace.case(cid)['inquiry']==message:
        case = workspace.case(cid)
        source = st.session_state.get('selected_source')
        if source=='live':
            st.info('今回のAPIで作成した結果です。担当者の承認前に送信・登録しません。')
        else:
            st.info('保存済みのAPI結果です。展示用に人が編集した返信・メモを含みます。今この場でAPIは呼び出していません。')
        review_ui(case)
        with st.expander('抽出データ・引用元・元のAPI出力'):
            st.json(case['extraction'])
            original = next((s for s in samples if s['id']==source),None)
            if original:
                st.write('使用したモデルとバージョン')
                st.json(original['provenance'])
                st.write('編集前のAPI出力（保存時のまま）')
                st.json(original['draft']['output'])

elif page == pages[1]:
    st.header('案件・対応履歴')
    cases = workspace.cases()
    if not cases:
        st.info('この接続の案件はまだありません。問い合わせ対応で例を開いてください。')
        st.button('問い合わせ対応へ →',on_click=move,args=(pages[0],))
    else:
        ids = [c['case_id'] for c in sorted(cases,key=lambda c:c['created_at'],reverse=True)]
        if st.session_state.get('selected_case') not in ids:
            st.session_state.selected_case=ids[0]
        lookup = {c['case_id']:c for c in cases}
        cid=st.selectbox('確認する案件',ids,key='selected_case',format_func=lambda c: lookup[c]['display_id']+'｜'+(lookup[c]['extraction'].get('company_name') or lookup[c]['extraction'].get('product') or '問い合わせ'))
        case=workspace.case(cid)
        snap=workspace.snapshot(cid)
        st.subheader(case['display_id'])
        summary(case)
        with st.expander('承認対象の返信・最新の版'):
            st.markdown('<div class="reply">'+email_text_html(current_revision(case)['reply_text'])+'</div>',unsafe_allow_html=True)
        with st.expander('顧客の原文'):
            st.write(case['inquiry'])
        if not snap.get('crm'):
            st.info('CRMは未作成です。返信案の承認が必要です。')
            review_ui(case)
        else:
            crm=snap['crm']
            st.markdown('<div class="statusbar">✓ 承認済み・CRM登録済み　／　次はフォローアップを確認</div>',unsafe_allow_html=True)
            with st.container(border=True):
                st.subheader('CRM・案件情報')
                st.write('会社：'+str(crm.get('company_name') or '未確認'))
                st.write('商品：'+str(crm.get('product') or '未確認'))
                st.write('配送先：'+str(crm.get('country') or '未確認'))
                st.write('担当者：'+str(crm.get('owner') or '未設定'))
                st.caption('CRM参照番号：'+str(crm.get('display_id','—'))+' ／ この画面内の模擬登録です。')
            extracted_fields(case)
            with st.expander('担当者を変更'):
                with st.form('owner_'+cid):
                    owner=st.text_input('新しい担当者',value=crm.get('owner') or '')
                    update=st.form_submit_button('担当者を保存')
                if update and owner.strip():
                    workspace.update_owner(cid,crm.get('owner') or 'デモ担当者',owner.strip())
                    st.rerun()
            st.subheader('フォローアップ')
            for task in snap.get('tasks',[]):
                with st.container(border=True):
                    st.write(followup_title(task,case,'ja'))
                    st.write('期限：'+format_date(task.get('due_at'))+'　担当者：'+str(task.get('owner') or '未設定'))
                    done=task.get('task_status')=='COMPLETED'
                    if done:
                        st.success('完了')
                    elif st.button('このフォローを完了',key='task_'+task['task_id']):
                        workspace.complete(task['task_id'],crm.get('owner') or 'デモ担当者')
                        st.rerun()
            can_close=all(t.get('task_status')=='COMPLETED' for t in snap.get('tasks',[]))
            if case['status']=='CLOSED':
                st.success('案件は完了しています。')
            elif st.button('案件を完了',disabled=not can_close):
                workspace.close(cid,crm.get('owner') or 'デモ担当者')
                st.rerun()
        with st.expander('変更・承認履歴を見る'):
            st.json({'revisions':case['revisions'],'reviews':case['reviews']})
        st.download_button('この接続の操作記録をダウンロード',json.dumps(workspace.export(),ensure_ascii=False,indent=2),file_name='inquiryflow-demo-records.json',mime='application/json')

elif page==pages[2]:
    st.header('ナレッジ・ルール')
    st.write('AIは問い合わせを整理し、参照資料とルールに沿って返信案を作ります。価格・在庫・納期の実データは接続していません。')
    st.subheader('承認・登録のルール')
    st.write('• 返信案は担当者が確認して承認します。メールは送信しません。\n\n• 承認した版に対してCRMとフォローを1回だけ作成します。\n\n• 複数商品・配送先など、現在の形式で扱えない案件は自動登録を止めます。\n\n• 根拠が不足する場合、価格・輸出可否・到着日は確約しません。')
    _,documents=load_knowledge()
    for doc in documents:
        if doc['status']!='active' or doc.get('authority')=='untrusted':
            continue
        translated,_=translated_document(doc,'ja')
        with st.expander(translated['title']+'｜v'+str(doc['version'])):
            st.caption(doc['document_id']+'｜合成資料・デモ用の社内規定')
            for chunk in translated['chunks']:
                st.write(chunk.get('title',''))
                st.write(chunk['content'])

else:
    st.header('検証と改善')
    st.write('日常の承認履歴とは別に、開発中の失敗と修正を確認するための記録です。')
    for title,before,change,limit in [
        ('01A｜見積依頼の資料検索','長い日本語メールで見積手順の資料が検索候補から外れた。','見積に関する表現と文書本文の一致を見直し、同じ入力で資料が取得できることを再確認。','商品カタログ・実在庫・船期は未接続。'),
        ('04A｜破損対応の確認','写真・費用負担・発送可否の確認が混ざり、返信が不自然になった。','証拠の確認と社内の判断を分け、無料補送や発送日を先に約束しない文面に修正。','実際の注文・配送履歴は照会していない。'),
        ('06A｜商品と配送先が2組ある依頼','単一商品の形式では、商品と配送先を正しく分けて登録できない。','数量・配送先を原文と返信に残し、自動登録を止める。','安全に止められても、自動処理が完了したことにはならない。')]:
        with st.container(border=True):
            st.subheader(title)
            st.write('発見した問題：'+before)
            st.write('対応：'+change)
            st.write('残る制約：'+limit)
    st.subheader('手作業との比較条件')
    st.write('自己申告の作業時間は01Aが12分34秒、04Aが6分02秒、06Aが4分42秒。文章の作成条件が揃った厳密な比較実験ではありません。外部への確認待ち・CRM入力・追跡設定は含まれず、API生成時間だけで削減率は計算していません。')
    with st.expander('保存済みAPI結果の出所・バージョン'):
        for sample in samples:
            st.write(sample['id'])
            st.json(sample['provenance'])
    st.caption('この公開デモの3例は既知のケースです。未見の保留テストとして扱いません。')
