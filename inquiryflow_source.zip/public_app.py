"""Shareable interview demo. No local history or server API credentials."""
from __future__ import annotations
import html
import json
import tempfile
from datetime import datetime
from zoneinfo import ZoneInfo
import streamlit as st
from inquiryflow.public_demo import PublicWorkspace, load_samples, SAMPLE_DIR
from inquiryflow.public_ui import theme_css, reply_html, case_state, case_heading_html, facts_html
from inquiryflow.review import current_revision, ReviewError
from inquiryflow.presentation import internal_notes_html, email_text_html
from inquiryflow.ui_i18n import followup_title
from inquiryflow.retrieval import load_knowledge
from inquiryflow.knowledge_i18n import translated_document

st.set_page_config(page_title='InquiryFlow | 海外営業の問い合わせ対応', page_icon='✉️', layout='wide',initial_sidebar_state='collapsed')

def move(page):
    st.session_state['public_nav'] = page

def reset():
    old = st.session_state.pop('public_temp', None)
    if old:
        old.cleanup()
    for key in list(st.session_state):
        if key.startswith(('case_', 'edit_', 'input_', 'sample_', 'selected_', 'public_key', 'active_case_', 'record_case_', 'pending_')):
            del st.session_state[key]
    st.session_state['public_nav'] = '問い合わせ対応'

if 'public_temp' not in st.session_state:
    st.session_state.public_temp = tempfile.TemporaryDirectory(prefix='inquiryflow-public-')
workspace = PublicWorkspace(st.session_state.public_temp.name)
samples = load_samples()
# Keep the active record separate from widget-owned selection state.
if 'active_case_id' not in st.session_state and st.session_state.get('selected_case'):
    st.session_state.active_case_id=st.session_state.selected_case

def toggle_theme():
    st.session_state.ui_dark_mode=not st.session_state.get('ui_dark_mode',False)

if 'ui_dark_mode' not in st.session_state:
    st.session_state.ui_dark_mode=bool(st.session_state.get('public_dark',False))
dark=st.session_state.ui_dark_mode
st.markdown(theme_css(dark),unsafe_allow_html=True)
with st.container(key='public_theme_control'):
    st.button('☀' if dark else '☾',help='ライトモードに切り替え' if dark else 'ダークモードに切り替え',on_click=toggle_theme)
with st.container(key='public_settings'):
    with st.popover('⚙',help='設定・APIキー'):
        st.subheader('設定')
        st.write('合成データによる公開デモです。メール送信・外部CRMへの登録は行いません。')
        st.button('この接続のデータをリセット',on_click=reset,width='stretch')
        st.caption('操作記録は接続ごとの一時保存です。再接続や再起動で消える場合があります。')
        with st.expander('APIキーとモデル（任意）'):
            st.write('APIを使う場合、入力した原文をOpenAIへ送信します。実在する顧客情報は入力しないでください。')
            st.text_input('OpenAI APIキー',type='password',key='public_key')
            st.text_input('モデルID',value='gpt-6.1-sol',key='public_model')
            st.caption('保存済みの例はキー不要。キーはこの接続内のみで使用し、保存・ダウンロードには含めません。')

st.markdown('<div class="hero"><small>AI OPERATIONS WORKSPACE</small><h1>InquiryFlow</h1><p>海外からの問い合わせを整理し、返信の確認から案件登録・フォローまで。</p></div>', unsafe_allow_html=True)
pages = ['問い合わせ対応','案件・対応履歴','ナレッジ・ルール','検証と改善']
if 'pending_page' in st.session_state:
    st.session_state.public_nav = st.session_state.pop('pending_page')
page = st.radio('ワークスペース', pages, key='public_nav', horizontal=True, label_visibility='collapsed')

def summary(case):
    with st.expander('社内向けメモ・確認事項'):
        st.markdown(internal_notes_html(current_revision(case)['summary_ja']), unsafe_allow_html=True)

def extracted_fields(case):
    e=case['extraction']
    q=e.get('purchase_quantity') or {}
    b=e.get('budget') or {}
    t=e.get('timeline') or {}
    rows=[('会社',e.get('company_name') or '未記載'),('商品',e.get('product') or '未記載'),
          ('数量（原文）',q.get('raw') or '未記載'),('予算（原文）',b.get('raw') or '未記載'),
          ('配送先',e.get('country') or '未記載'),('希望日（原文）',t.get('raw') or '未記載')]
    with st.expander('読み取った依頼内容を確認'):
        st.table([{'項目':k,'内容':v} for k,v in rows])
        st.caption('配送先が複数ある場合など、この一覧だけでは依頼全体を表せないことがあります。原文と社内メモも確認してください。')

def format_date(value):
    if not value:
        return '—'
    try:
        return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(ZoneInfo('Asia/Tokyo')).strftime('%Y-%m-%d %H:%M JST')
    except ValueError:
        return '日時を確認してください'

def review_ui(case):
    cid = case['case_id']
    rev = current_revision(case)
    blocked = case.get('decision_snapshot',{}).get('automatic_actions_blocked',False)
    extracted_fields(case)
    with st.container(border=True,key='reply_panel'):
        st.subheader('顧客への返信案')
        st.markdown(reply_html(rev['reply_text']),unsafe_allow_html=True)
        summary(case)
    if blocked:
        st.warning('この例は商品・配送先を分けて扱う必要があります。現在のデータ構造では一括登録できないため、CRM・タスクの自動作成を止めています。担当者による分割対応が必要です。')
    if case['status'] in ('ACTIONED','APPROVED','CLOSED'):
        st.success('承認済みです。案件・対応履歴でCRMとフォローを確認できます。')
        st.button('この案件を開く →', key='open_'+cid, on_click=move, args=('案件・対応履歴',))
    else:
        with st.container(border=True,key='approval_panel'):
            st.subheader('返信を確認して承認')
            actor = st.text_input('確認者の氏名', key='case_actor_'+cid, placeholder='例：デモ担当者')
            if st.button('承認してCRM・フォローを作成 →', type='primary', disabled=blocked or not actor.strip(), key='approve_'+cid):
                try:
                    workspace.approve_and_create(cid,actor)
                    st.session_state['active_case_id'] = cid
                    st.session_state['pending_case_id'] = cid
                    st.session_state['pending_page'] = '案件・対応履歴'
                    st.rerun()
                except ValueError:
                    st.error('登録できませんでした。内容と案件の状態を確認してください。')
            with st.expander('返信案を編集・差し戻す'):
                with st.form('edit_form_'+cid):
                    memo = st.text_area('社内向けメモ',rev['summary_ja'],height=180,key='edit_memo_'+rev['revision_id'])
                    reply = st.text_area('顧客への返信案',rev['reply_text'],height=280,key='edit_reply_'+rev['revision_id'])
                    reason = st.text_input('変更・差し戻しの理由',key='edit_reason_'+rev['revision_id'])
                    save = st.form_submit_button('変更を保存（新しい版を作成）')
                    reject = st.form_submit_button('差し戻す')
                if save or reject:
                    if not actor.strip() or not reason.strip():
                        st.warning('確認者の氏名と理由を入力してください。')
                    else:
                        try:
                            if save:
                                workspace.save_edit(cid,memo,reply,actor,reason)
                            else:
                                workspace.reject(cid,actor,reason)
                            st.rerun()
                        except ValueError:
                            st.error('保存できませんでした。最新の版を確認してください。')

if page == pages[0]:
    st.header('問い合わせを確認する')
    st.write('依頼内容と返信案を確認し、承認した案件をCRMとフォローに引き継ぎます。')
    chosen = st.selectbox('展示ケースを選択',range(len(samples)),format_func=lambda i: samples[i]['id']+'｜'+samples[i]['title_ja'],key='sample_choice')
    sample = samples[chosen]
    st.caption('検証時に保存した合成サンプルです。原文の日付は当時の想定を保持しています。')
    message = st.text_area('顧客からの問い合わせ（合成データ）',sample['inquiry'],height=230,key='input_'+sample['id'])
    if st.button('保存済みのAPI結果を開く（キー不要）',type='primary',disabled=message!=sample['inquiry']):
        case = workspace.open_sample(sample)
        st.session_state['active_case_id'] = case['case_id']
        st.session_state['selected_source'] = sample['id']
        st.rerun()
    if message != sample['inquiry']:
        st.info('原文を変更した場合、保存済み結果は使えません。新しい原文はAPIで分析してください。')
    with st.expander('入力した原文をAPIで分析する（任意・有料）'):
        ready = bool(st.session_state.get('public_key','').strip()) and st.session_state.get('api_attempts',0)<3
        if st.button('APIで分析し、返信案を作成',disabled=not ready):
            st.session_state.api_attempts = st.session_state.get('api_attempts',0)+1
            try:
                from inquiryflow.service import analyze, generate_response_draft, save_run
                with st.spinner('問い合わせを分析し、返信案を作成しています…'):
                    a = analyze(message,st.session_state.public_key,st.session_state.public_model)
                    save_run(a,directory=workspace.root/'runs')
                    if not a.get('output') or not a.get('decision'):
                        raise ValueError('analysis failed')
                    d = generate_response_draft(message,a['output'],a['retrieval'],a['decision'],st.session_state.public_key,st.session_state.public_model,source_analysis_run_id=a['run_id'])
                    save_run(d,directory=workspace.root/'runs')
                    case = workspace.open_live(a,d)
                st.session_state.active_case_id = case['case_id']
                st.session_state.selected_source = 'live'
                st.rerun()
            except Exception:
                st.error('API処理が完了しませんでした。キー・モデル・利用枠を確認してください。保存済みの例は引き続き利用できます。')
        st.caption('この接続では最大3回まで。ボタンを押したときだけ呼び出し、失敗時の自動再試行は行いません。')
    cid = st.session_state.get('active_case_id')
    if cid and workspace.case(cid)['inquiry']==message:
        case = workspace.case(cid)
        st.markdown(case_heading_html(case,workspace.snapshot(cid)),unsafe_allow_html=True)
        source_run=case.get('source_run_id','')
        source=source_run.split('public-sample:',1)[1] if source_run.startswith('public-sample:') else 'live'
        if source=='live':
            st.info('今回のAPIで作成した結果です。担当者の承認前に送信・登録しません。')
        else:
            st.markdown('<span class="chip">保存済みAPI結果</span><span class="chip">展示用の編集あり</span><span class="chip">未送信</span>',unsafe_allow_html=True)
        review_ui(case)
        with st.expander('抽出データ・引用元・元のAPI出力'):
            st.json(case['extraction'])
            original = next((s for s in samples if s['id']==source),None)
            if original:
                st.write('使用したモデルとバージョン')
                st.json(original['provenance'])
                st.write('編集前のAPI出力（保存時のまま）')
                st.json(original['draft']['output'])

elif page == pages[1]:
    st.header('案件・対応履歴')
    cases = workspace.cases()
    labels={c['case_id']:case_state(c,workspace.snapshot(c['case_id']))[0] for c in cases}
    metrics=[('承認待ち',sum(v=='承認待ち' for v in labels.values())),('フォロー中',sum(v in ('フォロー中','案件の完了待ち') for v in labels.values())),('対応完了',sum(v=='対応完了' for v in labels.values())),('担当者が分割',sum(v=='担当者が分割' for v in labels.values()))]
    st.markdown('<div class="record-stats">'+''.join('<div><span>'+label+'</span><b>'+str(count)+'</b></div>' for label,count in metrics)+'</div>',unsafe_allow_html=True)
    if not cases:
        st.info('この接続の案件はまだありません。問い合わせ対応で例を開いてください。')
        st.button('問い合わせ対応へ →',on_click=move,args=(pages[0],))
    else:
        focus=st.session_state.pop('pending_case_id',None)
        if focus or 'case_status_filter' not in st.session_state:
            st.session_state.case_status_filter='すべて'
        status_filter=st.pills('案件の状態',['すべて','承認待ち','フォロー中','対応完了','担当者が分割'],key='case_status_filter') or 'すべて'
        filtered=[c for c in cases if status_filter=='すべて' or labels[c['case_id']]==status_filter or (status_filter=='フォロー中' and labels[c['case_id']]=='案件の完了待ち')]
        if not filtered:
            st.info('この状態の案件はありません。上の条件を「すべて」にすると一覧に戻れます。')
            st.stop()
        ids = [c['case_id'] for c in sorted(filtered,key=lambda c:c['created_at'],reverse=True)]
        if st.session_state.get('active_case_id') not in ids:
            st.session_state.active_case_id=ids[0]
        if focus in ids or st.session_state.get('record_case_picker') not in ids:
            st.session_state.record_case_picker=focus if focus in ids else st.session_state.active_case_id
        lookup = {c['case_id']:c for c in cases}
        cid=st.selectbox('開く案件を選択',ids,key='record_case_picker',format_func=lambda c: lookup[c]['display_id']+'｜'+labels[c]+'｜'+(lookup[c]['extraction'].get('company_name') or lookup[c]['extraction'].get('product') or '問い合わせ'))
        st.session_state.active_case_id=cid
        case=workspace.case(cid)
        snap=workspace.snapshot(cid)
        st.markdown(case_heading_html(case,snap),unsafe_allow_html=True)
        if not snap.get('crm'):
            with st.expander('顧客の原文'):
                st.write(case['inquiry'])
            review_ui(case)
        else:
            crm=snap['crm']
            next_label='この案件の対応は完了しています。' if case['status']=='CLOSED' else '返信の承認・模擬CRM登録が完了しました。次はフォローアップを確認します。'
            st.markdown('<div class="statusbar">'+next_label+'</div>',unsafe_allow_html=True)
            with st.container(border=True,key='crm_panel'):
                st.subheader('CRM・案件情報')
                fields=[('会社',crm.get('company_name')),('商品',crm.get('product')),('配送先',{'TW':'台湾','HK':'香港'}.get(crm.get('country'),crm.get('country'))),('担当者',crm.get('owner'))]
                if crm.get('intent')=='Sales':
                    fields.append(('商談状況',{'NEW':'受付済み','QUALIFYING':'条件を確認中','QUOTING':'見積準備中','NEGOTIATION':'商談中','WON':'受注','LOST':'見送り'}.get(crm.get('sales_stage'),'確認中')))
                fields.append(('優先度',{'HIGH':'優先対応','NORMAL':'通常','LOW':'低','NEEDS_INFO':'情報確認が必要'}.get(crm.get('priority'),'未設定')))
                st.markdown(facts_html(fields),unsafe_allow_html=True)
                st.caption('CRM参照番号：'+str(crm.get('display_id','—'))+' ／ この画面内の模擬登録です。')
            extracted_fields(case)
            summary(case)
            with st.expander('承認した返信・顧客の原文'):
                st.markdown(reply_html(current_revision(case)['reply_text']),unsafe_allow_html=True)
                st.divider()
                st.write(case['inquiry'])
            with st.expander('進捗・担当者を変更'):
                with st.form('owner_'+cid):
                    owner=st.text_input('新しい担当者',value=crm.get('owner') or '')
                    statuses={'TODO':'未着手','IN_PROGRESS':'対応中','WAITING_CUSTOMER':'顧客の返信待ち','WAITING_INTERNAL':'社内確認中','FOLLOW_UP_DUE':'フォロー予定','OVERDUE':'期限超過'}
                    open_tasks=[t for t in snap.get('tasks',[]) if t.get('task_status')!='COMPLETED']
                    current_status=(open_tasks[0].get('track_status') if open_tasks else 'TODO') or 'TODO'
                    options=list(statuses)
                    track=st.selectbox('フォローの状態',options,index=options.index(current_status) if current_status in options else 0,format_func=lambda v:statuses[v],disabled=not open_tasks)
                    sales_stage=None
                    if crm.get('intent')=='Sales':
                        stages={'NEW':'受付済み','QUALIFYING':'条件を確認中','QUOTING':'見積準備中','NEGOTIATION':'商談中','WON':'受注','LOST':'見送り'}
                        stage_options=list(stages)
                        sales_stage=st.selectbox('商談状況',stage_options,index=stage_options.index(crm.get('sales_stage')) if crm.get('sales_stage') in stages else 0,format_func=lambda v:stages[v])
                    tracking_reason=st.text_input('変更メモ（任意）')
                    update=st.form_submit_button('進捗・担当者を保存',disabled=case['status']=='CLOSED')
                if update and owner.strip():
                    workspace.update_tracking(cid,crm.get('owner') or 'デモ担当者',owner.strip(),track if open_tasks else None,sales_stage,tracking_reason)
                    st.rerun()
            st.subheader('フォローアップ')
            for task in snap.get('tasks',[]):
                with st.container(border=True):
                    task_status={'TODO':'未着手','IN_PROGRESS':'対応中','WAITING_CUSTOMER':'顧客の返信待ち','WAITING_INTERNAL':'社内確認中','FOLLOW_UP_DUE':'フォロー予定','OVERDUE':'期限超過','COMPLETED':'完了'}.get(task.get('track_status'),'未着手')
                    st.markdown('<span class="chip">'+html.escape(task.get('display_id','タスク'))+'</span><span class="chip">'+task_status+'</span>',unsafe_allow_html=True)
                    st.write(followup_title(task,case,'ja'))
                    st.write('期限：'+format_date(task.get('due_at'))+'　担当者：'+str(task.get('owner') or '未設定'))
                    done=task.get('task_status')=='COMPLETED'
                    if done:
                        st.success('完了')
                    elif st.button('このフォローを完了',key='task_'+task['task_id']):
                        workspace.complete(task['task_id'],crm.get('owner') or 'デモ担当者')
                        st.rerun()
            can_close=all(t.get('task_status')=='COMPLETED' for t in snap.get('tasks',[]))
            if case['status']=='CLOSED':
                st.success('案件は完了しています。')
            elif st.button('案件を完了',disabled=not can_close):
                workspace.close(cid,crm.get('owner') or 'デモ担当者')
                st.rerun()
        with st.expander('変更・承認履歴を見る'):
            st.json({'revisions':case['revisions'],'reviews':case['reviews']})
        st.download_button('この接続の操作記録をダウンロード',json.dumps(workspace.export(),ensure_ascii=False,indent=2),file_name='inquiryflow-demo-records.json',mime='application/json')

elif page==pages[2]:
    st.header('ナレッジ・ルール')
    st.write('AIは問い合わせを整理し、参照資料とルールに沿って返信案を作ります。価格・在庫・納期の実データは接続していません。')
    st.subheader('承認・登録のルール')
    st.write('• 返信案は担当者が確認して承認します。メールは送信しません。\n\n• 承認した版に対してCRMとフォローを1回だけ作成します。\n\n• 複数商品・配送先など、現在の形式で扱えない案件は自動登録を止めます。\n\n• 根拠が不足する場合、価格・輸出可否・到着日は確約しません。')
    _,documents=load_knowledge()
    for doc in documents:
        if doc['status']!='active' or doc.get('authority')=='untrusted':
            continue
        translated,_=translated_document(doc,'ja')
        with st.expander(translated['title']+'｜v'+str(doc['version'])):
            st.caption(doc['document_id']+'｜合成資料・デモ用の社内規定')
            for chunk in translated['chunks']:
                st.write(chunk.get('title',''))
                st.write(chunk['content'])

else:
    st.header('検証と改善')
    st.write('システムのテスト記録です。何が問題で、どう直し、何を再確認したかをまとめています。')
    evidence=json.loads((SAMPLE_DIR/'iteration_evidence.json').read_text())
    with st.container(border=True):
        st.subheader('実際の改善例｜見積資料を見つけられなかった')
        st.markdown('<span class="chip danger">修正前：資料が見つからない</span> → <span class="chip">修正後：見積手順の資料を取得</span>',unsafe_allow_html=True)
        st.write('同じ日本語メールで再テスト。原文の理解だけでなく、参照すべき見積手順を検索できることまで確認しました。')
        with st.expander('修正前後の記録・使用したバージョン'):
            st.table([{'比較':'修正前','検索の版':evidence['before']['retrieval_version'],'結果':evidence['before']['retrieval_status']}, {'比較':'修正後','検索の版':evidence['after']['retrieval_version'],'結果':evidence['after']['retrieval_status']}])
            st.write(evidence['scope_ja'])
            st.json(evidence)
    for title,before,change,limit in [
        ('01A｜見積依頼の資料検索','長い日本語メールで見積手順の資料が検索候補から外れた。','見積に関する表現と文書本文の一致を見直し、同じ入力で資料が取得できることを再確認。','商品カタログ・実在庫・船期は未接続。'),
        ('04A｜破損対応の確認','写真・費用負担・発送可否の確認が混ざり、返信が不自然になった。','証拠の確認と社内の判断を分け、無料補送や発送日を先に約束しない文面に修正。','実際の注文・配送履歴は照会していない。'),
        ('06A｜商品と配送先が2組ある依頼','単一商品の形式では、商品と配送先を正しく分けて登録できない。','数量・配送先を原文と返信に残し、自動登録を止める。','安全に止められても、自動処理が完了したことにはならない。')]:
        with st.container(border=True):
            st.subheader(title)
            st.write('発見した問題：'+before)
            st.write('対応：'+change)
            st.write('残る制約：'+limit)
    with st.expander('画面操作の修正｜案件一覧からの承認エラー'):
        st.write('問題：案件一覧から承認すると、選択中の案件と選択欄が同じ保存先を使い、画面処理が中断していました。')
        st.write('修正：案件データの選択状態と画面部品の状態を分離。問い合わせ画面・案件一覧の両方から承認する回帰テストを追加しました。')
        st.caption('これは画面と処理の検証です。AIの回答精度とは別に扱います。')
    st.subheader('手作業との比較条件')
    st.write('自己申告の作業時間は01Aが12分34秒、04Aが6分02秒、06Aが4分42秒。文章の作成条件が揃った厳密な比較実験ではありません。外部への確認待ち・CRM入力・追跡設定は含まれず、API生成時間だけで削減率は計算していません。')
    with st.expander('保存済みAPI結果の出所・バージョン'):
        for sample in samples:
            st.write(sample['id'])
            st.json(sample['provenance'])
    with st.expander('開発中のテスト記録について'):
        st.write('D8・D9の完全な原始出力、失敗記録、採点と再テスト記録は開発用の本機版で保管しています。公開版には3つの合成例と改善の証拠を抜粋しています。日常業務の承認履歴とは分けて管理します。')
        st.download_button('公開用の改善記録をダウンロード',json.dumps(evidence,ensure_ascii=False,indent=2),file_name='inquiryflow-improvement-evidence.json',mime='application/json')
    st.caption('この公開デモの3例は既知のケースです。未見の保留テストとして扱いません。')
