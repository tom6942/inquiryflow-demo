"""Small deterministic retriever for the synthetic Day 4 knowledge base."""
from __future__ import annotations

import json
import math
import re
import unicodedata
from copy import deepcopy
from collections import Counter
from pathlib import Path
from .knowledge_i18n import translated_document

ROOT = Path(__file__).resolve().parents[1]
KNOWLEDGE_DIR = ROOT / "data" / "knowledge"
TOP_K = 3
MIN_SCORE = 0.12
RETRIEVAL_VERSION = "retrieval-1.7"

REQUEST_QUERY_TERMS = {
    "new_purchase": "purchase sales product 商品 採購",
    "pricing": "price quotation pricing 價格 報價 詢價 見積",
    "export_eligibility": "export eligibility ship overseas 出口 輸出",
    "delivery_timing": "delivery timing 交貨 納期",
    "general_info": "",
    "existing_order_issue": "support order damage delivery 售後 訂單 破損",
    "other": "other 其他",
}


def _normalise(text: str) -> str:
    return unicodedata.normalize("NFKC", text).lower()


def _tokens(text: str) -> set[str]:
    text = _normalise(text)
    tokens = set(re.findall(r"[a-z][a-z0-9_-]+", text))
    for pattern, concept in (
        (r"納品|納期|到着|受け取|交貨|到貨|delivery", "delivery"),
        (r"購入|採購|購買|purchase", "purchase"),
        (r"見積|報價|詢價|quotation", "quotation"),
    ):
        if re.search(pattern, text):
            tokens.add(concept)
    for run in re.findall(r"[\u3400-\u9fff\u3040-\u30ff]+", text):
        if len(run) == 1:
            tokens.add(run)
        else:
            tokens.update(run[i:i + 2] for i in range(len(run) - 1))
    # Japanese grammatical endings shared by unrelated documents are not topics.
    return {token for token in tokens if not re.fullmatch(r"[\u3040-\u309f]{2}", token)}


def load_knowledge(directory: Path = KNOWLEDGE_DIR) -> tuple[dict, list[dict]]:
    manifest = json.loads((directory / "manifest.json").read_text())
    documents = []
    seen = set()
    for filename in manifest["documents"]:
        path = (directory / filename).resolve()
        if path.parent != directory.resolve():
            raise ValueError("Knowledge manifest path must stay inside data/knowledge")
        doc = json.loads(path.read_text())
        key = (doc["document_id"], doc["version"])
        if key in seen:
            raise ValueError("Duplicate knowledge document version")
        seen.add(key)
        if not doc["is_synthetic"]:
            raise ValueError("This demo knowledge base accepts synthetic data only")
        if not doc["chunks"] or any(not c["content"].strip() for c in doc["chunks"]):
            raise ValueError("Every knowledge document needs non-empty chunks")
        documents.append(doc)
    # Multiple versions remain in the manifest for reproducibility. Only the
    # newest active trusted version is eligible for current retrieval.
    grouped = {}
    for doc in documents:
        grouped.setdefault(doc["document_id"], []).append(doc)
    resolved = []
    for versions in grouped.values():
        active_trusted = [d for d in versions if d["status"] == "active" and d["authority"] != "untrusted"]
        newest = max(active_trusted, key=lambda d: _version_key(d["version"])) if active_trusted else None
        for doc in versions:
            current = deepcopy(doc)
            if newest and doc is not newest and doc["status"] == "active" and doc["authority"] != "untrusted":
                current["status"] = "superseded"
            resolved.append(current)
    return manifest, resolved


def _version_key(version: str) -> tuple[int, ...]:
    if not re.fullmatch(r"\d+(?:\.\d+)*", version):
        raise ValueError("Knowledge document versions must be numeric, such as 1.0")
    return tuple(int(part) for part in version.split("."))


def build_query(message: str, extraction: dict | None = None) -> str:
    # Explicitly delimited historical mail is provenance, not the active query.
    active = re.sub(r"---\s*QUOTED EMAIL[^\n]*---.*?---\s*END QUOTE\s*---", "", message,
                    flags=re.I | re.S)
    parts = [active]
    if extraction:
        parts.extend(filter(None, [
            extraction.get("product"), extraction.get("product_name_zh"),
            extraction.get("country"), extraction.get("support", {}).get("description"),
        ]))
        parts.extend(REQUEST_QUERY_TERMS[x] for x in extraction.get("request_types", []) if x in REQUEST_QUERY_TERMS)
    return " ".join(parts)


def _search_rows(documents: list[dict]) -> list[dict]:
    rows = []
    for doc in documents:
        # Superseded versions remain in the manifest for audit and comparison,
        # but they are not current evidence and must not create a false conflict.
        if doc["status"] == "superseded":
            continue
        metadata = " ".join(doc["topics"] + doc["keywords"] + doc["answerable_questions"])
        japanese, translated = translated_document(doc, "ja")
        japanese_chunks = {chunk["chunk_id"]: chunk for chunk in japanese["chunks"]} if translated else {}
        for chunk in doc["chunks"]:
            search_text = " ".join([doc["title"], metadata, chunk["title"], chunk["content"]])
            if chunk["chunk_id"] in japanese_chunks:
                ja = japanese_chunks[chunk["chunk_id"]]
                search_text += " " + " ".join([japanese["title"], ja["title"], ja["content"]])
            body_text = chunk["content"] + " " + japanese_chunks.get(chunk["chunk_id"], {}).get("content", "")
            rows.append({"doc": doc, "chunk": chunk, "tokens": _tokens(search_text), "search_text": _normalise(search_text), "body_text": body_text})
    return rows


# Topic evidence is matched against clause content, never document metadata alone.
# This is a bounded verifier for the supported FAQ topics, not universal entailment.
TOPIC_RULES = {
    "damage_remedy": (r"(?:破損|割れ|damaged|broken).*(?:補寄|再送|交換|退款|refund|replac)|(?:補寄|再送|交換|退款|refund|replac).*(?:破損|割れ|damaged|broken)", r"補寄|再送|退款|返金|refund|replacement"),
    "damage_evidence": (r"破損|破損|割れ|damaged|broken|breakage", r"(?:破損|割れ|damage|broken).*(?:照片|写真|證據|証拠|evidence|photo)|(?:照片|写真|evidence|photo).*(?:破損|割れ|damage|broken)"),
    "product_types": (r"(?:類型|種類|types?|kinds?|varieties|categories).*(?:日本酒|酒|sake|products?)|(?:日本酒|酒|sake|products?).*(?:類型|種類|types?|kinds?|varieties|categories)",
                      r"(?:包含|包括|種類は|types? include).*(?:純米|吟釀|吟醸|junmai)|純米酒.*吟釀酒"),
    "response_target": (r"(?:response|reply|acknowledg|回覆|返信|回答|受領).*(?:target|business.day|目標|営業日|工作日)|(?:business.day|営業日|工作日).*(?:target|response|reply|回覆|返信|回答)",
                        r"(?:工作日|営業日|business.day).*(?:確認已收到|受領|acknowledg)|(?:收件|受領|acknowledg).*(?:目標|target|営業日)"),
    "minimum_order": (r"minimum.{0,25}(?:order|quantity|cases?|bottles?)|\bMOQ\b|最低.{0,8}(?:訂量|注文|数量|量|ケース|箱)",
                      r"最低.{0,8}(?:訂量|注文|数量|量).{0,12}\d+|minimum.{0,20}(?:order|quantity).{0,12}\d+"),
    "business_hours": (r"business hours|weekday.*hours|営業時間|受付時間|營業時間|受理時間|営業時間|open on|hours.*weekend",
                       r"(?:受理時間|受付時間|営業時間|business hours).{0,60}\d{1,2}[:：]\d{2}"),
}

def question_topics(message):
    return {name for name,(query,_) in TOPIC_RULES.items() if re.search(query,message,re.I|re.S)}

def supported_topics(body, requested):
    return {name for name in requested if re.search(TOPIC_RULES[name][1],body,re.I|re.S)}


def retrieve(message: str, extraction: dict | None = None, top_k: int = TOP_K, min_score: float = MIN_SCORE,
             directory: Path = KNOWLEDGE_DIR) -> dict:
    if not message.strip():
        raise ValueError("Retrieval query cannot be blank")
    if not 1 <= top_k <= 10:
        raise ValueError("top_k must be between 1 and 10")
    manifest, documents = load_knowledge(directory)
    rows = _search_rows(documents)
    requested_topics = question_topics(message)
    query = build_query(message, extraction)
    query_tokens = _tokens(query)
    document_frequency = Counter(token for token in query_tokens for row in rows if token in row["tokens"])
    weights = {token: math.log((len(rows) + 1) / (document_frequency[token] + 1)) + 1 for token in query_tokens}
    denominator = sum(weights.values()) or 1.0
    candidates = []
    for row in rows:
        overlap = query_tokens & row["tokens"]
        score = sum(weights[token] for token in overlap) / denominator
        # Prefer clauses about requested delivery conditions over incidental
        # mentions in document-wide metadata or follow-up reminder schedules.
        if re.search(r"納品|納期|受け取|交期|到貨|deliver", message, re.I) and re.search(
            r"交期|納期|希望到貨|希望到着|delivery date", row["body_text"], re.I
        ):
            score = min(1.0, score + 0.1)
        # A long Japanese mail dilutes lexical overlap with procedural clauses.
        # Rank relevant quotation-process content, without treating it as proof
        # of an actual price or of complete answer coverage.
        if (re.search(r"見積", message) and re.search(r"依頼|お願い|希望|ご検討", message)
                and re.search(r"見積|報價", row["body_text"])
                and re.search(r"確認|必要", row["body_text"])):
            score = min(1.0, score + 0.15)
        topic_support = supported_topics(row["body_text"], requested_topics)
        if topic_support:
            score = min(1.0, score + 0.30 * len(topic_support))
        if score < min_score:
            continue
        doc, chunk = row["doc"], row["chunk"]
        candidates.append({
            "document_id": doc["document_id"], "document_version": doc["version"],
            "chunk_id": chunk["chunk_id"], "title": doc["title"], "chunk_title": chunk["title"],
            "excerpt": chunk["content"], "source_type": doc["source_type"],
            "is_synthetic": doc["is_synthetic"], "status": doc["status"],
            "authority": doc["authority"], "valid_from": doc["valid_from"],
            "score": round(score, 4),
            "citation": f'{doc["document_id"]}@{doc["version"]}#{chunk["chunk_id"]}',
        })
    candidates.sort(key=lambda x: (-x["score"], x["document_id"], x["chunk_id"]))
    eligible = [x for x in candidates if x["status"] == "active" and x["authority"] in {"internal_reference", "internal_policy"}]
    excluded = [x for x in candidates if x not in eligible]
    hits = eligible[:top_k]
    # A topical match is not evidence that the requested subtopic is covered.
    weekend_requested = bool(re.search(r"weekends?|saturdays?|sundays?|週末|周末|週六|週日|土日|土曜|日曜", message, re.I))
    hours_requested = bool(re.search(r"hours?|open|營業|受理|営業時間|営業日", message, re.I))
    weekend_supported = any(re.search(r"weekends?|saturdays?|sundays?|週末|週六|週日|土日|土曜|日曜", hit["excerpt"], re.I) for hit in hits)
    scope_missing = ["weekend_business_hours"] if weekend_requested and hours_requested and not weekend_supported else []
    if excluded:
        status = "REVIEW_REQUIRED"
        reason = "找到過期或不可信的相關片段；它們已排除，不可作為答案或指令。"
    elif hits:
        status = "FOUND"
        reason = "找到可供人工核對的合成來源；檢索命中不代表已能對外承諾。"
    else:
        status = "NO_MATCH"
        reason = "找不到足以支持回答的知識來源，請轉人工確認，不可自行補寫答案。"
    covered_topics = set().union(*(supported_topics(h["excerpt"],requested_topics) for h in hits)) if hits else set()
    missing_topics = sorted(requested_topics-covered_topics) + scope_missing
    coverage = "PARTIAL" if missing_topics else "VERIFIED" if requested_topics else "NOT_VERIFIED"
    questions=[part.strip() for part in re.split(r'[?？;；\n]',message) if part.strip()]
    uncovered_question=any(re.search(r'^(?:what|which|how|when|where|do you|can you|are you|will you)|(?:嗎|ですか|ますか)$',part,re.I) and not question_topics(part) for part in questions)
    if uncovered_question:
        coverage="NOT_VERIFIED"
        missing_topics.append("additional_question_not_verified")
    return {
        "retrieval_version": RETRIEVAL_VERSION,
        "knowledge_base": manifest["knowledge_base"], "knowledge_version": manifest["version"],
        "original_query": message, "query": query, "top_k": top_k, "min_score": min_score,
        "status": status, "reason": reason, "hits": hits,
        "excluded_hits": excluded[:top_k],
        "answer_coverage": {"status": coverage,
                            "requested_topics": sorted(requested_topics), "covered_topics": sorted(covered_topics),
                            "missing_topics": missing_topics,
                            "note": "週末營業資訊未在命中來源明載。" if scope_missing else "命中仍需核對是否逐項支持答案。"},
    }
