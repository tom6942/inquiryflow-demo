"""Free deterministic Day 5 draft preview.

This is deliberately conservative. It demonstrates the workflow and language
selection without an API call, while every outbound draft remains pending
human review.
"""
from __future__ import annotations

from typing import Literal
from pydantic import ConfigDict, BaseModel, field_validator

from .presentation import quantity_text, timeline_text

DRAFT_TEMPLATE_VERSION = "draft-preview-0.4"


class DraftPackage(BaseModel):
    """Strict contract for an API-generated Day 5 draft."""
    model_config = ConfigDict(extra="forbid", strict=True)

    internal_summary_ja: str
    reply_language: Literal["zh-TW", "en", "ja"]
    customer_reply: str
    clarifying_questions: list[str]
    source_citations: list[str]
    commitment_warnings: list[str]

    @field_validator("internal_summary_ja", "customer_reply")
    @classmethod
    def not_blank(cls, value):
        if not value.strip():
            raise ValueError("summary and reply cannot be blank")
        return value

    @field_validator("source_citations")
    @classmethod
    def unique_citations(cls, value):
        if len(value) != len(set(value)):
            raise ValueError("source citations cannot repeat")
        return value


def _customer_language(extraction: dict, decision: dict) -> str:
    selected = decision.get("reply_language")
    if selected in {"zh-TW", "en", "ja"}:
        return selected
    language = extraction.get("language", "other")
    return language if language in {"zh-TW", "en", "ja"} else "zh-TW"


def _internal_summary_ja(extraction: dict, decision: dict) -> str:
    intent = extraction["intent"]
    product = extraction.get("product") or "商品未確認"
    quantity = quantity_text(extraction["purchase_quantity"], "ja")
    company = extraction.get("company_name") or extraction.get("company_description") or "会社名未確認"
    support = extraction.get("support", {})
    has_support = extraction.get("intent") == "Support" or "existing_order_issue" in extraction.get("request_types", [])
    has_purchase = "new_purchase" in extraction.get("request_types", [])
    if has_support:
        order_id = support.get("order_id") or "注文番号未確認"
        affected = quantity_text(support["affected_quantity"], "ja").replace(" ", "")
        purchase_quantity = quantity.replace(" ", "")
        purchase_note = f"別件として{product}を{purchase_quantity}追加購入希望あり。" if has_purchase else ""
        return (
            f"注文{order_id}の{affected}破損に関する問い合わせを優先対応。"
            f"{purchase_note}まず破損状況と証拠資料を確認する。"
            + ("その後に購入相談を営業へ引き継ぐ。" if has_purchase else "")
            + f"優先度は{decision['priority']}。"
        )
    request_labels = {
        "new_purchase": "新規購入", "pricing": "価格確認", "export_eligibility": "輸出可否確認",
        "delivery_timing": "納期確認", "general_info": "一般情報", "other": "その他",
    }
    requests = "、".join(request_labels.get(x, x) for x in extraction.get("request_types", [])) or "未判定"
    return (
        f"{company}からの{intent}問い合わせ。商品は{product}、新規購入数量は{quantity}。"
        f"要望は{requests}。優先度は{decision['priority']}。"
        f"推奨対応：{decision['recommended_action']['label_ja']}。"
    )


def _questions(decision: dict, language: str) -> list[str]:
    key = "question_ja" if language == "ja" else "question_zh"
    return [item[key] for item in decision["missing_information"]]


def preview_draft(message: str, extraction: dict, retrieval: dict, decision: dict) -> dict:
    """Return a visible preview; never sends, approves or calls an API."""
    language = _customer_language(extraction, decision)
    citations = [hit["citation"] for hit in retrieval.get("hits", [])]
    if decision["external_draft_blocked"]:
        return {
            "template_version": DRAFT_TEMPLATE_VERSION,
            "status": "BLOCKED",
            "internal_summary_ja": _internal_summary_ja(extraction, decision),
            "reply_language": language,
            "customer_reply": None,
            "clarifying_questions": [],
            "source_citations": [],
            "notice_zh": "已直接阻擋，不建立人工待辦或對外草稿。" if decision["human_in_loop"]["mode"] == "BLOCKED" else "原文有安全風險標記；不產生對外草稿，先交人工核對。",
            "notice_ja": "自動ブロック済み。人の対応待ち・対外返信案は作成しません。" if decision["human_in_loop"]["mode"] == "BLOCKED" else "原文にリスク表示があるため、対外返信案を作成せず人が確認します。",
        }

    questions = _questions(decision, language)
    has_support = extraction.get("intent") == "Support" or "existing_order_issue" in extraction.get("request_types", [])
    has_purchase = "new_purchase" in extraction.get("request_types", [])
    support_fields = [x for x in decision["missing_information"] if x["field"].startswith("support.")]
    sales_fields = [x for x in decision["missing_information"] if not x["field"].startswith("support.")]
    if has_support and language == "en":
        support = extraction["support"]
        order_id = support.get("order_id") or "your order"
        affected = quantity_text(support["affected_quantity"], "zh-TW").replace(" 瓶", " bottles")
        lines = [
            f"We’re sorry to hear that {affected.lower()} from order {order_id} arrived damaged.",
            "To investigate the damage, please send us:",
        ]
        support_labels = {
            "support.product": "the damaged product name, specification, or SKU",
            "support.photos": "photos of the damaged bottles and outer packaging",
            "support.received_date": "the delivery date",
            "support.order_id": "the order number",
            "support.description": "details of what happened",
            "support.affected_quantity": "the affected quantity and unit",
        }
        support_questions_en = [support_labels.get(item['field'], item['field']) for item in support_fields]
        lines += [f"- {question}" for question in support_questions_en]
        lines.append("Our support team will review the order and evidence before confirming any replacement, refund, or other remedy.")
        if has_purchase:
            purchase = quantity_text(extraction["purchase_quantity"], "zh-TW").replace(" 瓶", " bottles")
            lines += [
                "",
                f"Separately, we have also noted your request to purchase another {purchase.lower()} of {extraction.get('product') or 'sake'}.",
                "After the damage claim has been addressed, our sales team can follow up on the new purchase. To prepare for that discussion, please share:",
            ]
            english_sales = {
                "company_name": "your company’s legal name", "product": "the requested product or specification",
                "purchase_quantity": "the planned quantity and unit", "budget": "your budget range and currency",
                "preferred_delivery_date": "your preferred delivery date", "destination_country": "the destination country or region",
                "importer_arrangement": "the local importer and alcohol import licence arrangements",
            }
            sales_questions_en = [english_sales.get(item['field'], item['field'].replace('_', ' ')) for item in sales_fields]
            lines += [f"- {question}" for question in sales_questions_en]
        else:
            sales_questions_en = []
        questions = support_questions_en + sales_questions_en
        lines.append("Thank you for your cooperation.")
    elif language == "ja":
        lines = ["お問い合わせありがとうございます。内容を確認し、担当者よりご連絡いたします。"]
        if questions:
            lines += ["確認のため、次の情報をご共有ください。"] + [f"・{q}" for q in questions]
        if decision["retrieval_status"] == "PARTIAL":
            lines.append("確認できる出典には週末の受付時間が明記されていません。担当者が週末の対応を確認します。")
        elif decision["retrieval_status"] != "FOUND":
            lines.append("現時点では確認できる資料が不足しているため、回答内容を担当者が確認します。")
        else:
            lines.append("価格、輸出可否、納期などの条件は、最新情報を確認してからご案内します。")
        lines.append("よろしくお願いいたします。")
    elif language == "en":
        lines = ["Thank you for your inquiry. Our team will review the details and contact you."]
        if questions:
            labels = [item["field"].replace("_", " ") for item in decision["missing_information"]]
            lines += ["Please provide the following information:"] + [f"- {q}" for q in labels]
        if decision["retrieval_status"] == "PARTIAL":
            lines.append("The available source does not specify weekend business hours. A team member will confirm the weekend arrangements.")
        elif decision["retrieval_status"] != "FOUND":
            lines.append("We do not yet have sufficient verified information, so a team member will confirm the answer.")
        else:
            lines.append("We will confirm current pricing, export eligibility, and delivery conditions before making any commitment.")
        lines.append("Best regards,")
    else:
        lines = ["感謝您的詢問。我們已收到內容，將由負責人核對後與您聯絡。"]
        if questions:
            lines += ["為了進一步確認，請補充以下資訊："] + [f"・{q}" for q in questions]
        if decision["retrieval_status"] == "PARTIAL":
            lines.append("目前來源沒有明載週末受理時間，將由負責人補查週末安排後回覆。")
        elif decision["retrieval_status"] != "FOUND":
            lines.append("目前可查證的資料不足，我們會先由人工確認，不會直接提供未確認的結論。")
        else:
            lines.append("價格、出口可否與交期等條件，將以負責人確認後的最新資訊為準。")
        lines.append("謝謝。")

    return {
        "template_version": DRAFT_TEMPLATE_VERSION,
        "status": "PENDING_HUMAN_REVIEW",
        "internal_summary_ja": _internal_summary_ja(extraction, decision),
        "reply_language": language,
        "customer_reply": "\n".join(lines),
        "clarifying_questions": questions,
        "source_citations": citations,
        "notice_zh": "這是零 API 費用的規則模板預覽；尚未核准，也沒有寄出。",
        "notice_ja": "APIを使わないルールテンプレートのプレビューです。未承認で、送信もしていません。",
    }
