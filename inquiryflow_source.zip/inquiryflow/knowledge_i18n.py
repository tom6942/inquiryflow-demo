"""Version-bound display translations for the synthetic knowledge base."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path


TRANSLATIONS_PATH = Path(__file__).resolve().parents[1] / "data" / "knowledge" / "translations_ja.json"


@lru_cache(maxsize=1)
def _translations() -> dict:
    return json.loads(TRANSLATIONS_PATH.read_text(encoding="utf-8"))["documents"]


def translated_document(document: dict, locale: str) -> tuple[dict, bool]:
    """Return display text without changing the Chinese source document."""
    if locale != "ja":
        return document, True
    translated = _translations().get(f'{document["document_id"]}@{document["version"]}')
    if not translated:
        return document, False
    chunks = []
    for chunk in document["chunks"]:
        text = translated.get("chunks", {}).get(chunk["chunk_id"])
        chunks.append({**chunk, **(text or {})})
    return {
        **document,
        "title": translated["title"],
        "answerable_questions": translated.get("answerable_questions", []),
        "chunks": chunks,
    }, True


def translated_hit(hit: dict, locale: str) -> tuple[dict, bool]:
    if locale != "ja":
        return hit, True
    translated = _translations().get(f'{hit["document_id"]}@{hit["document_version"]}')
    chunk = translated and translated.get("chunks", {}).get(hit["chunk_id"])
    if not translated or not chunk:
        return hit, False
    return {
        **hit,
        "title": translated["title"],
        "chunk_title": chunk["title"],
        "excerpt": chunk["content"],
    }, True
