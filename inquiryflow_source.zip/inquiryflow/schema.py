from datetime import date
import re
from typing import Literal
from pydantic import BaseModel, ConfigDict, model_validator, field_validator

SCHEMA_VERSION = "extraction-0.5"
RULES_VERSION = "rules-0.7"

class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

class Quantity(StrictModel):
    min: int | None
    max: int | None
    unit: Literal["bottle", "case", "other"] | None
    raw: str | None

    @model_validator(mode="after")
    def valid_range(self):
        if any(v is not None and v <= 0 for v in (self.min, self.max)):
            raise ValueError("數量必須是正整數")
        if self.min is not None and self.max is not None and self.min > self.max:
            raise ValueError("數量下限不可高於上限")
        if (self.min is not None or self.max is not None or self.unit is not None) and not self.raw:
            raise ValueError("數量需要原文")
        return self

class Budget(StrictModel):
    status: Literal["not_provided", "undecided", "stated"]
    amount: str | None
    currency: str | None
    raw: str | None

    @model_validator(mode="after")
    def valid_money(self):
        if self.status == "not_provided" and any(v is not None for v in (self.amount, self.currency, self.raw)):
            raise ValueError("未提供預算時金額、幣別及原文應為 null")
        if self.status == "undecided" and (self.amount is not None or self.currency is not None):
            raise ValueError("預算未決定時不應猜測金額或幣別")
        if self.status != "not_provided" and not self.raw:
            raise ValueError("預算狀態需要原文")
        if self.amount is not None:
            import re
            if not re.fullmatch(r"\d+(?:\.\d+)?", self.amount):
                raise ValueError("金額需為非負十進位字串")
        if self.currency is not None and (len(self.currency) != 3 or not self.currency.isascii() or not self.currency.isupper() or not self.currency.isalpha()):
            raise ValueError("幣別需為三碼大寫代號")
        if (self.amount is not None or self.currency is not None) and not self.raw:
            raise ValueError("預算需要原文")
        return self

class Timeline(StrictModel):
    raw: str | None
    date: str | None
    summary_zh: str | None
    missing_parts: list[Literal["year", "month", "day", "exact_date"]]

    @model_validator(mode="after")
    def valid_date(self):
        if self.raw is None and (self.summary_zh is not None or self.missing_parts):
            raise ValueError("沒有交貨期限原文時不產生摘要或缺漏細節")
        if self.raw is not None and (self.summary_zh is None or not self.summary_zh.strip()):
            raise ValueError("交貨期限需提供繁中摘要")
        if len(set(self.missing_parts)) != len(self.missing_parts):
            raise ValueError("日期缺漏不可重複")
        if self.date is None and self.raw is not None and not self.missing_parts:
            raise ValueError("交貨日期不完整時需列出待確認部分")
        if self.date is not None and self.missing_parts:
            raise ValueError("完整日期不能同時標為缺少部分")
        if self.date is not None:
            import re
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", self.date):
                raise ValueError("日期格式錯誤")
            date.fromisoformat(self.date)
            if not self.raw:
                raise ValueError("日期需要原文")
        return self

class Evidence(StrictModel):
    quote: str
    source: Literal["inquiry"]

class EvidenceMap(StrictModel):
    company_name: Evidence | None
    company_description: Evidence | None
    country: Evidence | None
    product: Evidence | None
    purchase_quantity: Evidence | None
    budget: Evidence | None
    timeline: Evidence | None

class SupportEvidence(StrictModel):
    order_id: Evidence | None
    issue: Evidence | None
    affected_quantity: Evidence | None

class SupportIssue(StrictModel):
    order_id: str | None
    issue_type: Literal["damage", "delivery", "other"] | None
    description: str | None
    affected_quantity: Quantity
    field_evidence: SupportEvidence

    @field_validator("order_id", "description")
    @classmethod
    def not_blank(cls, value):
        if value is not None and not value.strip():
            raise ValueError("未知售後資訊請用 null")
        return value

class RiskFlag(StrictModel):
    code: Literal["prompt_injection", "suspected_spam"]
    reason: str
    evidence: Evidence

    @field_validator("reason")
    @classmethod
    def has_reason(cls, value):
        if not value.strip():
            raise ValueError("可疑標記需要理由")
        return value

class LanguageShare(StrictModel):
    code: str
    name_zh: str
    quote: str

    @model_validator(mode="before")
    @classmethod
    def discard_legacy_percentage(cls, value):
        """Read old saved runs without keeping the removed ratio field."""
        if isinstance(value, dict) and "percentage" in value:
            value = {key: item for key, item in value.items() if key != "percentage"}
        return value

    @field_validator("code", "name_zh", "quote")
    @classmethod
    def not_empty(cls, value):
        if not value.strip():
            raise ValueError("語言資料不可為空")
        return value

class Extraction(StrictModel):
    intent: Literal["Sales", "FAQ", "Support", "Other"]
    language: Literal["zh-TW", "en", "ja", "other"]
    languages: list[LanguageShare]
    company_name: str | None
    company_description: str | None
    country: str | None
    product: str | None
    product_name_zh: str | None
    purchase_quantity: Quantity
    support: SupportIssue
    risk_flags: list[RiskFlag]
    budget: Budget
    timeline: Timeline
    request_types: list[Literal["new_purchase", "pricing", "export_eligibility", "delivery_timing", "general_info", "existing_order_issue", "other"]]
    field_evidence: EvidenceMap

    @field_validator("languages")
    @classmethod
    def language_shares(cls, value):
        if not value:
            raise ValueError("至少需要一個主要語言")
        if len({x.code.lower() for x in value}) != len(value):
            raise ValueError("語言不可重複")
        return value

    @model_validator(mode="after")
    def translation_has_source(self):
        if self.product is None and self.product_name_zh is not None:
            raise ValueError("沒有商品原文，不產生中文名稱")
        if self.product is not None and (self.product_name_zh is None or not self.product_name_zh.strip()):
            raise ValueError("商品需提供中文展示名稱；專名可保留")
        return self

    @field_validator("company_name", "company_description", "product")
    @classmethod
    def not_blank(cls, value):
        if value is not None and not value.strip():
            raise ValueError("未知資訊請用 null")
        return value

    @field_validator("country")
    @classmethod
    def country_code(cls, value):
        if value is not None and (len(value) != 2 or not value.isascii() or not value.isalpha() or not value.isupper()):
            raise ValueError("市場需為兩碼大寫代號")
        return value

    @field_validator("request_types")
    @classmethod
    def unique_requests(cls, value):
        if len(set(value)) != len(value):
            raise ValueError("需求類型不可重複")
        return value

    @field_validator("risk_flags")
    @classmethod
    def unique_risks(cls, value):
        if len({item.code for item in value}) != len(value):
            raise ValueError("可疑標記不可重複")
        return value


def validate_input(message: str) -> str:
    if not isinstance(message, str) or not message.strip():
        raise ValueError("請先輸入客戶詢問。")
    if len(message) > 8000:
        raise ValueError("詢問超過 8,000 字元，請先縮短；系統不會自行截斷。")
    return message


def validate_evidence(result: Extraction, message: str) -> None:
    """Check provenance, not semantic correctness: a real quote may still be misread."""
    def quote_supported(quote: str) -> bool:
        if not quote.strip():
            return False
        if quote in message:
            return True
        pieces = [piece.strip() for piece in re.split(r"(?:\.{3,}|…+)", quote) if piece.strip()]
        if len(pieces) < 2:
            return False
        cursor = 0
        for piece in pieces:
            index = message.find(piece, cursor)
            if index < 0:
                return False
            cursor = index + len(piece)
        return True

    for name in EvidenceMap.model_fields:
        evidence = getattr(result.field_evidence, name)
        value = getattr(result, name)
        present = value.raw is not None if name in {"purchase_quantity", "budget", "timeline"} else value is not None
        if present and evidence is None:
            raise ValueError(f"{name} 缺少原文依據")
        if evidence is not None and not quote_supported(evidence.quote):
            raise ValueError(f"{name} 的引句不在原文中")
        if name in {"purchase_quantity", "budget", "timeline"} and value.raw is not None:
            if not value.raw.strip() or value.raw not in message:
                raise ValueError(f"{name} 的原始文字不在原文中")
    support = result.support
    for name, present in {
        "order_id": support.order_id is not None,
        "issue": support.issue_type is not None or support.description is not None,
        "affected_quantity": support.affected_quantity.raw is not None,
    }.items():
        ev = getattr(support.field_evidence, name)
        if present and ev is None:
            raise ValueError(f"support.{name} 缺少原文依據")
        if ev and not quote_supported(ev.quote):
            raise ValueError(f"support.{name} 的引句不在原文中")
    raw = support.affected_quantity.raw
    if raw is not None and (not raw.strip() or raw not in message):
        raise ValueError("售後數量的原始文字不在原文中")
    if support.order_id is not None and support.order_id not in message:
        raise ValueError("訂單編號不在原文中")
    for flag in result.risk_flags:
        if not flag.evidence.quote.strip() or flag.evidence.quote not in message:
            raise ValueError("可疑內容的引句不在原文中")
    # Language snippets are model diagnostics only. They are
    # not business fields and no longer gate an otherwise valid extraction.
    # Company names, signatures and email metadata can make a synthetic
    # language quote non-contiguous even when the main reply language is right.


def repair_language_quote_whitespace(result: Extraction, message: str) -> tuple[Extraction, list[dict]]:
    """Recover a verbatim language quote when the model changed only whitespace.

    This is intentionally narrow: wording and punctuation must still match.  It
    lets a newline survive structured extraction without accepting paraphrases.
    """
    import re

    data = result.model_dump()
    changes = []
    for item in data["languages"]:
        quote = item["quote"]
        if quote in message or not any(c.isspace() for c in quote):
            continue
        pieces = re.split(r"\s+", quote.strip())
        pattern = r"\s+".join(re.escape(piece) for piece in pieces)
        match = re.search(pattern, message)
        if match:
            repaired = match.group(0)
            changes.append({
                "field": "languages.quote",
                "before": quote,
                "after": repaired,
                "reason": "語言引句只改變了換行／空白，還原成客戶原文；未改主要語言",
            })
            item["quote"] = repaired
    return Extraction.model_validate(data), changes


def normalize_extraction(result: Extraction) -> tuple[Extraction, list[dict]]:
    """Deterministic presentation/routing corrections; keep raw model output separately."""
    data = result.model_dump()
    changes = []
    # Keep the model's explicit primary language. Language ratios no longer
    # exist in the schema and are never used for routing.
    represented = {item["code"] for item in data["languages"]}
    if data["language"] not in represented:
        before = data["language"]
        data["language"] = "other"
        changes.append({"field": "language", "before": before, "after": "other",
                        "reason": "主要語言未出現於模型列出的語言，改為 other"})
    if result.timeline.raw is not None and "delivery_timing" not in result.request_types:
        before = list(data["request_types"])
        data["request_types"].append("delivery_timing")
        changes.append({"field": "request_types", "before": before, "after": list(data["request_types"]), "reason": "已抽取到希望交貨期限，補交期需求標籤"})
    injection_quotes = [
        flag.evidence.quote for flag in result.risk_flags
        if flag.code == "prompt_injection"
    ]
    budget_evidence = result.field_evidence.budget
    budget_is_injected_instruction = bool(
        budget_evidence
        and result.budget.raw
        and any(
            budget_evidence.quote in quote
            and re.search(
                r"(?:把|將|請)?預算(?:填|設|改|輸入)(?:成|為)?|"
                r"(?:set|fill|change)\s+(?:the\s+)?budget(?:\s+to)?|"
                r"予算.{0,8}(?:設定|入力|変更)",
                quote,
                flags=re.IGNORECASE,
            )
            for quote in injection_quotes
        )
    )
    if budget_is_injected_instruction:
        before = data["budget"]
        data["budget"] = {"status": "not_provided", "amount": None, "currency": None, "raw": None}
        data["field_evidence"]["budget"] = None
        changes.append({
            "field": "budget",
            "before": before,
            "after": data["budget"],
            "reason": "預算數字位於已標記的指令注入片段，不能當成客戶預算",
        })
        if "other" in data["request_types"] and any(x != "other" for x in data["request_types"]):
            before_types = list(data["request_types"])
            data["request_types"] = [x for x in data["request_types"] if x != "other"]
            changes.append({
                "field": "request_types",
                "before": before_types,
                "after": list(data["request_types"]),
                "reason": "可疑指令由 risk_flags 表示，不把它重複算成客戶的 other 業務需求",
            })
    elif data["budget"]["status"] == "undecided" and data["budget"].get("raw"):
        # A stated approximate amount with no currency is still a stated
        # amount. Missing currency must not turn it into "undecided" or block
        # the first reply.
        amount_match = re.search(r"(?<!\d)(\d{1,3}(?:,\d{3})+|\d{4,})(?!\d)", data["budget"]["raw"])
        if amount_match:
            before = dict(data["budget"])
            data["budget"]["status"] = "stated"
            data["budget"]["amount"] = amount_match.group(1).replace(",", "")
            changes.append({
                "field": "budget", "before": before, "after": dict(data["budget"]),
                "reason": "原文已明確提供概算金額；幣別未指定不代表預算未決定",
            })
    return Extraction.model_validate(data), changes


def missing_fields(result: Extraction) -> list[str]:
    missing = []
    if result.intent == "Support" or "existing_order_issue" in result.request_types:
        if result.support.order_id is None:
            missing.append("support.order_id")
        if result.support.description is None:
            missing.append("support.description")
        q = result.support.affected_quantity
        if result.support.issue_type == "damage" and ((q.min is None and q.max is None) or q.unit in (None, "other")):
            missing.append("support.affected_quantity")
    # Mixed inquiries still need purchase follow-up even when Support takes priority.
    if result.intent != "Sales" and "new_purchase" not in result.request_types:
        return missing
    for name in ("company_name", "product"):
        if getattr(result, name) is None:
            missing.append(name)
    q = result.purchase_quantity
    if (q.min is None and q.max is None) or q.unit in (None, "other"):
        missing.append("purchase_quantity")
    # A buyer does not have to choose the seller's quotation currency. Budget
    # is useful context, but it must not block a first response. When the buyer
    # states an amount without a currency, the draft can ask only whether they
    # have a preferred settlement currency; otherwise Sales quotes in the
    # company's standard currency.
    if result.timeline.date is None:
        missing.append("preferred_delivery_date")
    return missing


def review_reasons(result: Extraction) -> list[str]:
    return ["人工核對抽取內容與原文"] + [
        "可疑內容需人工確認：" + flag.reason for flag in result.risk_flags
    ]
