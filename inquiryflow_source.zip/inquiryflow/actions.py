"""Persistent local CRM mock and follow-up actions.

The module never sends email or calls an external CRM.  Every action is bound
to an approved revision and protected by a durable idempotency key.
"""
from __future__ import annotations

import json
import os
import tempfile
import uuid
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .review import DEFAULT_STORE as DEFAULT_REVIEW_STORE
from .review import ReviewError, _event, load_store as load_review_store, save_store as save_review_store

ACTION_WORKFLOW_VERSION = "action-workflow-0.4"
DEFAULT_ACTION_STORE = Path(__file__).resolve().parents[1] / "outputs" / "action_store.json"
TRACK_STATUSES = (
    "TODO", "IN_PROGRESS", "WAITING_CUSTOMER", "WAITING_INTERNAL",
    "FOLLOW_UP_DUE", "OVERDUE", "COMPLETED", "CANCELLED",
)
SALES_STAGES = ("NEW", "QUALIFYING", "QUOTING", "NEGOTIATION", "WON", "LOST")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4()}"


def _next_display_id(items: dict, prefix: str) -> str:
    numbers = []
    for item in items.values():
        value = item.get("display_id", "")
        if value.startswith(prefix + "-") and value[len(prefix) + 1:].isdigit():
            numbers.append(int(value[len(prefix) + 1:]))
    return f"{prefix}-{max(numbers, default=0) + 1:03d}"


def load_action_store(path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    path = Path(path)
    if not path.exists():
        return {
            "store_version": ACTION_WORKFLOW_VERSION,
            "crm_records": {}, "tasks": {}, "actions": {},
            "reminders": {}, "activities": {},
        }
    data = json.loads(path.read_text(encoding="utf-8"))
    for key in ("crm_records", "tasks", "actions", "reminders", "activities"):
        if key not in data:
            data[key] = {}
        if not isinstance(data[key], dict):
            raise ReviewError("行動資料檔格式不正確。")
    for crm in data["crm_records"].values():
        crm.setdefault("assigned_at", crm.get("created_at"))
        crm.setdefault("last_activity_at", crm.get("updated_at") or crm.get("created_at"))
        crm.setdefault("closed_at", None)
        crm.setdefault("sales_stage", "NEW" if crm.get("intent") == "Sales" else None)
        crm.setdefault("escalation_status", "NONE")
        crm.setdefault("escalation_reason", None)
        crm.setdefault("escalated_at", None)
    for task in data["tasks"].values():
        legacy_status = task.get("task_status", "OPEN")
        task.setdefault("track_status", "COMPLETED" if legacy_status == "COMPLETED" else "TODO")
        task.setdefault("next_followup_at", task.get("due_at"))
        task.setdefault("waiting_since", None)
        task.setdefault("last_reminded_at", None)
        task.setdefault("reminder_count", 0)

    # Older PoC records predate the unified activity timeline.  Surface their
    # known creation/completion facts with stable IDs so existing cases do not
    # look blank and repeated loads never create duplicate history.  These
    # entries are explicitly marked as migrated rather than pretending that
    # we captured events which the old schema never stored.
    for case_id, crm in data["crm_records"].items():
        activity_key = f"MIGRATED:CRM:{case_id}"
        data["activities"].setdefault(activity_key, {
            "activity_id": activity_key,
            "case_id": case_id,
            "occurred_at": crm.get("created_at") or crm.get("updated_at") or _now(),
            "event_type": "CRM_RECORD_MIGRATED",
            "actor_type": "SYSTEM",
            "actor": "migration",
            "old_value": None,
            "new_value": crm.get("display_id"),
            "reason": "舊版紀錄匯入 Activity Timeline；原始建立事件未曾保存。",
            "revision_id": crm.get("approved_revision_id"),
            "task_id": None,
            "metadata": {"migrated_legacy_record": True},
        })
    for task_id, task in data["tasks"].items():
        activity_key = f"MIGRATED:TASK:{task_id}"
        data["activities"].setdefault(activity_key, {
            "activity_id": activity_key,
            "case_id": task["case_id"],
            "occurred_at": task.get("created_at") or task.get("updated_at") or _now(),
            "event_type": "FOLLOWUP_RECORD_MIGRATED",
            "actor_type": "SYSTEM",
            "actor": "migration",
            "old_value": None,
            "new_value": task.get("display_id"),
            "reason": "舊版待辦匯入 Activity Timeline；原始建立事件未曾保存。",
            "revision_id": task.get("approved_revision_id"),
            "task_id": task_id,
            "metadata": {"migrated_legacy_record": True},
        })
        if task.get("completed_at"):
            completed_key = f"MIGRATED:TASK-COMPLETED:{task_id}"
            data["activities"].setdefault(completed_key, {
                "activity_id": completed_key,
                "case_id": task["case_id"],
                "occurred_at": task["completed_at"],
                "event_type": "FOLLOWUP_COMPLETION_MIGRATED",
                "actor_type": "HUMAN" if task.get("completed_by") else "SYSTEM",
                "actor": task.get("completed_by") or "migration",
                "old_value": "OPEN",
                "new_value": "COMPLETED",
                "reason": "舊版完成紀錄匯入 Activity Timeline。",
                "revision_id": task.get("approved_revision_id"),
                "task_id": task_id,
                "metadata": {"migrated_legacy_record": True},
            })
    return data


def save_action_store(store: dict, path: Path | str = DEFAULT_ACTION_STORE) -> None:
    path = Path(path)
    store["store_version"] = ACTION_WORKFLOW_VERSION
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp_name = tempfile.mkstemp(prefix="action-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(store, file, ensure_ascii=False, indent=2)
        os.chmod(temp_name, 0o600)
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def _current_revision(case: dict) -> dict:
    revision = next(
        (item for item in case["revisions"] if item["revision_id"] == case["current_revision_id"]),
        None,
    )
    if not revision:
        raise ReviewError("找不到目前版本。")
    return revision


def _approved_review(case: dict, revision_id: str) -> dict:
    review_id = case.get("approved_review_id")
    review = next((item for item in case["reviews"] if item["review_id"] == review_id), None)
    if not review or review["decision"] != "approve" or review["revision_id"] != revision_id:
        raise ReviewError("目前版本沒有有效核准，不能建立 CRM 或待辦。")
    return review


def _action(store: dict, key: str, case_id: str, revision_id: str, action_type: str) -> dict:
    existing = store["actions"].get(key)
    if existing:
        return existing
    action = {
        "action_id": _id("ACTION"), "case_id": case_id, "revision_id": revision_id,
        "type": action_type, "execution_status": "PENDING", "idempotency_key": key,
        "attempt_count": 0, "result_record_id": None, "created_at": _now(),
        "updated_at": _now(), "error_code": None,
    }
    store["actions"][key] = action
    return action


def _activity(store: dict, case_id: str, event_type: str, actor: str, *,
              actor_type: str = "HUMAN", old_value=None, new_value=None,
              reason: str | None = None, revision_id: str | None = None,
              task_id: str | None = None, metadata: dict | None = None,
              occurred_at: str | None = None) -> dict:
    activity_id = _id("ACTIVITY")
    activity = {
        "activity_id": activity_id, "case_id": case_id,
        "occurred_at": occurred_at or _now(), "event_type": event_type,
        "actor_type": actor_type, "actor": actor,
        "old_value": old_value, "new_value": new_value, "reason": reason,
        "revision_id": revision_id, "task_id": task_id,
        "metadata": metadata or {},
    }
    store["activities"][activity_id] = activity
    crm = store["crm_records"].get(case_id)
    if crm:
        crm["last_activity_at"] = activity["occurred_at"]
    return activity


def execute_approved_actions(case_id: str, actor: str, *, simulate_task_failure: bool = False,
                             review_path: Path | str = DEFAULT_REVIEW_STORE,
                             action_path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    """Upsert one CRM mock and, for Sales/Support, one follow-up task."""
    if not actor.strip():
        raise ReviewError("執行者為必填。")
    review_store = load_review_store(review_path)
    case = review_store["cases"].get(case_id)
    if not case:
        raise ReviewError("找不到這筆案件。")
    revision = _current_revision(case)
    from .representation import representation_limits
    # Old approval snapshots cannot bypass newly detected unresolved scopes.
    current_limits = representation_limits(case.get("inquiry", ""))
    if current_limits or case.get("decision_snapshot", {}).get("automatic_actions_blocked"):
        raise ReviewError("資料需人工核對並拆案，不能以單一商品自動建立 CRM／任務。")
    approval = _approved_review(case, revision["revision_id"])
    # Approval verifies the draft; it cannot turn a non-transactional contact
    # into a sales opportunity when the extraction contradicts its own intent.
    extraction = case.get("extraction", {})
    transactional_requests = {"new_purchase", "pricing", "export_eligibility", "delivery_timing"}
    if extraction.get("intent") == "Sales" and not transactional_requests.intersection(
        extraction.get("request_types") or []
    ):
        raise ReviewError("分類與需求不一致：沒有採購或交易需求，請先更正分類，不能建立 Sales CRM／任務。")
    if case["status"] in {"ACTIONED", "CLOSED"}:
        return action_snapshot(case_id, action_path)
    if case["status"] not in {"APPROVED", "ACTION_FAILED", "ACTIONED"}:
        raise ReviewError("案件尚未核准，不能執行後續動作。")

    action_store = load_action_store(action_path)
    before = case["status"]
    case["status"] = "EXECUTING"
    case["updated_at"] = _now()
    _event(case, "ACTION_EXECUTION_STARTED", actor, revision["revision_id"], before, "EXECUTING")
    save_review_store(review_store, review_path)

    crm_key = f"{case_id}:{revision['revision_id']}:crm_upsert"
    crm_action = _action(action_store, crm_key, case_id, revision["revision_id"], "crm_upsert")
    if crm_action["execution_status"] != "SUCCEEDED":
        crm_action["attempt_count"] += 1
        crm = action_store["crm_records"].get(case_id)
        now = _now()
        created_crm = crm is None
        if not crm:
            crm = {
                "crm_id": _id("CRM"),
                "display_id": _next_display_id(action_store["crm_records"], "CRM"),
                "case_id": case_id, "created_at": now, "assigned_at": now,
                "closed_at": None, "escalation_status": "NONE",
                "escalation_reason": None, "escalated_at": None,
            }
            action_store["crm_records"][case_id] = crm
        extraction = case["extraction"]
        crm.update({
            "approved_revision_id": revision["revision_id"],
            "company_name": extraction.get("company_name"),
            "company_description": extraction.get("company_description"),
            "country": extraction.get("country"), "language": extraction.get("language"),
            "intent": extraction.get("intent"), "product": extraction.get("product"),
            "priority": case.get("decision_snapshot", {}).get("priority", "NORMAL"),
            "owner": crm.get("owner") or actor.strip(), "status": "OPEN", "updated_at": now,
            "sales_stage": crm.get("sales_stage") or ("NEW" if extraction.get("intent") == "Sales" else None),
            "last_activity_at": now,
        })
        crm_action.update(
            execution_status="SUCCEEDED", result_record_id=crm["crm_id"],
            updated_at=now, error_code=None,
        )
        _activity(
            action_store, case_id, "CRM_CREATED" if created_crm else "CRM_UPDATED",
            actor, old_value=None, new_value=crm["display_id"],
            revision_id=revision["revision_id"],
        )

    task_required = case["extraction"].get("intent") in {"Sales", "Support"}
    task_action = None
    if task_required:
        task_key = f"{case_id}:{revision['revision_id']}:create_followup"
        task_action = _action(action_store, task_key, case_id, revision["revision_id"], "create_followup")
        if task_action["execution_status"] != "SUCCEEDED":
            task_action["attempt_count"] += 1
            task_action["updated_at"] = _now()
            if simulate_task_failure:
                task_action.update(execution_status="FAILED", error_code="SIMULATED_TASK_FAILURE")
                _activity(
                    action_store, case_id, "FOLLOWUP_CREATE_FAILED", "system",
                    actor_type="SYSTEM", new_value="FAILED",
                    reason="SIMULATED_TASK_FAILURE", revision_id=revision["revision_id"],
                )
            else:
                approved_at = datetime.fromisoformat(approval["reviewed_at"].replace("Z", "+00:00"))
                task = next((item for item in action_store["tasks"].values() if item["case_id"] == case_id), None)
                created_task = task is None
                if not task:
                    task = {
                        "task_id": _id("TASK"),
                        "display_id": _next_display_id(action_store["tasks"], "TASK"),
                        "case_id": case_id, "created_by_action_id": task_action["action_id"],
                        "created_at": _now(), "task_status": "OPEN",
                        "completed_at": None, "completed_by": None,
                        "track_status": "TODO", "waiting_since": None,
                        "last_reminded_at": None, "reminder_count": 0,
                    }
                    action_store["tasks"][task["task_id"]] = task
                due_at = (approved_at + timedelta(days=3)).isoformat()
                intent = case["extraction"].get("intent")
                task_title = (
                    f"3日內確認售後資料並回覆客戶｜{case['display_id']}"
                    if intent == "Support" else
                    f"3日內確認客戶回覆並跟進詢價｜{case['display_id']}"
                )
                task.update({
                    "approved_revision_id": revision["revision_id"],
                    "owner": task.get("owner") or actor.strip(),
                    "due_at": due_at,
                    "next_followup_at": task.get("next_followup_at") or due_at,
                    "title": task_title, "updated_at": _now(),
                })
                task_action.update(
                    execution_status="SUCCEEDED", result_record_id=task["task_id"],
                    updated_at=_now(), error_code=None,
                )
                _activity(
                    action_store, case_id,
                    "FOLLOWUP_CREATED" if created_task else "FOLLOWUP_UPDATED", actor,
                    new_value=task["display_id"], revision_id=revision["revision_id"],
                    task_id=task["task_id"],
                )

    save_action_store(action_store, action_path)
    failed = any(
        action["execution_status"] == "FAILED"
        for action in action_store["actions"].values()
        if action["case_id"] == case_id and action["revision_id"] == revision["revision_id"]
    )
    review_store = load_review_store(review_path)
    case = review_store["cases"][case_id]
    case["status"] = "ACTION_FAILED" if failed else "ACTIONED"
    case["updated_at"] = _now()
    _event(
        case, "ACTION_EXECUTION_FAILED" if failed else "ACTIONS_COMPLETED", actor,
        revision["revision_id"], "EXECUTING", case["status"],
        {"crm_action": crm_action["execution_status"],
         "task_action": task_action["execution_status"] if task_action else "NOT_REQUIRED"},
    )
    save_review_store(review_store, review_path)
    action_store = load_action_store(action_path)
    _activity(
        action_store, case_id,
        "ACTION_FAILED" if failed else "ACTIONS_COMPLETED", actor,
        old_value="EXECUTING", new_value=case["status"],
        revision_id=revision["revision_id"],
    )
    save_action_store(action_store, action_path)
    return action_snapshot(case_id, action_path)


def action_snapshot(case_id: str, path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    store = load_action_store(path)
    return {
        "crm": deepcopy(store["crm_records"].get(case_id)),
        "tasks": deepcopy([item for item in store["tasks"].values() if item["case_id"] == case_id]),
        "actions": deepcopy([item for item in store["actions"].values() if item["case_id"] == case_id]),
        "reminders": deepcopy([item for item in store["reminders"].values() if item["case_id"] == case_id]),
        "activities": deepcopy(sorted(
            [item for item in store["activities"].values() if item["case_id"] == case_id],
            key=lambda item: item["occurred_at"], reverse=True,
        )),
    }


def task_is_overdue(task: dict, now: datetime | None = None) -> bool:
    """Return overdue state from UTC instants; completed tasks are never overdue."""
    if task.get("task_status") == "COMPLETED" or not task.get("due_at"):
        return False
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    due = datetime.fromisoformat(task["due_at"].replace("Z", "+00:00"))
    return due < now.astimezone(timezone.utc)


def filter_case_ids(cases: list[dict], action_store: dict, *, status: str = "ALL",
                    language: str = "ALL", priority: str = "ALL", owner: str = "ALL",
                    followup: str = "ALL", now: datetime | None = None) -> list[str]:
    """Apply read-only case and follow-up filters for the local work queue."""
    matched = []
    for case in cases:
        case_id = case["case_id"]
        crm = action_store["crm_records"].get(case_id)
        tasks = [item for item in action_store["tasks"].values() if item["case_id"] == case_id]
        owners = {item.get("owner") for item in tasks if item.get("owner")}
        if crm and crm.get("owner"):
            owners.add(crm["owner"])
        case_priority = case.get("decision_snapshot", {}).get("priority", "NORMAL")
        status_groups = {
            "REVIEW": {"NEEDS_REVIEW", "NEEDS_CHANGES"},
            "SETUP": {"APPROVED", "EXECUTING"},
            "FOLLOWUP": {"ACTIONED"},
            "READY_TO_CLOSE": {"ACTIONED"},
            "ATTENTION": {"NEEDS_CHANGES", "ACTION_FAILED"},
            "CLOSED": {"CLOSED"},
        }
        if status != "ALL" and case.get("status") not in status_groups.get(status, {status}):
            continue
        if status == "READY_TO_CLOSE" and any(item["task_status"] == "OPEN" for item in tasks):
            continue
        if language != "ALL" and case.get("extraction", {}).get("language") != language:
            continue
        if priority != "ALL" and case_priority != priority:
            continue
        if owner != "ALL" and owner not in owners:
            continue
        if followup == "OPEN" and not any(item["task_status"] == "OPEN" for item in tasks):
            continue
        if followup == "OVERDUE" and not any(task_is_overdue(item, now) for item in tasks):
            continue
        if followup == "COMPLETED" and not any(item["task_status"] == "COMPLETED" for item in tasks):
            continue
        if followup == "NONE" and tasks:
            continue
        matched.append(case_id)
    return matched


def complete_task(task_id: str, actor: str, *, review_path: Path | str = DEFAULT_REVIEW_STORE,
                  action_path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    if not actor.strip():
        raise ReviewError("完成者為必填。")
    store = load_action_store(action_path)
    task = store["tasks"].get(task_id)
    if not task:
        raise ReviewError("找不到追蹤待辦。")
    if task["task_status"] == "COMPLETED":
        return deepcopy(task)
    before = task.get("track_status") or task.get("task_status")
    completed_at = _now()
    task.update(
        task_status="COMPLETED", track_status="COMPLETED",
        completed_at=completed_at, completed_by=actor.strip(), updated_at=completed_at,
    )
    _activity(
        store, task["case_id"], "FOLLOWUP_COMPLETED", actor,
        old_value=before, new_value="COMPLETED", task_id=task_id,
    )
    save_action_store(store, action_path)
    review_store = load_review_store(review_path)
    case = review_store["cases"].get(task["case_id"])
    if case:
        _event(case, "FOLLOWUP_COMPLETED", actor, case["current_revision_id"], case["status"], case["status"],
               {"task_id": task_id})
        save_review_store(review_store, review_path)
    return deepcopy(task)


def close_case(case_id: str, actor: str, *, review_path: Path | str = DEFAULT_REVIEW_STORE,
               action_path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    if not actor.strip():
        raise ReviewError("結案者為必填。")
    review_store = load_review_store(review_path)
    case = review_store["cases"].get(case_id)
    if not case:
        raise ReviewError("找不到這筆案件。")
    if case["status"] == "CLOSED":
        return deepcopy(case)
    if case["status"] != "ACTIONED":
        raise ReviewError("後續動作尚未完成，不能結案。")
    tasks = action_snapshot(case_id, action_path)["tasks"]
    if any(item["task_status"] != "COMPLETED" for item in tasks):
        raise ReviewError("仍有未完成的追蹤待辦，不能結案。")
    before = case["status"]
    closed_at = _now()
    case["status"] = "CLOSED"; case["updated_at"] = closed_at
    _event(case, "CASE_CLOSED", actor, case["current_revision_id"], before, "CLOSED")
    save_review_store(review_store, review_path)
    action_store = load_action_store(action_path)
    crm = action_store["crm_records"].get(case_id)
    if crm:
        crm.update(status="CLOSED", closed_at=closed_at, updated_at=closed_at, last_activity_at=closed_at)
    _activity(
        action_store, case_id, "CASE_CLOSED", actor,
        old_value=before, new_value="CLOSED", revision_id=case["current_revision_id"],
        occurred_at=closed_at,
    )
    save_action_store(action_store, action_path)
    return deepcopy(case)


def update_case_tracking(case_id: str, actor: str, *, owner: str | None = None,
                         track_status: str | None = None, sales_stage: str | None = None,
                         next_followup_at: str | None = None, reason: str | None = None,
                         crm_details: dict | None = None,
                         action_path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    """Update ownership and operational tracking fields with append-only activities."""
    if not actor.strip():
        raise ReviewError("執行者為必填。")
    store = load_action_store(action_path)
    crm = store["crm_records"].get(case_id)
    if not crm:
        raise ReviewError("尚未建立 CRM 紀錄。")
    if crm_details is not None:
        allowed = {'company_name', 'country', 'product', 'priority'}
        if not isinstance(crm_details, dict) or set(crm_details) - allowed:
            raise ReviewError("CRM 修改包含不支援的欄位。")
        if not reason or not reason.strip():
            raise ReviewError("修改 CRM 資料必須填寫原因。")
        if any(not isinstance(value, str) for value in crm_details.values()):
            raise ReviewError("CRM 欄位必須是文字。")
        if crm_details.get('priority', crm.get('priority')) not in {'HIGH','NORMAL','LOW','NEEDS_INFO'}:
            raise ReviewError("CRM 優先度不正確。")
        for field, value in crm_details.items():
            value = value.strip() or None
            if crm.get(field) != value:
                old_value = crm.get(field)
                crm[field] = value
                crm['updated_at'] = _now()
                _activity(store, case_id, 'CRM_FIELD_UPDATED', actor, old_value={field:old_value}, new_value={field:value}, reason=reason)
    tasks = [item for item in store["tasks"].values() if item["case_id"] == case_id]
    now = _now()
    if owner is not None and owner.strip() and owner.strip() != crm.get("owner"):
        old_owner = crm.get("owner")
        new_owner = owner.strip()
        crm.update(owner=new_owner, assigned_at=now, updated_at=now)
        for task in tasks:
            task.update(owner=new_owner, updated_at=now)
        _activity(store, case_id, "OWNER_ASSIGNED", actor, old_value=old_owner, new_value=new_owner, reason=reason)
    if track_status is not None:
        if track_status not in TRACK_STATUSES:
            raise ReviewError("追蹤狀態不正確。")
        for task in tasks:
            if task.get("task_status") == "COMPLETED" and track_status != "COMPLETED":
                continue
            old_status = task.get("track_status", "TODO")
            if old_status != track_status:
                task["track_status"] = track_status
                task["updated_at"] = now
                task["waiting_since"] = now if track_status == "WAITING_CUSTOMER" else None
                if track_status == "WAITING_CUSTOMER":
                    task["next_followup_at"] = (datetime.fromisoformat(now) + timedelta(days=3)).isoformat()
                _activity(
                    store, case_id, "TRACK_STATUS_CHANGED", actor,
                    old_value=old_status, new_value=track_status,
                    reason=reason, task_id=task["task_id"],
                )
    if sales_stage is not None:
        if sales_stage not in SALES_STAGES:
            raise ReviewError("Sales 階段不正確。")
        if crm.get("intent") != "Sales":
            raise ReviewError("只有 Sales 案件可以設定 Sales 階段。")
        old_stage = crm.get("sales_stage") or "NEW"
        if old_stage != sales_stage:
            crm.update(sales_stage=sales_stage, updated_at=now)
            _activity(store, case_id, "SALES_STAGE_CHANGED", actor, old_value=old_stage, new_value=sales_stage, reason=reason)
    if next_followup_at is not None:
        try:
            datetime.fromisoformat(next_followup_at.replace("Z", "+00:00"))
        except (AttributeError, ValueError):
            raise ReviewError("下次追蹤時間格式不正確。")
        for task in tasks:
            old_time = task.get("next_followup_at")
            if old_time != next_followup_at:
                task.update(next_followup_at=next_followup_at, updated_at=now)
                _activity(
                    store, case_id, "NEXT_FOLLOWUP_CHANGED", actor,
                    old_value=old_time, new_value=next_followup_at,
                    reason=reason, task_id=task["task_id"],
                )
    save_action_store(store, action_path)
    return action_snapshot(case_id, action_path)


def escalate_case(case_id: str, actor: str, reason: str, *, actor_type: str = "HUMAN",
                  action_path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    if not reason.strip():
        raise ReviewError("升級原因為必填。")
    store = load_action_store(action_path)
    crm = store["crm_records"].get(case_id)
    if not crm:
        raise ReviewError("尚未建立 CRM 紀錄。")
    if crm.get("escalation_status") != "ESCALATED":
        now = _now()
        crm.update(
            escalation_status="ESCALATED", escalation_reason=reason.strip(),
            escalated_at=now, updated_at=now,
        )
        _activity(
            store, case_id, "CASE_ESCALATED", actor, actor_type=actor_type,
            old_value="NONE", new_value="ESCALATED", reason=reason.strip(),
        )
        save_action_store(store, action_path)
    return action_snapshot(case_id, action_path)


def run_due_automations(*, now: datetime | None = None,
                        action_path: Path | str = DEFAULT_ACTION_STORE) -> dict:
    """Create internal reminders for due follow-ups and apply minimal escalation rules."""
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    now = now.astimezone(timezone.utc)
    now_text = now.isoformat()
    store = load_action_store(action_path)
    created = []
    escalated = []
    for task in store["tasks"].values():
        if task.get("task_status") == "COMPLETED" or task.get("track_status") == "CANCELLED":
            continue
        followup_value = task.get("next_followup_at") or task.get("due_at")
        if not followup_value:
            continue
        followup_at = datetime.fromisoformat(followup_value.replace("Z", "+00:00")).astimezone(timezone.utc)
        if followup_at > now:
            continue
        reminder_key = f"{task['task_id']}:{followup_value}"
        if reminder_key in store["reminders"]:
            continue
        reminder = {
            "reminder_id": _id("REMINDER"), "display_id": _next_display_id(store["reminders"], "REMINDER"),
            "idempotency_key": reminder_key, "case_id": task["case_id"],
            "task_id": task["task_id"], "owner": task.get("owner"),
            "status": "OPEN", "triggered_at": now_text,
            "reason": "CUSTOMER_NO_RESPONSE_OR_FOLLOWUP_DUE",
        }
        store["reminders"][reminder_key] = reminder
        task["reminder_count"] = int(task.get("reminder_count", 0)) + 1
        task["last_reminded_at"] = now_text
        task["next_followup_at"] = (now + timedelta(days=3)).isoformat()
        task["track_status"] = "OVERDUE" if task_is_overdue(task, now) else "FOLLOW_UP_DUE"
        task["updated_at"] = now_text
        _activity(
            store, task["case_id"], "REMINDER_TRIGGERED", "automation",
            actor_type="AUTOMATION", new_value=reminder["display_id"],
            reason=reminder["reason"], task_id=task["task_id"], occurred_at=now_text,
        )
        created.append(reminder["reminder_id"])

        crm = store["crm_records"].get(task["case_id"])
        needs_escalation = bool(
            crm and crm.get("escalation_status") != "ESCALATED"
            and (task["reminder_count"] >= 2 or (crm.get("priority") == "HIGH" and task_is_overdue(task, now)))
        )
        if needs_escalation:
            reason = "高優先度案件已逾期" if crm.get("priority") == "HIGH" else "連續兩次提醒仍未完成"
            crm.update(
                escalation_status="ESCALATED", escalation_reason=reason,
                escalated_at=now_text, updated_at=now_text,
            )
            _activity(
                store, task["case_id"], "CASE_ESCALATED", "automation",
                actor_type="AUTOMATION", old_value="NONE", new_value="ESCALATED",
                reason=reason, task_id=task["task_id"], occurred_at=now_text,
            )
            escalated.append(task["case_id"])
    if created or escalated:
        save_action_store(store, action_path)
    return {"reminders_created": created, "cases_escalated": escalated}
