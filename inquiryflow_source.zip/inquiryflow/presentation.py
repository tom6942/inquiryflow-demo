"""Shared human-readable views for gold fixtures and live outputs."""
import html
import re
import streamlit as st

from .knowledge_i18n import translated_hit
from .schema import Extraction, missing_fields


LABELS = {
    'zh-TW': {
        'company_name': '公司正式名稱', 'company_description': '公司描述', 'country': '市場',
        'product': '商品', 'purchase_quantity': '新採購數量／單位', 'budget': '採購預算／幣別',
        'timeline': '希望交貨時間', 'preferred_delivery_date': '希望到貨日期',
        'support.order_id': '售後訂單編號', 'support.description': '售後問題說明',
        'support.affected_quantity': '售後受影響數量／單位',
    },
    'ja': {
        'company_name': '会社正式名称', 'company_description': '会社概要', 'country': '市場',
        'product': '商品', 'purchase_quantity': '新規購入数量／単位', 'budget': '購入予算／通貨',
        'timeline': '希望納期', 'preferred_delivery_date': '希望到着日',
        'support.order_id': 'アフターサービス注文番号', 'support.description': '問題の内容',
        'support.affected_quantity': '影響を受けた数量／単位',
    },
}
REQUEST_LABELS = {
    'zh-TW': {
        'new_purchase': '新採購', 'pricing': '詢問價格', 'export_eligibility': '詢問能否出口',
        'delivery_timing': '交貨時間', 'general_info': '一般資訊',
        'existing_order_issue': '既有訂單／售後', 'other': '其他需求',
    },
    'ja': {
        'new_purchase': '新規購入', 'pricing': '価格・見積もり', 'export_eligibility': '輸出可否',
        'delivery_timing': '納期', 'general_info': '一般情報',
        'existing_order_issue': '既存注文／アフターサービス', 'other': 'その他',
    },
}
DECISION_JA_FALLBACK = {
    'R01': '価格、輸出可否、納期をモデルだけで確約せず、担当者が最新条件を確認します。',
    'R02': '必要情報が不足しています。不明な値は空欄のままとし、システムで推測しません。',
    'R03': '日本酒の新規購入数量がデモ用の優先基準に該当します。',
    'R04': '有効な出典が不足または競合しているため、会社情報を補って作成しません。',
    'R08': '不審な指示は確認対象のデータとして扱い、承認・実行権限を与えません。',
    'D05': '既存注文の問題による顧客影響を優先して人が確認します。',
}


def _u(locale, zh, ja):
    return ja if locale == 'ja' else zh


def quantity_text(q, locale='zh-TW'):
    low, high = q['min'], q['max']
    units = {
        'zh-TW': {'bottle': '瓶', 'case': '箱', 'other': '（其他單位）', None: '（單位未知）'},
        'ja': {'bottle': '本', 'case': 'ケース', 'other': '（その他の単位）', None: '（単位不明）'},
    }
    unit = units[locale][q['unit']]
    if low is None and high is None:
        return _u(locale, '數量未知', '数量不明') + (f'；原文：{q["raw"]}' if q['raw'] else '')
    if low is None:
        return f'{_u(locale, "最多", "最大")} {high} {unit}'
    if high is None:
        return f'{_u(locale, "至少", "最小")} {low} {unit}'
    if low == high:
        return f'{low} {unit}'
    return f'{low}～{high} {unit}'


def budget_text(b, locale='zh-TW'):
    if b['status'] == 'not_provided':
        return _u(locale, '未提供', '未提示')
    if b['status'] == 'undecided':
        return _u(locale, '尚未決定', '未定')
    if b['amount'] is not None:
        currency = b['currency'] or _u(locale, '幣別待確認', '通貨要確認')
        suffix = _u(locale, '（總額或單價等條件請核對原文）', '（総額・単価などの条件は原文を確認）')
        return f'{_u(locale, "已提供金額", "提示金額")}：{currency} {b["amount"]}{suffix}'
    return _u(locale, '已提到預算條件，金額／範圍待人工確認', '予算条件への言及あり。金額・範囲は人による確認が必要')


def timeline_text(t, locale='zh-TW'):
    if t['raw'] is None:
        return _u(locale, '未提供希望到貨日期', '希望到着日の提示なし')
    # summary_zh is model data. The Japanese view uses the verbatim source when available.
    text = t['raw'] if locale == 'ja' else t['summary_zh']
    if t['missing_parts']:
        labels = ({'year': '年份', 'month': '月份', 'day': '日期', 'exact_date': '確切日期'} if locale != 'ja'
                  else {'year': '年', 'month': '月', 'day': '日', 'exact_date': '正確な日付'})
        text += '（' + '、'.join(labels[x] for x in t['missing_parts']) + _u(locale, '待確認）', '要確認）')
    return text


def missing_label(field, result, locale='zh-TW'):
    if field == 'preferred_delivery_date' and result['timeline']['raw'] is not None:
        return _u(locale, '希望到貨：', '希望到着：') + timeline_text(result['timeline'], locale)
    return LABELS[locale].get(field, field)


def render_summary(result, locale='zh-TW', *, title=None, decision=None):
    intent_labels = ({'Sales': 'Sales／採購或詢價', 'Support': 'Support／優先處理售後', 'FAQ': 'FAQ／一般資訊', 'Other': 'Other／其他需求'} if locale != 'ja'
                     else {'Sales': 'Sales／購入・見積もり', 'Support': 'Support／アフターサービス優先', 'FAQ': 'FAQ／一般情報', 'Other': 'Other／その他'})
    language_names = {'zh-TW': ('繁體中文', '繁体字中国語'), 'zh-CN': ('簡體中文', '簡体字中国語'),
                      'en': ('英文', '英語'), 'ja': ('日文', '日本語'), 'other': ('其他', 'その他')}
    primary = result.get('language', 'other')
    requests = '、'.join(REQUEST_LABELS[locale][x] for x in result['request_types'])
    support = result['support']
    has_support = result['intent'] == 'Support' or 'existing_order_issue' in result['request_types'] or support['description'] is not None
    missing = missing_fields(Extraction.model_validate(result))
    decision_questions = decision.get('missing_information', []) if decision else None
    limits = {item['code'] for item in (decision or {}).get('representation_limitations', [])}
    quantity_display = quantity_text(result['purchase_quantity'], locale)
    budget_display = budget_text(result['budget'], locale)
    market_display = result['country'] or _u(locale, '未知', '不明')
    date_display = timeline_text(result['timeline'], locale)
    if limits & {'MULTIPLE_PRODUCTS', 'MULTIPLE_DESTINATIONS'}:
        if result['purchase_quantity']['min'] is None and result['purchase_quantity'].get('raw'):
            quantity_display = _u(locale, '多筆數量，未合併；請按原文逐筆核對', '複数の数量を合算せず、原文の明細ごとに確認')
        if not result['country'] and 'MULTIPLE_DESTINATIONS' in limits:
            market_display = _u(locale, '多個配送地，請按原文逐筆核對', '複数の配送先。原文の明細ごとに確認')
        if result['budget']['amount'] is None and result['budget'].get('raw'):
            budget_display = _u(locale, '多筆預算，未合併；請按原文逐筆核對', '複数の予算を合算せず、原文の明細ごとに確認')
        if not result['timeline']['date'] and decision_questions is not None and not any(q['field']=='preferred_delivery_date' for q in decision_questions):
            date_display = result['timeline'].get('summary_zh') if locale != 'ja' else result['timeline'].get('raw')
            date_display = date_display or _u(locale, '請按原文分別核對日期', '原文で各明細の日付を確認')

    product = result['product'] if locale == 'ja' else result['product_name_zh']
    risk_text = '、'.join(flag['code'] for flag in result['risk_flags']) or _u(locale, '未偵測到', '検出なし')
    rows = [
        (_u(locale, '意圖（Intent）', '意図（Intent）'), intent_labels[result['intent']], 'overview'),
        (_u(locale, '需求類型', '要望タイプ'), requests or _u(locale, '尚未判定', '未判定'), 'overview'),
        (_u(locale, '建議回覆語言', '推奨返信言語'), language_names.get(primary, (primary, primary))[1 if locale == 'ja' else 0], 'overview'),
        (_u(locale, '公司正式名稱', '会社正式名称'), result['company_name'] or _u(locale, '未提供', '未提示'), 'detail'),
        (_u(locale, '公司描述', '会社概要'), result['company_description'] or _u(locale, '未提供', '未提示'), 'detail'),
        (_u(locale, '市場／國家', '市場・国'), market_display, 'detail'),
        (_u(locale, '商品', '商品'), product or _u(locale, '未知', '不明'), 'detail'),
        (_u(locale, '新採購數量', '新規購入数量'), quantity_display, 'detail'),
        (_u(locale, '預算／幣別', '予算・通貨'), budget_display, 'detail'),
        (_u(locale, '時間需求', '日程のご希望'), date_display, 'detail'),
        (_u(locale, '風險標記', 'リスク表示'), risk_text, 'risk'),
        (_u(locale, '仍需補充', '不足情報'), ('、'.join(q.get('question_ja' if locale == 'ja' else 'question_zh', q['field']) for q in decision_questions) if decision_questions is not None else '、'.join(missing_label(field, result, locale) for field in missing)) or _u(locale, '目前未列出', '現在なし'), 'attention'),
    ]
    if decision and decision.get('human_in_loop'):
        human = decision['human_in_loop']
        rows.append((_u(locale, '執行模式', '実行モード'), human['label_ja' if locale == 'ja' else 'label_zh'], 'mode'))
    if has_support:
        rows.extend([
            (_u(locale, '售後訂單', '関連注文'), support['order_id'] or _u(locale, '未知', '不明'), 'support'),
            (_u(locale, '售後問題', '問題の内容'), support['description'] or _u(locale, '待補充', '要追記'), 'support'),
            (_u(locale, '受影響數量', '影響数量'), quantity_text(support['affected_quantity'], locale), 'support'),
        ])
    fields = ''.join(
        f'<div class="if-form-field {tone}"><div class="if-form-label">{html.escape(str(label))}</div>'
        f'<div class="if-form-value">{html.escape(str(value))}</div></div>'
        for label, value, tone in rows
    )
    form_title = title or _u(locale, '分析結果', '分析結果')
    st.markdown(
        f'<div class="if-result-form"><div class="if-form-title">{html.escape(form_title)}</div>'
        f'<div class="if-form-grid">{fields}</div></div>',
        unsafe_allow_html=True,
    )
    if result['risk_flags']:
        for flag in result['risk_flags']:
            st.warning(_u(locale, '可疑原文：', '疑わしい原文：') + flag['evidence']['quote'])


def render_evidence(result, locale='zh-TW'):
    items = []
    for field, ev in result['field_evidence'].items():
        if ev:
            items.append((LABELS[locale].get(field, field), ev['quote']))
    support_labels = ({'order_id': '售後訂單', 'issue': '售後問題', 'affected_quantity': '售後受影響數量'} if locale != 'ja'
                      else {'order_id': 'アフターサービス注文', 'issue': '問題', 'affected_quantity': '影響数量'})
    for field, ev in result['support']['field_evidence'].items():
        if ev:
            items.append((support_labels[field], ev['quote']))
    cards = ''.join(
        f'<div class="if-evidence-item"><div class="if-evidence-label">{html.escape(str(label))}</div>'
        f'<div class="if-evidence-quote">{html.escape(str(quote))}</div></div>'
        for label, quote in items
    )
    if not cards:
        cards = f'<div class="if-empty-state">{_u(locale, "這筆結果沒有可顯示的原文片段。", "表示できる原文断片はありません。")}</div>'
    st.markdown(
        f'<div class="if-evidence-wrap"><div class="if-panel-title">{_u(locale, "原文依據", "原文の根拠")}</div>'
        f'<div class="if-panel-note">{_u(locale, "每個欄位都可回查客戶原文。", "各項目を顧客の原文まで確認できます。")}</div>'
        f'<div class="if-evidence-grid">{cards}</div></div>',
        unsafe_allow_html=True,
    )


def render_retrieval(retrieval, locale='zh-TW'):
    status = retrieval['status']
    status_labels = ({'FOUND': '找到可引用來源', 'NO_MATCH': '查無足以支持回答的來源', 'REVIEW_REQUIRED': '需要人工核對', 'ERROR': '檢索失敗'} if locale != 'ja'
                     else {'FOUND': '引用可能な出典あり', 'NO_MATCH': '回答を裏付ける出典なし', 'REVIEW_REQUIRED': '人による確認が必要', 'ERROR': '検索エラー'})
    reasons_ja = {
        'FOUND': '人による確認に使用できる合成資料が見つかりました。検索ヒットは、社外への約束を意味しません。',
        'NO_MATCH': '回答を十分に裏付ける資料がありません。情報を補わず、担当者へ確認してください。',
        'REVIEW_REQUIRED': '期限切れまたは信頼できない関連断片は除外され、回答や指示には使用できません。',
        'ERROR': 'ナレッジベース検索に失敗しました。',
    }
    reason = reasons_ja.get(status, retrieval['reason']) if locale == 'ja' else retrieval['reason']
    if retrieval.get('answer_coverage', {}).get('status') == 'PARTIAL':
        status = 'PARTIAL'
        status_labels['PARTIAL'] = _u(locale, '來源僅部分支持問題', '出典の裏付けは一部のみ')
        reason = _u(locale, '來源列出平日受理時間，但沒有明載週末安排；需補查後再回答週末問題。', '出典には平日の受付時間がありますが、週末の対応は明記されていません。追加確認が必要です。')
    if status == 'FOUND':
        scope = _u(locale, '已找到可供草稿引用的資料；可繼續產生待人工核對的回覆草稿。', '草稿に引用できる資料があります。人による確認待ちの返信案を作成できます。')
    elif status in {'NO_MATCH', 'PARTIAL'}:
        scope = _u(locale, '不可根據現有 KB 回答。應明示資料不足並轉人工確認。', '現在のKBでは回答できません。情報不足を明示し、担当者へ確認します。')
    elif status == 'REVIEW_REQUIRED':
        if retrieval.get('hits'):
            scope = _u(locale, '有有效來源，但同時找到過期或不可信資料；不可直接下結論，需人工核對後才能寫草稿。', '有効な出典と同時に期限切れ・信頼できない資料も見つかりました。人が確認するまで結論や草稿を作成できません。')
        else:
            scope = _u(locale, '沒有可引用的有效來源，不產生答案；需人工確認。', '引用可能な有効資料がないため回答を作成せず、担当者が確認します。')
    else:
        scope = _u(locale, '檢索失敗，不產生答案。', '検索に失敗したため回答を作成しません。')
    status_class = {'FOUND': 'found', 'NO_MATCH': 'nomatch', 'REVIEW_REQUIRED': 'review', 'ERROR': 'error'}.get(status, 'review')
    st.markdown(
        f'<div class="if-retrieval-card {status_class}">'
        f'<div class="if-retrieval-head"><div><div class="if-panel-title">{_u(locale, "知識庫檢索與來源", "ナレッジベース検索と出典")}</div>'
        f'<div class="if-panel-note">{_u(locale, "先確認資料能否支持回答，再決定草稿邊界。", "資料が回答を裏付けるか確認してから、返信案の範囲を決めます。")}</div></div>'
        f'<span class="if-status-pill">{html.escape(status)} · {html.escape(status_labels.get(status, _u(locale, "未知狀態", "不明")))}</span></div>'
        f'<div class="if-retrieval-body"><div class="if-retrieval-reason">{html.escape(reason)}</div>'
        f'<div class="if-retrieval-scope"><b>{_u(locale, "可回答範圍", "回答可能な範囲")}</b><span>{html.escape(scope)}</span></div></div></div>',
        unsafe_allow_html=True,
    )
    if status == 'NO_MATCH':
        with st.container(key='retrieval_semantic_warning'):
            st.warning(reason)
    for hit in retrieval.get('hits', []):
        view, translated = translated_hit(hit, locale)
        label = f"{_u(locale, '來源', '出典')} {view['citation']}｜{_u(locale, '相關度', '関連度')} {view['score']:.2f}"
        with st.expander(label):
            st.write(view['title'] + '｜' + view['chunk_title'])
            st.write(view['excerpt'])
            st.caption(f"{_u(locale, '類型', '種類')}：{view['source_type']}｜{_u(locale, '有效自', '有効日')}：{view['valid_from']}｜{_u(locale, '合成資料：是', '合成データ：はい')}")
            if locale == 'ja' and not translated:
                st.caption('この文書版の日本語訳は未作成です。中国語の原文を表示しています。')
    for hit in retrieval.get('excluded_hits', []):
        view, translated = translated_hit(hit, locale)
        label = f"{_u(locale, '已排除', '除外済み')} {view['citation']}｜{view['status']}／{view['authority']}"
        with st.expander(label):
            st.write(view['excerpt'])
            st.caption(_u(locale, '此片段只供風險核對，不能作為答案、公司政策或可執行指令。', 'この断片はリスク確認専用で、回答、会社方針、実行可能な指示として使用できません。'))
            if locale == 'ja' and not translated:
                st.caption('この文書版の日本語訳は未作成です。中国語の原文を表示しています。')
    if not retrieval.get('hits'):
        no_source_note = _u(locale, '沒有可引用來源。後續草稿必須明示待確認，不能補造公司資訊。', '引用可能な出典はありません。後続の草稿では要確認と明示し、会社情報を作り足してはいけません。')
        st.markdown(f'<div class="if-source-empty">{no_source_note}</div>', unsafe_allow_html=True)
        with st.container(key='retrieval_semantic_caption'):
            st.caption(no_source_note)


def render_decision(decision, locale='zh-TW'):
    """Show one scannable decision sheet instead of a long prose report."""
    st.subheader(_u(locale, '業務判斷', '業務判断'))
    priority_label = {'HIGH': 'High／優先人工處理', 'NORMAL': 'Normal／一般處理', 'NEEDS_INFO': 'Needs Info／包裝規格待確認', 'LOW': 'Low／低優先'}.get(decision['priority'], decision['priority'])
    if locale == 'ja':
        priority_label = {'HIGH': 'High／優先して人が対応', 'NORMAL': 'Normal／通常対応', 'NEEDS_INFO': 'Needs Info／梱包仕様の確認待ち', 'LOW': 'Low／低優先'}.get(decision['priority'], decision['priority'])
    action = decision['recommended_action']['label_ja' if locale == 'ja' else 'label_zh']
    human = decision.get('human_in_loop', {})
    if human.get('mode') == 'BLOCKED':
        priority_label = _u(locale, '已阻擋／不進人工待辦', 'ブロック済み・人の対応待ちなし')
    human_label = human.get('label_ja' if locale == 'ja' else 'label_zh', _u(locale, '待判定', '判定待ち'))
    human_reason = human.get('reason_ja' if locale == 'ja' else 'reason_zh', '')
    cards = [
        (_u(locale, '優先度', '優先度'), priority_label),
        (_u(locale, '執行模式', '実行モード'), human_label),
        (_u(locale, '建議下一步', '推奨する次の対応'), action),
    ]
    card_html = ''.join(
        f'<div class="if-decision-card"><div class="if-decision-kicker">{html.escape(label)}</div>'
        f'<div class="if-decision-value">{html.escape(value)}</div></div>' for label, value in cards
    )
    st.markdown(f'<div class="if-decision-grid">{card_html}</div>', unsafe_allow_html=True)
    if human_reason:
        st.markdown(
            f'<div class="if-decision-callout"><b>{_u(locale, "為什麼這樣分流", "このルートを選ぶ理由")}</b>'
            f'<span>{html.escape(human_reason)}</span></div>', unsafe_allow_html=True,
        )

    combined = []
    seen = set()
    for reason in decision['priority_reasons'] + decision['escalation_reasons']:
        if reason['rule_id'] in seen:
            continue
        seen.add(reason['rule_id'])
        title = reason.get('title_ja', '') if locale == 'ja' else reason.get('title', '')
        detail = (reason.get('detail_ja') or DECISION_JA_FALLBACK.get(reason['rule_id'], reason['detail'])) if locale == 'ja' else reason['detail']
        combined.append(
            f'<div class="if-rule-row"><code>{html.escape(reason["rule_id"])}</code><div><b>{html.escape(title)}</b>'
            f'<span>{html.escape(detail)}</span></div></div>'
        )
    if not combined:
        combined.append(f'<div class="if-empty-state">{_u(locale, "未命中特別規則，維持一般處理。", "特別なルールに該当せず、通常対応です。")}</div>')
    st.markdown(
        f'<div class="if-decision-section"><div class="if-decision-title">{_u(locale, "命中規則", "適用ルール")}</div>'
        f'<div class="if-rule-list">{"".join(combined)}</div></div>', unsafe_allow_html=True,
    )

    missing = decision['missing_information']
    missing_chips = ''.join(
        f'<span class="if-chip">{html.escape(item["question_ja"] if locale == "ja" else item["question_zh"])}</span>'
        for item in missing
    ) or f'<span class="if-chip clear">{_u(locale, "目前沒有缺項", "不足項目なし")}</span>'
    st.markdown(
        f'<div class="if-decision-section"><div class="if-decision-title">{_u(locale, "仍需補充", "不足情報")}</div>'
        f'<div class="if-chip-wrap">{missing_chips}</div></div>', unsafe_allow_html=True,
    )

    steps = decision['recommended_action'].get('steps', [])
    if steps:
        system_codes = {'RESEARCH_SOURCES', 'REJECT_INPUT'}
        step_rows = []
        for index, step in enumerate(steps, 1):
            actor = _u(locale, '系統輔助', 'システム支援') if step.get('code') in system_codes else _u(locale, '負責人', '担当者')
            label = step['label_ja' if locale == 'ja' else 'label_zh']
            step_rows.append(
                f'<div class="if-action-row"><span class="if-action-number">{index}</span>'
                f'<span class="if-actor">{html.escape(actor)}</span><b>{html.escape(label)}</b></div>'
            )
        st.markdown(
            f'<div class="if-decision-section"><div class="if-decision-title">{_u(locale, "接下來誰做什麼", "次に誰が何をするか")}</div>'
            f'<div class="if-action-list">{"".join(step_rows)}</div></div>', unsafe_allow_html=True,
        )
    boundary = decision.get('reply_boundary', {})
    if boundary and human.get('mode') != 'BLOCKED':
        can_answer = boundary.get('can_answer') or []
        needs_human = boundary.get('needs_human_confirmation') or []
        can_html = ''.join(f'<li>{html.escape(item["label_ja"] if locale == "ja" else item["label_zh"])}</li>' for item in can_answer)
        human_html = ''.join(f'<li>{html.escape(item["label_ja"] if locale == "ja" else item["label_zh"])}</li>' for item in needs_human)
        if not can_html:
            can_html = f'<li>{_u(locale, "目前沒有可引用來源", "現在、引用可能な出典はありません")}</li>'
        if not human_html:
            human_html = f'<li>{_u(locale, "依本案執行模式處理草稿與對外動作", "この案件の実行モードに従って返信案と対外操作を処理")}</li>'
        st.markdown(
            f'<div class="if-decision-section"><div class="if-decision-title">{_u(locale, "哪些內容可以回覆", "回答範囲")}</div>'
            f'<div class="if-boundary-grid"><div class="if-boundary-card answer"><b>{_u(locale, "可依來源回答", "出典に基づき回答可能")}</b><ul>{can_html}</ul></div>'
            f'<div class="if-boundary-card human"><b>{_u(locale, "需人工確認", "人の確認が必要")}</b><ul>{human_html}</ul></div></div></div>',
            unsafe_allow_html=True,
        )
def email_text_html(text):
    """Keep saved mail text out of Markdown block parsing while retaining line breaks."""
    return html.escape(text).replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>")


def internal_notes_html(text):
    """Display sections without editing the stored/API text or its evaluation.

    New drafts have explicit labels. Legacy sentences are grouped only for
    presentation; this does not infer completed work or verify their content.
    """
    labels = ['お問い合わせ概要', '確認事項', '対応案', '未確認・注意点']
    sections = {label: [] for label in labels}
    current = None
    for part in re.split(r'(【(?:お問い合わせ概要|確認事項|対応案|未確認・注意点)】)', text):
        if part.startswith('【') and part.endswith('】') and part[1:-1] in sections:
            current = part[1:-1]
        elif part.strip():
            if current:
                sections[current].append(part.strip())
            else:
                for sentence in re.split(r'(?<=。)|\n+', part):
                    if not sentence.strip():
                        continue
                    if re.search(r'(?:様|氏)(?:から|より)', sentence):
                        label = 'お問い合わせ概要'
                    elif re.search(r'未確認|未確定|未実施|入力項目|単一商品|資料はなく|追加質問|再質問|再確認は不要|送信しない|整合|必要缺項|exact_date', sentence):
                        label = '未確認・注意点'
                    elif re.search(r'確認事項|確認先', sentence):
                        label = '確認事項'
                    elif re.search(r'担当|確認する|確認し|照合|依頼する|必要がある', sentence):
                        label = '対応案'
                    else:
                        label = 'お問い合わせ概要'
                    sections[label].append(sentence.strip())
    return ''.join(
        '<div class="if-internal-section" style="margin-bottom:.8rem">'
        '<div class="if-draft-label" style="margin-bottom:.3rem">' + html.escape(label) + '</div>'
        '<div class="if-draft-text">' + email_text_html('\n'.join(parts)) + '</div></div>'
        for label, parts in sections.items() if parts
    )


def render_draft_preview(draft, locale='zh-TW', key_prefix='draft', source='preview'):
    title = _u(locale, 'API 生成草稿', 'API生成返信案') if source == 'api' else _u(locale, '規則草稿預覽', 'ルール返信案プレビュー')
    notice = draft['notice_ja' if locale == 'ja' else 'notice_zh']
    blocked = draft['status'] == 'BLOCKED'
    status_label = _u(locale, '已停止對外草稿', '対外返信案を停止') if blocked else _u(locale, '待人工核對', '人による確認待ち')
    reply = draft.get('customer_reply')
    reply_html = (
        f'<div class="if-draft-text if-draft-reply">{email_text_html(reply)}</div>'
        if reply is not None else
        f'<div class="if-draft-text if-draft-reply">{_u(locale, "對外草稿已停止。", "対外返信案の作成を停止しました。")}</div>'
    )
    source_chips = ''.join(
        f'<span class="if-source-chip">{html.escape(citation)}</span>'
        for citation in draft.get('source_citations', [])
    )
    if not source_chips:
        source_chips = f'<span class="if-chip">{_u(locale, "沒有可引用來源，不得宣稱公司事實", "引用可能な出典なし。会社情報を断定不可")}</span>'
    st.markdown(
        f'<div class="if-draft-shell">'
        f'<div class="if-draft-heading {"blocked" if blocked else ""}"><div class="if-draft-heading-copy"><h3>{title}</h3>'
        f'<p>{html.escape(notice)}</p></div><strong>{status_label}</strong></div>'
        f'<div class="if-draft-grid">'
        f'<div class="if-draft-card"><div class="if-draft-label">{_u(locale, "內部紀錄（日文）", "社内メモ")}</div>'
        f'{internal_notes_html(draft["internal_summary_ja"])}</div>'
        f'<div class="if-draft-card"><div class="if-draft-label">{_u(locale, "客戶回覆草稿", "顧客向け返信案")} · {html.escape(draft["reply_language"])}</div>{reply_html}</div>'
        f'</div>'
        f'</div>',
        unsafe_allow_html=True,
    )
    with st.expander(_u(locale, '草稿來源與技術紀錄', '返信案の出典・技術記録')):
        st.markdown(f'<div class="if-source-list">{source_chips}</div>', unsafe_allow_html=True)
        st.caption(f'{draft["template_version"]} · {draft["status"]} · ' + _u(locale, '尚未寄出', '未送信'))

