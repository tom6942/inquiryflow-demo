"""Scoped visual language and escaped presentation for the public demo."""
import html
import re

def theme_css(dark=False):
    colors = ({'bg':'#111c19','paper':'#192823','field':'#20332c','ink':'#edf3ef','muted':'#afc1b6','line':'#354c40','accent':'#a4d4b8','solid':'#2e7054','soft':'#243f31','gold':'#dfc392','warning':'#3d3322','danger':'#dca59b'} if dark else
              {'bg':'#f5f5f1','paper':'#ffffff','field':'#f6f8f5','ink':'#243c33','muted':'#596e61','line':'#dce4dc','accent':'#216447','solid':'#235f46','soft':'#ecf3ec','gold':'#9c7843','warning':'#faf3e5','danger':'#9c453b'})
    variables=';'.join('--if-'+k+':'+v for k,v in colors.items())
    return '<style>:root,.stApp{'+variables+';color-scheme:'+('dark' if dark else 'light')+';}'+'''
.stApp,[data-testid="stAppViewContainer"],[data-testid="stMain"] {background:var(--if-bg)!important;color:var(--if-ink)!important;}
.block-container {max-width:920px!important;padding:3.1rem 1.5rem 4rem!important;}
[data-testid="stHeader"] {background:var(--if-bg)!important;z-index:900!important;}
.stApp,button,input,textarea {font-family:-apple-system,BlinkMacSystemFont,"Noto Sans JP","Hiragino Kaku Gothic ProN","Yu Gothic",sans-serif;}
h1,h2,h3,p,label,li,[data-testid="stWidgetLabel"] {color:var(--if-ink);}
h1 {font-size:1.9rem!important;letter-spacing:-.025em;font-weight:650!important;}
h2 {font-size:1.42rem!important;letter-spacing:-.02em;font-weight:600!important;padding-top:.5rem!important;}
h3 {font-size:1.05rem!important;font-weight:600!important;}
[data-testid="stCaptionContainer"] p {color:var(--if-muted)!important;font-size:.8rem!important;line-height:1.6;}
[data-testid="stMarkdownContainer"] p {line-height:1.7;}
.hero {background:linear-gradient(110deg,#153c2e,#265b44);border-radius:15px;padding:1.65rem 1.8rem;margin:.1rem 0 1rem;border:1px solid #47715a;position:relative;overflow:hidden;}
.hero::after {content:"";position:absolute;width:210px;height:210px;border:1px solid #b5d1ba24;border-radius:50%;right:-50px;top:-90px;pointer-events:none;}
.hero h1 {color:#f2f6ef!important;font-size:2.05rem!important;margin:.5rem 0 .65rem!important;padding:0!important;}
.hero p {color:#e1ebe0!important;font-size:.91rem;max-width:42em;margin:0;}
.hero small {color:#c0d5bf;letter-spacing:.15em;font-size:.67rem;font-weight:550;}
[data-testid="stRadioGroup"] {gap:.1rem;border-bottom:1px solid var(--if-line);padding:0 0 .45rem;margin-bottom:.8rem;}
[data-testid="stRadioOption"] {padding:.55rem .7rem!important;border-bottom:2px solid transparent;transition:background .15s;}
[data-testid="stRadioOption"]>div>div:not([data-testid="stMarkdownContainer"]) {display:none;}
[data-testid="stRadioOption"] p {color:var(--if-muted)!important;font-size:.86rem!important;white-space:nowrap;}
[data-testid="stRadioOption"][data-selected="true"] {border-bottom-color:var(--if-accent);}
[data-testid="stRadioOption"][data-selected="true"] p {color:var(--if-accent)!important;font-weight:600;}
[data-testid="stRadioOption"]:hover {background:var(--if-soft);}
[data-testid="stRadioOption"][data-focus-visible="true"] {outline:2px solid var(--if-gold);outline-offset:2px;}
textarea,input,[data-baseweb="input"],[data-baseweb="textarea"],[data-baseweb="base-input"] {background:var(--if-field)!important;color:var(--if-ink)!important;caret-color:var(--if-accent)!important;}
textarea {font-size:.9rem!important;line-height:1.7!important;}
textarea::placeholder,input::placeholder {color:var(--if-muted)!important;opacity:1;}
[data-baseweb="select"] div {color:var(--if-ink);}
[data-baseweb="select"]>div {background:var(--if-paper)!important;border:1px solid var(--if-line)!important;border-radius:9px!important;}
[data-baseweb="select"] svg {fill:var(--if-ink)!important;background:var(--if-paper)!important;}
.react-aria-ComboBox [role="group"] {background:var(--if-paper)!important;border:1px solid var(--if-line)!important;border-radius:9px!important;overflow:hidden;}
.react-aria-ComboBox input {background:var(--if-paper)!important;border:0!important;}
.react-aria-ComboBox button {background:var(--if-paper)!important;color:var(--if-ink)!important;border:0!important;}
.react-aria-ComboBox svg {color:var(--if-ink)!important;fill:currentColor!important;}
[role="listbox"],[role="option"],[data-baseweb="menu"],[data-baseweb="popover"] {background:var(--if-paper)!important;color:var(--if-ink)!important;}
[role="option"][aria-selected="true"] {background:var(--if-soft)!important;}
[data-testid="stExpander"] details,[data-testid="stForm"] {background:var(--if-paper)!important;color:var(--if-ink)!important;border:1px solid var(--if-line)!important;border-radius:10px!important;}
[data-testid="stExpander"] summary {background:transparent!important;color:var(--if-ink)!important;font-size:.86rem;}
[data-testid="stExpander"] summary p {font-size:.86rem!important;font-weight:500;}
[data-testid="stExpander"] summary svg {fill:var(--if-muted)!important;}
.stButton button,.stDownloadButton button,.stFormSubmitButton button,[data-testid="stPopoverButton"] {background:var(--if-paper)!important;color:var(--if-ink)!important;border:1px solid var(--if-line)!important;border-radius:9px!important;min-height:40px;padding:.5rem .85rem;box-shadow:none!important;}
.stButton button p,.stDownloadButton button p,.stFormSubmitButton button p,[data-testid="stPopoverButton"] p {color:inherit!important;font-size:.87rem!important;font-weight:500;}
button[kind="primary"] {background:var(--if-solid)!important;color:#fff!important;border-color:var(--if-solid)!important;}
button[kind="primary"] * {color:#fff!important;}
button:disabled {opacity:.5;}
button:not(:disabled):hover {border-color:var(--if-accent)!important;}
button:focus-visible,textarea:focus-visible,input:focus-visible {outline:2px solid var(--if-gold)!important;outline-offset:3px;}
[data-testid="stHeader"] button {color:var(--if-ink)!important;}
[data-testid="stTable"] table,[data-testid="stTable"] th,[data-testid="stTable"] td {background:var(--if-paper)!important;color:var(--if-ink)!important;border-color:var(--if-line)!important;line-height:1.65;font-size:.87rem;}
[data-testid="stTable"] th {font-weight:500!important;color:var(--if-muted)!important;}
[data-testid="stAlert"] {background:var(--if-soft)!important;color:var(--if-ink)!important;border:1px solid var(--if-line)!important;border-radius:9px;padding:.65rem .85rem;}
[data-testid="stAlert"] p {color:var(--if-ink)!important;font-size:.86rem!important;}
[data-testid="stJson"],[data-testid="stCode"] {background:var(--if-field)!important;color:var(--if-ink)!important;}
.st-key-public_settings {position:fixed;left:1.1rem;top:.65rem;z-index:10000;width:38px;}
.st-key-public_theme_control {position:fixed;right:15rem;top:.65rem;z-index:10000;width:38px;}
.st-key-public_settings button,.st-key-public_theme_control button {width:36px;min-height:36px;padding:0!important;border-radius:50%!important;}
[data-testid="stPopoverBody"] {background:var(--if-paper)!important;color:var(--if-ink)!important;max-width:360px;}
button[data-variant="pills"] {background:var(--if-paper)!important;color:var(--if-muted)!important;border:1px solid var(--if-line)!important;border-radius:6px!important;}
button[data-variant="pills"] p {color:inherit!important;font-size:.78rem!important;}
button[data-variant="pills"][aria-checked="true"] {background:var(--if-soft)!important;color:var(--if-accent)!important;border-color:var(--if-accent)!important;}
[role="tooltip"],[data-testid="stTooltipContent"] {background:var(--if-paper)!important;border:1px solid var(--if-line)!important;color:var(--if-ink)!important;}
[role="tooltip"] *,[data-testid="stTooltipContent"] * {color:var(--if-ink)!important;}
.reply {max-width:44em;margin:0 auto;padding:.2rem .25rem;color:var(--if-ink);font-size:.94rem;line-height:1.75;overflow-wrap:anywhere;white-space:normal;}
.reply p {font-size:inherit!important;line-height:inherit!important;margin:0 0 1em!important;color:var(--if-ink)!important;}
.reply p:last-child {margin-bottom:0!important;}
.st-key-reply_panel,.st-key-approval_panel,.st-key-crm_panel {background:var(--if-paper);border-color:var(--if-line)!important;border-radius:13px!important;padding:1.15rem!important;}
.st-key-approval_panel {border-top:3px solid var(--if-accent)!important;}
.if-internal-section {line-height:1.7;margin-bottom:1rem!important;}
.if-draft-label {color:var(--if-accent);font-size:.8rem;letter-spacing:.04em;font-weight:600;margin-bottom:.3rem;}
.if-draft-text {color:var(--if-ink);font-size:.9rem;line-height:1.7;}
.case-heading {display:flex;justify-content:space-between;align-items:center;gap:1rem;margin:1rem 0 .5rem;}
.case-heading h3 {margin:0;padding:0;font-size:1.2rem!important;}.case-heading small {font-size:.75rem;color:var(--if-muted);display:block;margin-bottom:.25rem;}
.chip {display:inline-flex;align-items:center;border-radius:5px;padding:.22rem .5rem;font-size:.75rem;line-height:1.5;font-weight:500;background:var(--if-soft);color:var(--if-accent);margin:0 .25rem .2rem 0;border:1px solid var(--if-line);}
.chip.warn {background:var(--if-warning);color:var(--if-gold);}.chip.danger {color:var(--if-danger);}
.record-stats {display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--if-line);border-radius:12px;background:var(--if-paper);margin:.6rem 0 1rem;}
.record-stats>div {padding:.65rem .85rem;border-right:1px solid var(--if-line);}.record-stats>div:last-child{border:0;}
.record-stats span {font-size:.74rem;color:var(--if-muted);display:block;}.record-stats b {font-size:1.35rem;font-weight:550;display:block;margin-top:.1rem;}
.statusbar {padding:.55rem .75rem;border-left:3px solid var(--if-accent);background:var(--if-soft);border-radius:6px;font-size:.84rem;color:var(--if-ink);margin:.4rem 0 .8rem;}
.facts {display:grid;grid-template-columns:1fr 1fr;gap:0 1.8rem;}.facts div {padding:.65rem 0;border-bottom:1px solid var(--if-line);}.facts dt {font-size:.75rem;color:var(--if-muted);margin-bottom:.25rem;}.facts dd {margin:0;font-size:.94rem;color:var(--if-ink);font-weight:500;}
.sample-brief {border-left:3px solid var(--if-accent);padding:.7rem 1rem;background:var(--if-soft);margin:.2rem 0 .8rem;border-radius:0 8px 8px 0;}
.sample-brief span,.section-eyebrow {color:var(--if-accent);font-size:.8rem;font-weight:600;letter-spacing:.02em;}
.sample-brief p {margin:.35rem 0 0;font-size:.9rem;}
.decision-box {border-left:3px solid var(--if-gold);padding:.4rem 0 .4rem .9rem;}
.decision-box h3 {margin:.3rem 0;}.decision-box p {font-size:.9rem;}
.evaluation-scoreboard {display:grid;grid-template-columns:repeat(3,1fr);gap:.6rem;margin:.5rem 0 1rem;}
.evaluation-scoreboard>div {border:1px solid var(--if-line);background:var(--if-paper);border-radius:10px;padding:.85rem 1rem;border-top:3px solid var(--if-accent);}
.evaluation-scoreboard>.fail {border-top-color:var(--if-danger);}.evaluation-scoreboard>.pending {border-top-color:var(--if-gold);}
.evaluation-scoreboard span {display:block;font-size:.8rem;color:var(--if-muted);}.evaluation-scoreboard strong{font-size:1.8rem;font-weight:550;color:var(--if-ink);}
.st-key-request_panel,.st-key-decision_panel {background:var(--if-paper);border-color:var(--if-line)!important;border-radius:13px!important;padding:1rem!important;}
@media(max-width:600px) {.block-container {padding:3rem 1rem 3rem!important;}.hero{padding:1.3rem;}.hero h1{font-size:1.8rem!important;}[data-testid="stRadioOption"]{padding:.4rem .45rem!important;}[data-testid="stRadioOption"] p{font-size:.78rem!important;}.record-stats{grid-template-columns:repeat(2,1fr);}.record-stats>div:nth-child(2){border-right:0;}.facts{grid-template-columns:1fr;}.case-heading{align-items:flex-start;}.st-key-public_theme_control{right:auto;left:3.9rem;}}
@media(prefers-reduced-motion:no-preference) {button{transition:border-color .15s,background .15s;}}
</style>'''

def reply_html(text):
    paragraphs=re.split(r'\n\s*\n',text.replace('\r\n','\n').strip())
    return '<div class="reply">'+''.join('<p>'+html.escape(p.strip()).replace('\n','<br>')+'</p>' for p in paragraphs if p.strip())+'</div>'

def case_state(case, snapshot=None):
    status=case['status']
    if status=='CLOSED': return '対応完了','done'
    if case.get('decision_snapshot',{}).get('automatic_actions_blocked'): return '担当者が分割','warn'
    if status=='REJECTED': return '差し戻し','danger'
    if status=='ACTION_FAILED': return '登録エラー','danger'
    if status=='ACTIONED':
        tasks=(snapshot or {}).get('tasks',[])
        if tasks and all(t.get('task_status')=='COMPLETED' for t in tasks): return '案件の完了待ち','ready'
        return 'フォロー中','active'
    if status in ('APPROVED','EXECUTING'): return '登録処理中','warn'
    return '承認待ち','review'

def case_heading_html(case,snapshot=None):
    label,tone=case_state(case,snapshot)
    company=case.get('extraction',{}).get('company_name') or '会社名未記載'
    rev=next(r for r in case['revisions'] if r['revision_id']==case['current_revision_id'])
    priority=case.get('decision_snapshot',{}).get('priority','NORMAL')
    priority_chip='<span class="chip warn">優先対応</span>' if priority=='HIGH' else ''
    return '<div class="case-heading"><div><small>'+html.escape(case['display_id'])+'</small><h3>'+html.escape(company)+'</h3></div><div>'+priority_chip+'<span class="chip '+tone+'">'+label+'</span><span class="chip">第'+str(rev['revision_no'])+'版</span></div></div>'

def facts_html(pairs):
    return '<dl class="facts">'+''.join('<div><dt>'+html.escape(k)+'</dt><dd>'+html.escape(str(v or '未確認'))+'</dd></div>' for k,v in pairs)+'</dl>'

def extraction_rows(extraction):
    """Display actual extracted values with their original evidence, never inferred gold."""
    e=extraction
    evidence=e.get('field_evidence') or {}
    q=e.get('purchase_quantity') or {}
    support=e.get('support') or {}
    quantity=(support.get('affected_quantity') or {}) if e.get('intent')=='Support' else q
    support_evidence=support.get('field_evidence') or {}
    values=[('会社',e.get('company_name'),evidence.get('company_name')),
            ('商品',e.get('product'),evidence.get('product')),
            ('破損数量' if e.get('intent')=='Support' else '購入数量',quantity.get('raw'),support_evidence.get('affected_quantity') if e.get('intent')=='Support' else evidence.get('purchase_quantity')),
            ('配送先',{'TW':'台湾','HK':'香港','SG':'シンガポール'}.get(e.get('country'),e.get('country')),evidence.get('country'))]
    if e.get('intent')=='Support':
        values.append(('注文番号',support.get('order_id'),support_evidence.get('order_id')))
    else:
        values.append(('予算',(e.get('budget') or {}).get('raw'),evidence.get('budget')))
    values.append(('希望日',(e.get('timeline') or {}).get('raw'),evidence.get('timeline')))
    return [{'項目':label,'読み取った内容':value or '単一欄には未設定','原文の該当箇所':(proof or {}).get('quote') or '対応する引用なし'} for label,value,proof in values]

def decision_html(decision):
    blocked=decision.get('automatic_actions_blocked',False)
    missing=decision.get('missing_information') or []
    heading='担当者による分割が必要' if blocked else '返信案の確認・承認が必要'
    commercial=(decision.get('reply_boundary') or {}).get('needs_human_confirmation')
    reason='複数の条件を1件にまとめると情報が失われるため、自動登録を止めています。' if blocked else ('価格・出荷条件などの確約と、返信案の承認は担当者が行います。' if commercial else '回答の根拠と返信案を担当者が確認してから、登録に進みます。')
    rows=[('顧客に確認すること','下記の不足情報を確認' if missing else '現時点で追加質問なし')]
    rows.append(('登録の制御','自動登録を禁止' if blocked else '承認した版だけを1回登録'))
    return '<div class="decision-box"><div class="section-eyebrow">担当者が判断すること</div><h3>'+heading+'</h3><p>'+reason+'</p>'+facts_html(rows)+'</div>'
