"""Deterministic Day 5 business decisions built on extracted inquiry data.

The language model identifies what the customer wrote.  This module owns
company policy: priority, required follow-up, human-review gates and the next
recommended action.  Keeping those decisions here makes them repeatable and
auditable.
"""
from __future__ import annotations

import re

from .schema import Extraction, missing_fields
from .representation import representation_limits, has_complete_item_delivery_dates

DECISION_RULES_VERSION = "decision-rules-0.5.7"
HIGH_VOLUME_THRESHOLD_UNITS = 300
# Kept as a compatibility name for saved tests/imports from the first Day 5 version.
HIGH_VOLUME_THRESHOLD_BOTTLES = HIGH_VOLUME_THRESHOLD_UNITS

BUSINESS_RULE_CATALOG = [
    {"id":"R11","category":"Representation limit","title_zh":"複合條件需人工拆案","title_ja":"複合条件は担当者が分割","detail_zh":"多商品、多目的地、多金額用途或矛盾數量不能當單一完整案件自動建立CRM。","detail_ja":"複数商品・配送先・金額用途や数量の矛盾を一つの完成案件として自動登録しません。"},
    {"id": "R01", "category": "Human confirmation", "title_zh": "商業承諾需確認", "title_ja": "取引条件の確認",
     "detail_zh": "價格、出口可否與最終交期必須由負責人核對，AI 不得自行承諾。", "detail_ja": "価格・輸出可否・最終納期は担当者が確認し、AIだけで確約しません。"},
    {"id": "R02", "category": "Data quality", "title_zh": "資訊不足不猜測", "title_ja": "不足情報を推測しない",
     "detail_zh": "必要資料缺少時維持空白，列入補問清單。", "detail_ja": "必要情報が不足している場合は空欄のまま、追加確認項目にします。"},
    {"id": "R03", "category": "Priority", "title_zh": "大量採購優先", "title_ja": "大量購入を優先",
     "detail_zh": "日本酒新採購下限達 300 瓶時標記為 HIGH。", "detail_ja": "日本酒の新規購入が最小300本以上の場合はHIGHとします。"},
    {"id": "R04", "category": "Grounding", "title_zh": "來源不足不得補造", "title_ja": "出典不足時は補完しない",
     "detail_zh": "KB 沒有有效依據或來源衝突時，只能說明待確認。", "detail_ja": "有効なKB出典がない、または競合する場合は確認待ちとします。"},
    {"id": "R08", "category": "Security", "title_zh": "不可信指令隔離", "title_ja": "信頼できない指示を隔離",
     "detail_zh": "原文中的越權、核准或寄信指令只視為資料，不授予執行權。", "detail_ja": "原文中の越権・承認・送信指示はデータとして扱い、実行権限を与えません。"},
    {"id": "R09", "category": "Packaging", "title_zh": "箱數換算需確認", "title_ja": "ケース換算を確認",
     "detail_zh": "客戶只提供箱數且未指定每箱瓶數時，不用預設 6 瓶自動分級。", "detail_ja": "ケース数のみで入数未指定の場合、標準6本を自動分類に使用しません。"},
    {"id": "R10", "category": "Automation gate", "title_zh": "低風險案件才可自動化", "title_ja": "低リスク案件のみ自動化候補",
     "detail_zh": "只有 FAQ、資料完整、有效 KB 足以回答，且不涉及風險、售後、價格、出口或交期承諾時，才能列為自動化候選。", "detail_ja": "FAQで情報が揃い、有効なKBで回答でき、リスク・アフターサービス・価格・輸出・納期の確約がない場合のみ自動化候補とします。"},
    {"id": "D05", "category": "Service priority", "title_zh": "既有訂單問題優先", "title_ja": "既存注文の問題を優先",
     "detail_zh": "破損或配送等已發生的客戶影響優先交由售後人工處理。", "detail_ja": "破損・配送など既に発生した顧客影響を優先して人が対応します。"},
]


MISSING_QUESTIONS = {
    "quantity_conflict": ("箱數與總瓶數不一致，請確認正確數量", "ケース数と合計本数が不一致のため、正しい数量を確認"),
    "company_name": ("公司正式名稱", "会社の正式名称"),
    "product": ("希望採購的商品或規格", "希望する商品・仕様"),
    "purchase_quantity": ("預計採購數量與單位", "購入予定数量と単位"),
    "purchase_quantity.case_pack_size": (
        "請確認具體總瓶數，或指定每箱瓶數（本公司預設參考為 6 瓶／箱，仍需確認）",
        "合計本数、または1ケース当たりの本数を確認（当社の参考標準は6本／ケースだが、要確認）",
    ),
    "budget": ("如有指定的報價／結算幣別請告知；未指定時由業務使用標準報價幣別", "見積もり・決済通貨の指定があればご連絡ください。指定がない場合は当社標準通貨で見積もります"),
    "preferred_delivery_date": ("希望到貨日期（完整年月日）", "希望到着日（年月日）"),
    "support.order_id": ("相關訂單編號", "該当する注文番号"),
    "support.description": ("問題的具體情況", "問題の具体的な状況"),
    "support.affected_quantity": ("受影響數量與單位", "影響を受けた数量と単位"),
    "support.product": ("破損商品名稱、規格或 SKU", "破損商品の名称・規格・SKU"),
    "support.photos": ("破損商品與外箱照片", "破損商品と外箱の写真"),
    "support.received_date": ("實際收貨日期", "実際の受取日"),
    "destination_country": ("出口目的國家／地區", "輸出先の国・地域"),
    "importer_arrangement": ("當地進口商與酒類進口資格安排", "現地輸入者と酒類輸入資格の手配状況"),
}


def _add_reason(reasons: list[dict], rule_id: str, title: str, detail: str,
                title_ja: str, detail_ja: str) -> None:
    if not any(item["rule_id"] == rule_id for item in reasons):
        reasons.append({"rule_id": rule_id, "title": title, "detail": detail,
                        "title_ja": title_ja, "detail_ja": detail_ja})


def explicit_case_pack_size(raw: str | None) -> int | None:
    """Read only an exact pack size explicitly written by the customer.

    A company default is never used here. Ranges such as 4–10 remain unknown
    because they do not establish the actual bottle equivalent.
    """
    if not raw:
        return None
    patterns = (
        r"每箱\s*(\d+)\s*(?:瓶|支|本)",
        r"1\s*箱(?:裝)?\s*(\d+)\s*(?:瓶|支|本)",
        r"1\s*ケース(?:あたり|当たり|入り)?\s*(\d+)\s*本",
        r"(\d+)\s*本\s*(?:入り|入)\s*(?:の)?\s*ケース",
        r"(\d+)\s*bottles?\s+per\s+case",
        r"case(?:s)?\s+of\s+(\d+)\s*bottles?",
    )
    for pattern in patterns:
        match = re.search(pattern, raw, flags=re.IGNORECASE)
        if match:
            return int(match.group(1))
    return None


def select_reply_language(result: Extraction) -> tuple[str, str]:
    """Choose an outbound language from customer wording and regional context."""
    represented = {item.code for item in result.languages}
    regional = {
        "TW": "zh-TW", "HK": "zh-TW", "MO": "zh-TW", "JP": "ja",
    }.get(result.country)
    if regional and regional in represented:
        return regional, f"市場為 {result.country}，且來信有使用當地語言"
    primary = result.language if result.language in {"zh-TW", "en", "ja"} else "zh-TW"
    return primary, "未命中地區語言條件，使用原文主要語言"


def _mentions_photos(text: str) -> bool:
    # Keep availability claims in the photo clause, rather than interpreting an
    # unrelated unknown delivery date as a statement that photos are missing.
    photo_parts = [part for part in re.split(r"[。.!?！？;；，,\n]+", text)
                   if re.search(r"照片|相片|写真|photos?|images?", part, re.I)]
    if not photo_parts:
        return False
    unavailable = (
        r"(?:尚未|未附|沒有|稍後|之後).{0,12}(?:照片|相片|写真)|"
        r"(?:照片|相片|写真)(?:は|が|目前|現在)?\s*(?:尚未|未拍|未附|稍後|未撮影|未添付|まだ撮影していません)|"
        r"(?:photos?|images?).{0,24}(?:not attached|later|not available)|"
        r"(?:no|without).{0,10}(?:photos?|images?)"
    )
    return not any(re.search(unavailable,part,re.I) for part in photo_parts)


def _mentions_received_date(text: str) -> bool:
    return bool(re.search(
        r"(?:收[到貨]|受領|受取|到着|deliver(?:ed|y)|receiv(?:ed|al)).{0,18}(?:20\d{2}[-/.年]\d{1,2}|\d{1,2}月\d{1,2}日)|"
        r"(?:20\d{2}[-/.年]\d{1,2}|\d{1,2}月\d{1,2}日).{0,18}(?:收[到貨]|受領|受取|到着|deliver(?:ed|y)|receiv(?:ed|al))",
        text, re.IGNORECASE,
    ))


def _mentions_importer_arrangement(text: str) -> bool:
    # Mentioning a requirement is not evidence that it has been arranged.
    importer_pattern = r"進口商|輸入業者|輸入者|importer"
    qualification_pattern = r"進口資格|輸入資格|licen[cs]e|資格"
    relevant = [part for part in re.split(r"[。.!?！？;；\n]+", text)
                if re.search(importer_pattern + "|" + qualification_pattern, part, re.I)]
    if not relevant:
        return False
    unknown = (
        r"尚未|未確認|未安排|未定|沒有|没有|不明|待確認|待安排|還沒|还没|"
        r"確認していません|確認できていません|手配していません|手配できていません|"
        r"手配中|手配しているところ|まだ手配|未手配|未確定|決まっていません|ありません|わからない|分からない|必要です|"
        r"\b(?:not|no|without|unknown|unconfirmed|undecided|pending)\b|(?:haven|hasn|isn|aren)[’']t|"
        r"(?:need|require)\w*\s+(?:an?\s+)?(?:importer|licen[cs]e)"
    )
    if any(re.search(unknown, part, re.I) for part in relevant):
        return False
    evidence = " ".join(relevant)
    if not (re.search(importer_pattern, evidence, re.I)
            and re.search(qualification_pattern, evidence, re.I)):
        return False
    # Explicit arrangement/status assertions only; never infer validity from nouns.
    affirmed = r"已安排|已確認|已具備|已取得|已備妥|有.*資格|手配済|手配(?:は|が)?(?:済んで|完了)|手配を済ませ|確認済|資格があります|保有|取得済|\b(?:arranged|confirmed|secured|licensed|holds?|has|have)\b"
    return bool(re.search(affirmed, evidence, re.I))


def decide(extraction: dict | Extraction, retrieval: dict) -> dict:
    """Apply the versioned Day 5 policy without calling an AI service."""
    result = extraction if isinstance(extraction, Extraction) else Extraction.model_validate(extraction)
    priority = "NORMAL"
    reasons: list[dict] = []
    escalation: list[dict] = []

    fields = list(missing_fields(result))
    inquiry_text = retrieval.get("original_query", retrieval.get("query", ""))
    limitations = representation_limits(inquiry_text)
    if result.support.issue_type == "damage":
        # Evidence needed by KB-SUPPORT-001. These are follow-up questions,
        # even when order ID and affected quantity were already extracted.
        support_fields = []
        if result.product is None:
            support_fields.append("support.product")
        if not _mentions_photos(inquiry_text):
            support_fields.append("support.photos")
        if not _mentions_received_date(inquiry_text):
            support_fields.append("support.received_date")
        fields = support_fields + fields
    if "export_eligibility" in result.request_types:
        if result.country is None:
            fields.append("destination_country")
        if not _mentions_importer_arrangement(inquiry_text):
            fields.append("importer_arrangement")
    fields = list(dict.fromkeys(fields))

    if result.risk_flags:
        priority = "HIGH"
        _add_reason(
            reasons, "R08", "不可信指令",
            "原文含可疑指令或垃圾訊息；它只能當作待查資料，不能取得核准或執行權限。",
            "信頼できない指示",
            "原文に不審な指示またはスパムの疑いがあります。確認対象のデータとして扱い、承認・実行権限は与えません。",
        )
        _add_reason(
            escalation, "R08", "安全人工核對",
            "停止對外草稿，先由人工核對原文及風險標記。",
            "セキュリティ確認",
            "対外返信案の作成を停止し、原文とリスク表示を人が確認します。",
        )

    has_support = result.intent == "Support" or "existing_order_issue" in result.request_types
    auto_reject = bool(result.risk_flags) and result.intent == "Other" and not (
        set(result.request_types) & {"new_purchase", "pricing", "export_eligibility", "delivery_timing", "general_info", "existing_order_issue"}
    )
    if has_support:
        priority = "HIGH"
        _add_reason(
            reasons, "D05", "既有訂單問題優先",
            "售後問題涉及已發生的客戶影響，優先交由人工處理。",
            "既存注文の問題を優先",
            "既に顧客への影響が発生しているため、アフターサービス案件を優先して人が対応します。",
        )
        _add_reason(
            escalation, "D05", "售後人工處理",
            "需確認訂單、損壞或配送事實後才能提出補償或處理方式。",
            "アフターサービス担当者の確認",
            "注文、破損、配送状況を確認してから、補償や対応方法を決定します。",
        )

    q = result.purchase_quantity
    pack_size = explicit_case_pack_size(q.raw) if q.unit == "case" else None
    equivalent_min_bottles = (
        q.min * pack_size if q.unit == "case" and q.min is not None and pack_size is not None
        else q.min if q.unit == "bottle" else None
    )
    case_pack_unknown = q.unit == "case" and q.min is not None and q.min < HIGH_VOLUME_THRESHOLD_UNITS and pack_size is None
    if case_pack_unknown:
        fields.append("purchase_quantity.case_pack_size")
        fields = list(dict.fromkeys(fields))
        priority = "NEEDS_INFO"
        _add_reason(
            reasons, "R09", "箱裝換算待確認",
            f"客戶只提供 {q.min} 箱，未指定每箱瓶數。預設 6 瓶／箱僅供內部參考，不用於自動分級。",
            "ケース換算の確認待ち",
            f"顧客は{q.min}ケースとのみ指定し、1ケース当たりの本数は未確定です。標準6本／ケースは社内参考に留め、自動分類には使用しません。",
        )
    product = " ".join(filter(None, [result.product, result.product_name_zh])).lower()
    high_volume = (
        result.intent == "Sales"
        and "new_purchase" in result.request_types
        and q.unit in {"bottle", "case"}
        and q.min is not None
        and (
            (q.unit == "case" and q.min >= HIGH_VOLUME_THRESHOLD_UNITS)
            or (equivalent_min_bottles is not None and equivalent_min_bottles >= HIGH_VOLUME_THRESHOLD_UNITS)
        )
        and ("日本酒" in product or "sake" in product)
    )
    if high_volume:
        priority = "HIGH"
        unit_zh = "箱" if q.unit == "case" else "瓶"
        unit_ja = "ケース" if q.unit == "case" else "本"
        conversion_zh = f"（客戶指定 {pack_size} 瓶／箱，換算下限 {equivalent_min_bottles} 瓶）" if pack_size else ""
        conversion_ja = f"（顧客指定{pack_size}本／ケース、換算下限{equivalent_min_bottles}本）" if pack_size else ""
        _add_reason(
            reasons, "R03", "Demo 大量採購門檻",
            f"日本酒新採購的數量下限為 {q.min} {unit_zh}{conversion_zh}，命中示範門檻 ≥{HIGH_VOLUME_THRESHOLD_UNITS} 瓶。",
            "デモ用の大量購入基準",
            f"日本酒の新規購入数量の下限が{q.min}{unit_ja}{conversion_ja}で、デモ基準の{HIGH_VOLUME_THRESHOLD_UNITS}本以上に該当します。",
        )

    commitment_types = set(result.request_types) & {"pricing", "export_eligibility", "delivery_timing"}
    if commitment_types:
        _add_reason(
            escalation, "R01", "商業承諾需確認",
            "價格、出口可否或交期不能由模型自行承諾，需由負責人核對最新條件。",
            "取引条件の確認",
            "価格、輸出可否、納期をモデルだけで確約せず、担当者が最新条件を確認します。",
        )

    if fields:
        _add_reason(
            reasons, "R02", "資訊尚未完整",
            f"目前有 {len(fields)} 項必要資訊待補充；未知值維持空白，不由系統猜測。",
            "情報不足",
            f"必要情報が{len(fields)}項不足しています。不明な値は空欄のままとし、システムで推測しません。",
        )

    coverage_incomplete = retrieval.get("answer_coverage", {}).get("status") == "PARTIAL"
    retrieval_status = "PARTIAL" if coverage_incomplete else retrieval.get("status", "ERROR")
    if retrieval_status != "FOUND":
        _add_reason(
            escalation, "R04", "來源不足或有衝突",
            "目前沒有可直接支持答案的有效來源，或同時找到需排除的來源；不可補造公司資訊。",
            "出典不足または競合",
            "回答を直接裏付ける有効な出典がない、または除外対象の出典があるため、会社情報を補って作成しません。",
        )

    blocked = bool(result.risk_flags)
    if auto_reject:
        escalation = []
        action = "REJECT_INPUT"
        action_zh = "直接阻擋無有效業務需求的越權或垃圾訊息；不建立人工待辦"
        action_ja = "有効な業務要望のない不正指示・スパムをブロックし、人の対応待ちは作成しない"
    elif blocked:
        action = "SECURITY_REVIEW"
        action_zh = "先做安全人工核對；目前不產生對外回覆草稿"
        action_ja = "セキュリティ担当者が確認し、現時点では対外返信案を作成しない"
    elif has_support:
        action = "SUPPORT_REVIEW"
        action_zh = "由售後負責人核對訂單與影響後，準備處理及回覆"
        action_ja = "アフターサービス担当者が注文と影響を確認して対応案を作成する"
    elif retrieval_status != "FOUND":
        action = "MANUAL_RESEARCH"
        action_zh = "先補查可靠資料；只能回覆待確認或追問必要資訊"
        action_ja = "信頼できる資料を追加確認し、確認中または不足情報のみを返信する"
    elif fields:
        action = "REQUEST_INFORMATION"
        action_zh = "先請客戶補充必要資訊，再由負責人確認條件"
        action_ja = "必要情報を顧客に確認し、その後担当者が条件を確認する"
    elif commitment_types:
        action = "BUSINESS_REVIEW"
        action_zh = "由業務人員確認價格、出口或交期後再回覆"
        action_ja = "営業担当者が価格・輸出・納期を確認してから返信する"
    else:
        action = "PREPARE_SOURCE_BASED_REPLY"
        action_zh = "根據有效來源準備草稿，送人工核對"
        action_ja = "有効な出典に基づく返信案を作成し、人が確認する"

    reply_language, reply_language_reason = select_reply_language(result)
    reply_language_reason_ja = (
        f"市場が{result.country}で、問い合わせに現地言語が使われているため選択しました。"
        if reply_language_reason.startswith("市場為") else
        "地域言語の条件に該当しないため、原文の主要言語を使用します。"
    )

    action_steps = []
    if fields:
        action_steps.append({
            "code": "CONFIRM_MISSING_INFORMATION",
            "label_zh": "確認缺少的客戶、數量、日期或包裝資訊",
            "label_ja": "顧客・数量・日付・梱包の不足情報を確認する",
        })
    if has_support:
        action_steps.append({
            "code": "VERIFY_SUPPORT_FACTS", "label_zh": "由售後人員核對訂單、破損與配送事實",
            "label_ja": "アフターサービス担当者が注文・破損・配送事実を確認する",
        })
    if retrieval_status != "FOUND":
        action_steps.append({
            "code": "RESEARCH_SOURCES", "label_zh": "補查可靠且有效的公司或法規來源",
            "label_ja": "信頼できる有効な社内・法規出典を追加確認する",
        })
    if commitment_types:
        action_steps.append({
            "code": "VERIFY_COMMERCIAL_TERMS", "label_zh": "由負責人確認價格、出口可否與最終交期",
            "label_ja": "担当者が価格・輸出可否・最終納期を確認する",
        })
    action_steps.append({
        "code": "REVIEW_DRAFT", "label_zh": "編輯草稿並交由人工審核，核准前不寄出",
        "label_ja": "返信案を編集し、人の承認後に送信する",
    })
    if auto_reject:
        action_steps = [{"code": "REJECT_INPUT", "label_zh": "系統直接阻擋，保留紀錄，不加入人工待辦", "label_ja": "自動ブロックし、記録のみ保持。人の対応待ちには追加しない"}]

    confirmation_map = {
        "pricing": ("最終價格、折扣與報價有效期", "最終価格・値引き・見積有効期限"),
        "export_eligibility": ("本案最終出口可否與當地資格", "本件の最終的な輸出可否と現地資格"),
        "delivery_timing": ("真實庫存與最終到貨日", "実在庫と最終到着日"),
    }
    needs_confirmation = [
        {"code": key.upper(), "label_zh": confirmation_map[key][0], "label_ja": confirmation_map[key][1]}
        for key in ("pricing", "export_eligibility", "delivery_timing") if key in commitment_types
    ]
    if has_support:
        needs_confirmation.append({
            "code": "SUPPORT_REMEDY", "label_zh": "補寄、退款或其他售後處理方式",
            "label_ja": "再送・返金・その他のアフターサービス対応",
        })
    if limitations and not auto_reject:
        priority = "HIGH" if has_support or blocked else "NEEDS_INFO"
        codes = {item["code"] for item in limitations}
        if codes & {"MULTIPLE_PRODUCTS", "MULTIPLE_DESTINATIONS", "MULTIPLE_MONEY_BASES"}:
            fields = [field for field in fields if field not in {"product", "purchase_quantity", "destination_country", "budget"}]
        if codes & {"MULTIPLE_PRODUCTS", "MULTIPLE_DESTINATIONS"} and has_complete_item_delivery_dates(inquiry_text):
            # An unrepresentable list is not missing customer information.
            # Keep the manual split and automatic-action block below.
            fields = [field for field in fields if field != "preferred_delivery_date"]
        if "QUANTITY_CONFLICT" in codes:
            fields = [field for field in fields if field != "purchase_quantity"]
            fields.append("quantity_conflict")
        action = "MANUAL_SPLIT_REQUIRED"
        action_zh = "目前資料結構無法完整表示，先交人工核對並拆案"
        action_ja = "現在の項目では完全に表現できないため、担当者が確認して案件を分割する"
        action_steps = [{"code":"MANUAL_SPLIT_REQUIRED","label_zh":action_zh,"label_ja":action_ja}]
        _add_reason(escalation, "R11", "結構限制／資料衝突", "不能完整表示或條件互相矛盾，需人工拆案，不能當作抽取完整或自動完成。", "項目の制約・データの矛盾", "完全に表現できない、または条件が矛盾しているため、担当者が確認・分割します。")

    # Describe the final missing-field list after structural checks adjusted it.
    reasons = [reason for reason in reasons if reason['rule_id'] != 'R02']
    if fields:
        _add_reason(reasons, 'R02', '資訊尚未完整',
                    f'目前有 {len(fields)} 項必要資訊待補充；未知值維持空白，不由系統猜測。',
                    '情報不足', f'必要情報が{len(fields)}項不足しています。不明な値は空欄のままとし、システムで推測しません。')

    can_answer = [{
        "citation": hit["citation"],
        "label_zh": f"可依 {hit['citation']} 回答其明載的流程、必要資訊或公開範圍",
        "label_ja": f"{hit['citation']} に明記された手順・必要情報・公開範囲のみ回答可能",
    } for hit in retrieval.get("hits", [])]
    if auto_reject:
        human_mode = "BLOCKED"
        human_reason_zh = "只有越權指令或垃圾訊息，沒有有效業務需求，直接阻擋，不需人工審核。"
        human_reason_ja = "有効な業務要望のない不正指示・スパムのため、自動ブロックし、人の確認は不要です。"
    elif limitations:
        human_mode = "FULL_REVIEW"
        human_reason_zh = "目前資料結構無法完整表示或數據矛盾；需人工確認、拆案，不能自動建立扁平化紀錄。"
        human_reason_ja = "現在のデータ項目では表現できない、または値が矛盾しています。担当者による確認・分割前に自動処理しません。"
    elif blocked or has_support or retrieval_status != "FOUND":
        human_mode = "FULL_REVIEW"
        human_reason_zh = "涉及安全、售後或來源不足，需由人工全程處理。"
        human_reason_ja = "安全・アフターサービス・出典不足に関わるため、人が全体を確認します。"
    elif commitment_types or fields or result.intent != "FAQ":
        human_mode = "APPROVAL_REQUIRED"
        human_reason_zh = "AI 可整理及起草；商業承諾、資料缺漏或非 FAQ 案件在執行前仍需人工核准。"
        human_reason_ja = "AIは整理・下書きできますが、取引上の確約、情報不足、FAQ以外の案件は実行前に人の承認が必要です。"
    elif retrieval.get("answer_coverage", {}).get("status") != "VERIFIED":
        human_mode = "FULL_REVIEW"
        human_reason_zh = "還沒確認資料足以回答所問，先由人核對，不能自動回覆。"
        human_reason_ja = "質問を回答できる根拠が確認できていないため、人が確認します。"
    else:
        human_mode = "AUTO_ELIGIBLE"
        human_reason_zh = "此案是資料完整的低風險 FAQ，且有有效 KB 依據，可列入自動化候選；這不代表零風險，正式啟用仍需管理者設定抽查與停用條件。"
        human_reason_ja = "情報が揃った低リスクFAQで、有効なKB根拠があるため自動化候補です。無リスクではなく、本番では管理者が抜き取り確認と停止条件を設定します。"
    return {
        "rules_version": DECISION_RULES_VERSION,
        "representation_limitations": limitations,
        "structured_extraction_complete": not bool(limitations),
        "automatic_actions_blocked": bool(limitations),
        "priority": priority,
        "priority_reasons": reasons,
        "missing_information": [
            {"field": field, "question_zh": MISSING_QUESTIONS.get(field, (field, field))[0],
             "question_ja": MISSING_QUESTIONS.get(field, (field, field))[1]}
            for field in fields
        ],
        "escalation_reasons": escalation,
        "recommended_action": {"code": action, "label_zh": action_zh, "label_ja": action_ja,
                               "steps": action_steps},
        "reply_boundary": {"can_answer": can_answer, "needs_human_confirmation": needs_confirmation},
        "requires_human_review": human_mode not in {"AUTO_ELIGIBLE", "BLOCKED"},
        "human_in_loop": {
            "mode": human_mode,
            "label_zh": {"BLOCKED": "直接阻擋，不需人工", "FULL_REVIEW": "全程人工處理", "APPROVAL_REQUIRED": "核准前需要人工", "AUTO_ELIGIBLE": "可不逐筆人工核准"}[human_mode],
            "label_ja": {"BLOCKED": "自動ブロック・人の確認不要", "FULL_REVIEW": "全工程で人が対応", "APPROVAL_REQUIRED": "承認前に人が必要", "AUTO_ELIGIBLE": "個別承認なしの候補"}[human_mode],
            "reason_zh": human_reason_zh,
            "reason_ja": human_reason_ja,
        },
        "external_draft_blocked": blocked,
        "retrieval_status": retrieval_status,
        "reply_language": reply_language,
        "reply_language_reason": reply_language_reason,
        "reply_language_reason_ja": reply_language_reason_ja,
        "packaging_assumption": {
            "company_reference_bottles_per_case": 6,
            "customer_specified_bottles_per_case": pack_size,
            "equivalent_min_bottles": equivalent_min_bottles,
            "used_company_reference_for_priority": False,
        },
    }
