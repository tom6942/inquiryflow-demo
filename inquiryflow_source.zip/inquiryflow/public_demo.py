"""An isolated public demo using the same review/action backend as the local app.

Every browser session gets explicit private store paths. No global store, server
API key, real email, or external CRM is used by this entrypoint.
"""
from __future__ import annotations
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from .review import create_case, current_revision, get_case, list_cases, save_revision, approve, reject, ReviewError
from .actions import execute_approved_actions, action_snapshot, complete_task, close_case, update_case_tracking, load_action_store

SAMPLE_DIR=Path(__file__).resolve().parents[1]/'data/public_demo'

def load_samples(directory=SAMPLE_DIR):
    directory=Path(directory)
    manifest=json.loads((directory/'manifest.json').read_text())
    rows=[]
    for item in manifest['samples']:
        file=(directory/item['file']).resolve()
        if file.parent!=directory.resolve() or hashlib.sha256(file.read_bytes()).hexdigest()!=item['sha256']:
            raise ValueError('Sample manifest validation failed')
        row=json.loads(file.read_text())
        if row['analysis']['input']!=row['inquiry'] or row['draft']['input']['customer_inquiry']!=row['inquiry']:
            raise ValueError('Sample input mismatch')
        if row['draft']['source_analysis_run_id']!=row['analysis']['run_id']:
            raise ValueError('Sample draft mismatch')
        rows.append(row)
    return rows

class PublicWorkspace:
    def __init__(self, root):
        self.root=Path(root)
        self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.review_path=self.root/'review.json'
        self.action_path=self.root/'actions.json'

    def cases(self): return list_cases(self.review_path)
    def case(self, cid): return get_case(cid,self.review_path)
    def snapshot(self,cid): return action_snapshot(cid,self.action_path)

    def open_sample(self,sample):
        draft={**sample['draft']['output'],'status':'PENDING_HUMAN_REVIEW'}
        case=create_case('public-sample:'+sample['id'],sample['inquiry'],sample['analysis']['output'],
                         sample['analysis']['decision'],draft,actor='保存済みAPIサンプル',source_kind='api_draft',path=self.review_path)
        current=current_revision(case)
        edited=sample.get('edited')
        # Only seed a human-edited revision once, never overwrite a visitor edit.
        if edited and len(case['revisions'])==1 and not case['reviews']:
            if edited['summary_ja']!=current['summary_ja'] or edited['reply_text']!=current['reply_text']:
                case=save_revision(case['case_id'],current['revision_id'],edited['summary_ja'],edited['reply_language'],
                                   edited['reply_text'],'展示稿の編集',edited['reason'],path=self.review_path)
        return case

    def open_live(self,analysis,draft):
        if not analysis.get('output') or draft.get('status')!='PENDING_HUMAN_REVIEW':
            raise ReviewError('分析または返信案の作成が完了していません。')
        return create_case(analysis['workflow_id'],analysis['input'],analysis['output'],analysis['decision'],
                           {**draft['output'],'status':draft['status']},actor='API',source_kind='api_draft',path=self.review_path)

    def save_edit(self,cid,summary,reply,actor,reason):
        if not actor.strip(): raise ReviewError('氏名を入力してください。')
        rev=current_revision(self.case(cid))
        return save_revision(cid,rev['revision_id'],summary,rev['reply_language'],reply,actor,reason,path=self.review_path)

    def approve_and_create(self,cid,actor):
        if not actor.strip(): raise ReviewError('氏名を入力してください。')
        case=self.case(cid)
        if case.get('decision_snapshot',{}).get('automatic_actions_blocked'):
            raise ReviewError('このケースは担当者による分割が必要です。自動登録できません。')
        rev=current_revision(case)
        approve(cid,rev['revision_id'],actor,path=self.review_path)
        return execute_approved_actions(cid,actor,review_path=self.review_path,action_path=self.action_path)

    def reject(self,cid,actor,reason):
        if not actor.strip(): raise ReviewError('氏名を入力してください。')
        rev=current_revision(self.case(cid))
        return reject(cid,rev['revision_id'],actor,reason,path=self.review_path)

    def complete(self,tid,actor):
        return complete_task(tid,actor,review_path=self.review_path,action_path=self.action_path)

    def close(self,cid,actor):
        return close_case(cid,actor,review_path=self.review_path,action_path=self.action_path)

    def update_owner(self,cid,actor,owner):
        return update_case_tracking(cid,actor,owner=owner,reason='公開デモで担当者を変更',action_path=self.action_path)

    def export(self):
        return {'mode':'isolated-demo','cases':self.cases(),'actions':load_action_store(self.action_path),
                'notice':'Synthetic demo only. No email or external CRM action.'}
