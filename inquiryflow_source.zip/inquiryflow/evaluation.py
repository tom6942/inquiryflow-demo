"""Development-case scoring; never mixes fixture checks with live model metrics."""
FIELDS = ["intent", "language", "company_name", "country", "product", "purchase_quantity.min", "purchase_quantity.max", "purchase_quantity.unit", "budget.status", "budget.amount", "budget.currency", "timeline.date", "support.order_id", "support.issue_type", "support.affected_quantity.min", "support.affected_quantity.max", "support.affected_quantity.unit"]

def at(data, path):
    for key in path.split("."):
        data = data[key]
    return data

def score(actual, expected):
    comparisons = [{"field": f, "expected": at(expected, f), "actual": at(actual, f), "passed": at(actual, f) == at(expected, f)} for f in FIELDS]
    comparisons.append({"field": "request_types", "expected": sorted(expected["request_types"]), "actual": sorted(actual["request_types"]), "passed": set(actual["request_types"]) == set(expected["request_types"])})
    comparisons.append({"field": "risk_flags.code", "expected": sorted(f["code"] for f in expected["risk_flags"]), "actual": sorted(f["code"] for f in actual["risk_flags"]), "passed": {f["code"] for f in expected["risk_flags"]} == {f["code"] for f in actual["risk_flags"]}})
    for name, actual_values, expected_values in [
        ("languages.code", {x["code"] for x in actual["languages"]}, {x["code"] for x in expected["languages"]}),
        ("timeline.missing_parts", set(actual["timeline"]["missing_parts"]), set(expected["timeline"]["missing_parts"]))
    ]:
        comparisons.append({"field": name, "expected": sorted(expected_values), "actual": sorted(actual_values), "passed": actual_values == expected_values})
    return {"passed": all(c["passed"] for c in comparisons), "checks": comparisons,
            "note": "開發案例固定欄位比對；翻譯、原文語意、描述、引句支持程度仍需人工評分，不是完整品質驗收。"}


EVALUATION_VERSION = "evaluation-0.2"


def reply_boundary_code(decision):
    if decision.get("external_draft_blocked"):
        return "BLOCKED"
    boundary = decision.get("reply_boundary", {})
    if (decision.get("retrieval_status") != "FOUND" or decision.get("missing_information")
            or boundary.get("needs_human_confirmation") or decision.get("escalation_reasons")):
        return "NEEDS_HUMAN_CONFIRMATION"
    return "CAN_ANSWER_FROM_KB"


def _missing_groups(fields, group_support=False):
    aliases = {"purchase_quantity.case_pack_size": "case_pack_size"}
    return sorted({"support_evidence" if group_support and field.startswith("support.") else aliases.get(field, field) for field in fields})


def compare_expectation(actual, decision, expected):
    """Compare all supplied workflow expectations; missing old labels stay unscored."""
    actual_values = {
        "intent": actual["intent"],
        "languages": sorted(x["code"] for x in actual["languages"]),
        "request_types": sorted(actual["request_types"]),
        "priority": decision["priority"],
        "missing_information": _missing_groups((x["field"] for x in decision["missing_information"]),
                                               group_support="support_evidence" in expected.get("missing_information", [])),
        "reply_boundary": reply_boundary_code(decision),
        "human_in_loop": decision["human_in_loop"]["mode"],
    }
    checks = []
    for field, value in actual_values.items():
        if field not in expected:
            continue
        target = expected[field]
        if field in {"languages", "request_types"}:
            target = sorted(set(target))
        if field == "missing_information":
            target = _missing_groups(target)
        checks.append({"field": field, "expected": target, "actual": value, "passed": target == value})
    return {"version": EVALUATION_VERSION, "checks": checks,
            "passed": bool(checks) and all(c["passed"] for c in checks),
            "unscored": [field for field in actual_values if field not in expected],
            "note": "結構與業務條件比對；語意、來源支持及草稿品質另由人工評分。"}


def quality_verdict(ratings, *, critical_error=False, automatic_checks=None, blocked=False, expectation_confirmed=False):
    """Do not turn absent comparisons or unreviewed dimensions into a pass."""
    required = {"semantics", "source_support", "draft_quality"}
    if set(ratings) != required:
        raise ValueError("請完成三項品質評分。")
    allowed = {"NOT_REVIEWED", "PASS", "FAIL", "NOT_APPLICABLE"}
    if any(value not in allowed for value in ratings.values()):
        raise ValueError("品質評分值無效。")
    if critical_error or "FAIL" in ratings.values() or (automatic_checks and not automatic_checks["passed"]):
        return "FAIL"
    if (not expectation_confirmed or not automatic_checks or automatic_checks.get("unscored") or "NOT_REVIEWED" in ratings.values()
            or ratings["semantics"] != "PASS"):
        return "INCOMPLETE"
    if not blocked and "NOT_APPLICABLE" in ratings.values():
        return "INCOMPLETE"
    return "PASS"


def save_quality_review(context, reviewer, ratings, notes="", critical_error=False, directory=None):
    """Append a review tied to the exact displayed output, decision and draft."""
    import hashlib
    import json
    import uuid
    from datetime import datetime, timezone
    from pathlib import Path

    if not reviewer.strip():
        raise ValueError("請填寫評分者。")
    if (critical_error or "FAIL" in ratings.values()) and not notes.strip():
        raise ValueError("失敗或關鍵錯誤請填寫原因。")
    if not context.get("run_id"):
        raise ValueError("缺少分析紀錄編號。")
    verdict = quality_verdict(ratings, critical_error=critical_error,
                              automatic_checks=context.get("automatic_checks"), blocked=context.get("blocked", False),
                              expectation_confirmed=context.get("expectation_confirmed", False))
    payload = {"evaluation_version": EVALUATION_VERSION, "review_id": str(uuid.uuid4()),
               "reviewed_at": datetime.now(timezone.utc).isoformat(), "reviewer": reviewer.strip(),
               "ratings": ratings, "critical_error": bool(critical_error), "notes": notes.strip(),
               "verdict": verdict, "context": context,
               "content_hash": hashlib.sha256(json.dumps(context, ensure_ascii=False, sort_keys=True).encode()).hexdigest()}
    folder = Path(directory) if directory is not None else Path(__file__).resolve().parents[1] / "outputs" / "evaluations"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f'{payload["review_id"]}.json'
    with path.open("x", encoding="utf-8") as file:
        json.dump(payload, file, ensure_ascii=False, indent=2)
    return path, payload
