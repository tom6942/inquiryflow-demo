"""Local, auditable Day 6 review workflow.

The JSON store is a transparent PoC substitute for the PostgreSQL tables
designed on Day 2. Revisions, reviews and audit events are append-only.
No external action or message is executed here.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

REVIEW_WORKFLOW_VERSION = "review-workflow-0.3"
DEFAULT_STORE = Path(__file__).resolve().parents[1] / "outputs" / "review_store.json"


class ReviewError(ValueError):
    """A safe, user-displayable workflow error."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4()}"


def _assign_display_ids(store: dict) -> bool:
    """Backfill stable human-readable IDs in creation order."""
    changed = False
    used = {
        case.get("display_id") for case in store.get("cases", {}).values()
        if isinstance(case.get("display_id"), str) and case["display_id"].startswith("CASE-")
    }
    next_number = 1
    ordered = sorted(
        store.get("cases", {}).values(),
        key=lambda case: (case.get("created_at", ""), case.get("case_id", "")),
    )
    for case in ordered:
        if case.get("display_id") in used:
            continue
        while f"CASE-{next_number:03d}" in used:
            next_number += 1
        case["display_id"] = f"CASE-{next_number:03d}"
        used.add(case["display_id"])
        next_number += 1
        changed = True
    return changed


def _next_display_id(store: dict) -> str:
    used_numbers = []
    for case in store.get("cases", {}).values():
        value = case.get("display_id", "")
        if value.startswith("CASE-") and value[5:].isdigit():
            used_numbers.append(int(value[5:]))
    return f"CASE-{(max(used_numbers, default=0) + 1):03d}"


def _hash(summary_ja: str, reply_language: str, reply_text: str, action_plan: list) -> str:
    payload = json.dumps({
        "summary_ja": summary_ja.strip(), "reply_language": reply_language,
        "reply_text": reply_text.strip(), "action_plan": action_plan,
    }, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def load_store(path: Path | str = DEFAULT_STORE) -> dict:
    path = Path(path)
    if not path.exists():
        return {"store_version": REVIEW_WORKFLOW_VERSION, "cases": {}}
    data = json.loads(path.read_text())
    if not isinstance(data.get("cases"), dict):
        raise ReviewError("審核資料檔格式不正確。")
    _assign_display_ids(data)
    return data


def save_store(store: dict, path: Path | str = DEFAULT_STORE) -> None:
    path = Path(path)
    store["store_version"] = REVIEW_WORKFLOW_VERSION
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp_name = tempfile.mkstemp(prefix="review-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(store, file, ensure_ascii=False, indent=2)
        os.chmod(temp_name, 0o600)
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def _event(case: dict, event_type: str, actor: str, revision_id: str | None,
           from_state: str | None, to_state: str | None, details: dict | None = None) -> dict:
    event = {
        "event_id": _id("EVT"), "event_type": event_type, "actor": actor,
        "revision_id": revision_id, "from_state": from_state, "to_state": to_state,
        "created_at": _now(), "details": details or {},
    }
    case["audit_events"].append(event)
    return event


def _current(case: dict) -> dict:
    revision = next((item for item in case["revisions"] if item["revision_id"] == case["current_revision_id"]), None)
    if not revision:
        raise ReviewError("找不到目前草稿版本。")
    return revision


def create_case(source_run_id: str, inquiry: str, extraction: dict, decision: dict,
                draft: dict, actor: str = "demo-operator", source_kind: str = "rule_preview",
                path: Path | str = DEFAULT_STORE) -> dict:
    if decision.get("external_draft_blocked") or draft.get("status") == "BLOCKED" or not draft.get("customer_reply"):
        raise ReviewError("這筆詢問的對外草稿已被阻擋，不能建立待審版本。")
    store = load_store(path)
    existing = next((case for case in store["cases"].values() if case["source_run_id"] == source_run_id), None)
    if existing:
        current = _current(existing)
        action_plan = deepcopy(decision.get("recommended_action", {}).get("steps", []))
        incoming_hash = _hash(
            draft["internal_summary_ja"], draft["reply_language"],
            draft["customer_reply"], action_plan,
        )
        # If nobody has reviewed or edited the free preview, the paid API draft
        # is the actual initial draft. Replace that placeholder in place so a
        # brand-new inquiry still starts at Revision 1.
        can_promote_api_draft = (
            source_kind == "api_draft"
            and current.get("source_kind") == "rule_preview"
        )
        pristine_preview = (
            can_promote_api_draft and len(existing["revisions"]) == 1
            and not existing.get("reviews") and existing.get("status") == "NEEDS_REVIEW"
            and len(existing.get("audit_events", [])) == 1
        )
        if pristine_preview and incoming_hash != current["content_hash"]:
            created = _now()
            current.update(
                summary_ja=draft["internal_summary_ja"].strip(),
                reply_language=draft["reply_language"], reply_text=draft["customer_reply"].strip(),
                action_plan=action_plan, evidence_refs=list(draft.get("source_citations", [])),
                edited_by=actor, created_at=created, source_kind=source_kind,
                change_reason="API initial draft", content_hash=incoming_hash,
            )
            existing["updated_at"] = created
            existing["audit_events"][0]["details"]["source_kind"] = source_kind
            existing["audit_events"][0]["details"]["draft_replaced_placeholder"] = True
            save_store(store, path)
        elif can_promote_api_draft and incoming_hash != current["content_hash"]:
            created = _now()
            before = existing["status"]
            revision = {
                "revision_id": _id("REV"),
                "revision_no": current["revision_no"] + 1,
                "summary_ja": draft["internal_summary_ja"].strip(),
                "reply_language": draft["reply_language"],
                "reply_text": draft["customer_reply"].strip(),
                "action_plan": action_plan,
                "evidence_refs": list(draft.get("source_citations", [])),
                "edited_by": actor,
                "created_at": created,
                "source_kind": source_kind,
                "change_reason": "API-generated draft replaced rule preview",
                "content_hash": incoming_hash,
            }
            if existing.get("approved_review_id"):
                _event(
                    existing, "APPROVAL_INVALIDATED", actor, current["revision_id"],
                    before, "NEEDS_REVIEW",
                    {"review_id": existing["approved_review_id"], "reason": "api_draft_generated"},
                )
            existing["approved_review_id"] = None
            existing["current_revision_id"] = revision["revision_id"]
            existing["status"] = "NEEDS_REVIEW"
            existing["updated_at"] = created
            existing["revisions"].append(revision)
            _event(
                existing, "REVISION_SAVED", actor, revision["revision_id"],
                before, "NEEDS_REVIEW",
                {
                    "revision_no": revision["revision_no"],
                    "previous_revision_id": current["revision_id"],
                    "change_reason": revision["change_reason"],
                    "source_kind": source_kind,
                },
            )
            save_store(store, path)
        return deepcopy(existing)
    case_id, revision_id, created = _id("CASE"), _id("REV"), _now()
    action_plan = deepcopy(decision.get("recommended_action", {}).get("steps", []))
    revision = {
        "revision_id": revision_id, "revision_no": 1, "summary_ja": draft["internal_summary_ja"].strip(),
        "reply_language": draft["reply_language"], "reply_text": draft["customer_reply"].strip(),
        "action_plan": action_plan, "evidence_refs": list(draft.get("source_citations", [])),
        "edited_by": actor, "created_at": created, "source_kind": source_kind,
        "change_reason": "Initial draft",
        "content_hash": _hash(draft["internal_summary_ja"], draft["reply_language"], draft["customer_reply"], action_plan),
    }
    case = {
        "case_id": case_id, "display_id": _next_display_id(store),
        "source_run_id": source_run_id, "inquiry": inquiry,
        "extraction": deepcopy(extraction), "decision_snapshot": deepcopy(decision),
        "status": "NEEDS_REVIEW", "current_revision_id": revision_id,
        "approved_review_id": None, "created_at": created, "updated_at": created,
        "revisions": [revision], "reviews": [], "audit_events": [],
    }
    _event(case, "CASE_CREATED", actor, revision_id, None, "NEEDS_REVIEW",
           {"revision_no": 1, "source_kind": source_kind})
    store["cases"][case_id] = case
    save_store(store, path)
    return deepcopy(case)


def get_case(case_id: str, path: Path | str = DEFAULT_STORE) -> dict:
    case = load_store(path)["cases"].get(case_id)
    if not case:
        raise ReviewError("找不到這筆案件。")
    return deepcopy(case)


def list_cases(path: Path | str = DEFAULT_STORE) -> list[dict]:
    cases = load_store(path)["cases"].values()
    return sorted((deepcopy(case) for case in cases), key=lambda x: x["updated_at"], reverse=True)


def save_revision(case_id: str, expected_revision_id: str, summary_ja: str,
                  reply_language: str, reply_text: str, actor: str, change_reason: str,
                  path: Path | str = DEFAULT_STORE) -> dict:
    if not summary_ja.strip() or not reply_text.strip():
        raise ReviewError("日文摘要與客戶回覆不可空白。")
    if not change_reason.strip():
        raise ReviewError("儲存新版本時必須填寫修改理由。")
    if reply_language not in {"zh-TW", "en", "ja"}:
        raise ReviewError("回覆語言不在允許清單。")
    store = load_store(path); case = store["cases"].get(case_id)
    if not case:
        raise ReviewError("找不到這筆案件。")
    current = _current(case)
    if current["revision_id"] != expected_revision_id:
        raise ReviewError("草稿已更新，請重新查看目前版本。")
    new_hash = _hash(summary_ja, reply_language, reply_text, current["action_plan"])
    if new_hash == current["content_hash"]:
        raise ReviewError("內容沒有變更，不需要建立新版本。")
    before = case["status"]
    revision = {
        **{k: deepcopy(current[k]) for k in ("action_plan", "evidence_refs", "source_kind")},
        "revision_id": _id("REV"), "revision_no": current["revision_no"] + 1,
        "summary_ja": summary_ja.strip(), "reply_language": reply_language,
        "reply_text": reply_text.strip(), "edited_by": actor, "created_at": _now(),
        "change_reason": change_reason.strip(),
        "content_hash": new_hash,
    }
    if case.get("approved_review_id"):
        _event(case, "APPROVAL_INVALIDATED", actor, current["revision_id"], before, "NEEDS_REVIEW",
               {"review_id": case["approved_review_id"], "reason": "content_changed"})
    case["approved_review_id"] = None
    case["current_revision_id"] = revision["revision_id"]
    case["status"] = "NEEDS_REVIEW"
    case["updated_at"] = revision["created_at"]
    case["revisions"].append(revision)
    _event(case, "REVISION_SAVED", actor, revision["revision_id"], before, "NEEDS_REVIEW",
           {"revision_no": revision["revision_no"], "previous_revision_id": current["revision_id"],
            "change_reason": change_reason.strip()})
    save_store(store, path)
    return deepcopy(case)


def approve(case_id: str, expected_revision_id: str, reviewer: str,
            path: Path | str = DEFAULT_STORE) -> dict:
    store = load_store(path); case = store["cases"].get(case_id)
    if not case:
        raise ReviewError("找不到這筆案件。")
    current = _current(case)
    if current["revision_id"] != expected_revision_id:
        raise ReviewError("這不是目前版本，不能核准。")
    existing = next((r for r in case["reviews"] if r["decision"] == "approve" and r["revision_id"] == expected_revision_id), None)
    if existing:
        return deepcopy(case)
    if case["status"] not in {"NEEDS_REVIEW"}:
        raise ReviewError("這筆案件目前不能核准；請先儲存修改後的新版本。")
    review = {
        "review_id": _id("REVIEW"), "revision_id": expected_revision_id,
        "decision": "approve", "reviewer_id": reviewer, "reason": None,
        "reviewed_at": _now(), "resolved_action_plan": deepcopy(current["action_plan"]),
    }
    before = case["status"]
    case["reviews"].append(review); case["approved_review_id"] = review["review_id"]
    case["status"] = "APPROVED"; case["updated_at"] = review["reviewed_at"]
    _event(case, "REVISION_APPROVED", reviewer, expected_revision_id, before, "APPROVED",
           {"review_id": review["review_id"], "send": False, "external_actions": []})
    save_store(store, path)
    return deepcopy(case)


def reject(case_id: str, expected_revision_id: str, reviewer: str, reason: str,
           path: Path | str = DEFAULT_STORE) -> dict:
    if not reason.strip():
        raise ReviewError("拒絕時必須填寫理由。")
    store = load_store(path); case = store["cases"].get(case_id)
    if not case:
        raise ReviewError("找不到這筆案件。")
    current = _current(case)
    if current["revision_id"] != expected_revision_id:
        raise ReviewError("這不是目前版本，不能退回。")
    existing = next((r for r in case["reviews"] if r["decision"] == "reject" and r["revision_id"] == expected_revision_id), None)
    if existing:
        return deepcopy(case)
    if case["status"] != "NEEDS_REVIEW":
        raise ReviewError("只能退回目前待審核的版本。")
    review = {
        "review_id": _id("REVIEW"), "revision_id": expected_revision_id,
        "decision": "reject", "reviewer_id": reviewer, "reason": reason.strip(),
        "reviewed_at": _now(), "resolved_action_plan": None,
    }
    case["reviews"].append(review); case["approved_review_id"] = None
    case["status"] = "NEEDS_CHANGES"; case["updated_at"] = review["reviewed_at"]
    _event(case, "REVISION_REJECTED", reviewer, expected_revision_id, "NEEDS_REVIEW", "NEEDS_CHANGES",
           {"review_id": review["review_id"], "reason": reason.strip()})
    save_store(store, path)
    return deepcopy(case)


def current_revision(case: dict) -> dict:
    return deepcopy(_current(case))


def has_unsaved_changes(revision: dict, summary_ja: str, reply_language: str, reply_text: str) -> bool:
    return revision["content_hash"] != _hash(summary_ja, reply_language, reply_text, revision["action_plan"])
