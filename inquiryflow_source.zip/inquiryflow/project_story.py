"""Static, Japanese project narrative for the public interview demo.

No operational data or API access: historical evidence remains in the source
documents, and this page explains the scope and the author's decisions.
"""

STORY_CSS = """<style>
.if-story {color:var(--if-ink,#243c33);font-size:.94rem;line-height:1.8;}
.if-story .story-intro {max-width:42em;margin:0 0 2rem;}
.if-story .story-kicker {color:var(--if-accent,#216447);font-size:.75rem;letter-spacing:.1em;margin:0 0 .3rem;}
.if-story h2 {font-size:1.22rem!important;font-weight:550!important;margin:0 0 .65rem;padding:0!important;}
.if-story h3 {font-size:1rem!important;font-weight:550!important;margin:0 0 .4rem;}
.if-story p {margin:.25rem 0 .8rem;}
.if-story section {padding:1.5rem 0;border-top:1px solid var(--if-line,#dce4dc);}
.if-story .story-grid {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.2rem;}
.if-story .story-panel {background:var(--if-paper,#fff);border:1px solid var(--if-line,#dce4dc);border-radius:10px;padding:1rem 1.15rem;}
.if-story .story-panel.after {background:var(--if-soft,#ecf3ec);border-top:3px solid var(--if-accent,#216447);}
.if-story .story-label {display:block;color:var(--if-accent,#216447);font-size:.8rem;margin-bottom:.5rem;}
.if-story .story-flow {padding:0;margin:.3rem 0;list-style:none;}
.if-story .story-flow li {padding:.25rem 0;font-weight:400;}
.if-story .story-insight {border-left:3px solid var(--if-gold,#9c7843);padding:.2rem 0 .2rem 1rem;margin:1rem 0;}
.if-story .story-roles {display:grid;grid-template-columns:4.5em 1fr;gap:.55rem 1rem;margin:.5rem 0;}
.if-story .story-roles dt {color:var(--if-accent,#216447);font-weight:500;}
.if-story .story-roles dd {margin:0;}
.if-story details {border-bottom:1px solid var(--if-line,#dce4dc);padding:.65rem 0;margin:.65rem 0 0;}
.if-story summary {cursor:pointer;color:var(--if-accent,#216447);font-size:.87rem;}
.if-story details p,.if-story details li {font-size:.85rem;}
.if-story summary:hover {text-decoration:underline;text-underline-offset:4px;}
.if-story summary:focus-visible {outline:2px solid var(--if-gold,#9c7843);outline-offset:4px;}
.if-story .story-stages {list-style:none;padding:0;margin:.5rem 0;counter-reset:stage;}
.if-story .story-stages li {padding:.65rem 0;border-bottom:1px solid var(--if-line,#dce4dc);}
.if-story .story-stages span {display:inline-block;min-width:5.2em;color:var(--if-accent,#216447);font-size:.83rem;}
@media(max-width:620px) {.if-story .story-grid{grid-template-columns:1fr;gap:.7rem;}.if-story .story-roles{grid-template-columns:3.5em 1fr;}}
</style>"""

STORY_HTML = """<article class="if-story">
<header class="story-intro">
<p class="story-kicker">制作の背景</p>
<h2>海外営業の問い合わせと、その後の対応</h2>
<p>日本酒を扱う貿易会社の海外営業を想定しました。外国語の問い合わせを読み、社内資料を確認して返信し、CRMへの転記とフォロー設定まで行う。その繰り返しを、どこまで支援できるかを試した作品です。</p>
</header>
<section aria-label="業務の変化">
<h2>目指したのは、確認に集中できる流れ</h2>
<div class="story-grid">
<div class="story-panel"><span class="story-label">これまでの想定業務</span>
<ol class="story-flow"><li>受信メールを読み、必要に応じて翻訳する</li><li>数量・予算・期限を拾い、社内資料を探す</li><li>返信を書き、顧客情報をCRMへ転記する</li><li>次に連絡する日を設定する</li></ol></div>
<div class="story-panel after"><span class="story-label">この試作での流れ</span>
<ol class="story-flow"><li>AIが要点と返信案を準備する</li><li>担当者が原文・参照資料と照合する</li><li>返信内容を確認・承認する</li><li>プログラムが模擬CRMとタスクを作る</li></ol></div>
</div>
<p>転記や起草の負担を減らすことが狙いです。実際に何分短縮できるかは、まだ検証できていません。</p>
<details><summary>なぜこの業務を選んだか</summary><p>外国語の理解、情報整理、会社の決まりの参照、返信、その後のフォローを、一つの流れとして検討できるためです。実際の企業への聞き取りは未実施であり、この業種や規模の会社に最も必要だと確認したものではありません。</p></details>
</section>
<section aria-label="役割分担">
<h2>AIに任せること、任せないこと</h2>
<dl class="story-roles"><dt>AI</dt><dd>受信メールを読み取り、要点と参照資料に基づく返信案を作る。</dd>
<dt>処理ルール</dt><dd>必須項目・引用元・承認対象の版を確認し、条件を満たさない登録を止める。</dd>
<dt>担当者</dt><dd>原文との違いや文章を確認する。価格・供給・出荷条件は別途社内で確認する。</dd></dl>
<details><summary>会社の資料と承認の扱い</summary><p>KBは参照する会社資料、業務ルールは優先度や確認事項を決める基準として分けました。参照可能な版を絞り、返信に付く引用元も確認します。資料が見つかることと、質問に答えられることは別です。</p><p>承認するのは初回返信の内容とその版です。価格や出荷の確定を意味しません。このデモはメールを送信せず、外部CRMにも接続しません。</p></details>
</section>
<section aria-label="自分が気づいたこと">
<p class="story-kicker">自分の判断から変えたこと</p>
<h2>「数量が合っている」だけでは足りなかった</h2>
<p>「2本が破損した。追加で100本買いたい」という受信メールを見直すと、主分類はサポートなのに、数量欄には100と表示されていました。</p>
<div class="story-grid"><div class="story-panel"><span class="story-label">変更前</span><p>サポート ／ 数量100本</p><p>何の数量か、画面だけでは判断しにくい。</p></div>
<div class="story-panel after"><span class="story-label">変更後</span><p>破損2本 ／ 新規購入100本</p><p>二つの要望を分けて残し、破損への対応を優先する。</p></div></div>
<p>参照回答と項目設計の改善例です。モデル精度の改善率は未計測です。</p>
<p class="story-insight">私はこの混同を指摘し、数量を用途別に分けるよう求めました。学んだのは、分類が正しくても、次の人が誤解する表示では業務に使えないということです。</p>
<details><summary>根拠と、まだ残る制約</summary><p>Day 3のDEV-06で、既存注文の破損数と追加購入数を分ける要件を提案しました。プログラムとテストの実装はAIの支援を受けました。変更当時の記録はDay 3の改善記録に保存しています。</p><p>その後の06Aでは、二つの商品・配送先・日付を一組の項目に保存できず、既にある日付を再度尋ねる問題も見つかりました。「顧客が書いていない」と「システムが保存できない」を区別し、不要な質問を避け、自動登録を止める方針にしました。複数明細の完全な登録・案件分割は未実装です。</p></details>
</section>
<section aria-label="制作の過程">
<h2>作って終わりにせず、使い方から見直した</h2>
<ol class="story-stages"><li><span>Day 1–2</span>対象業務と、受信メールからフォローまでの流れを整理。</li>
<li><span>Day 3–5</span>抽出項目、会社資料の検索、判断ルールと返信案を接続。</li>
<li><span>Day 6–7</span>版ごとの承認と、模擬CRM・フォローへの引き継ぎを実装。</li>
<li><span>Day 8–9</span>原文と結果を比べ、誤抽出・検索漏れ・不自然な返信を記録。人の作業手順とも比較。</li></ol>
<details><summary>改善をどう確かめたか</summary><p>元の出力を残し、修正前後を分けて確認しました。例えば01Aでは、存在する見積手順が検索できなかったため検索順位を調整し、同じ原文でAPIを再実行。参照資料が取得できたことを確認しました。これだけで実際の価格や在庫まで分かったとは扱いません。</p><p>改善に使用した問題を、未見のテストとして再集計することはしません。詳しい結果と残る問題は「検証と改善」にまとめています。</p></details>
</section>
<section aria-label="現状と分担">
<h2>今できることと、これから確かめること</h2>
<div class="story-grid"><div class="story-panel after"><h3>このデモで確認できること</h3><p>保存済みの受信メール・要点・返信案を確認し、返信内容の承認後に模擬CRMとフォロータスクへ進む流れ。複雑な条件を一件として登録しない制御。</p></div>
<div class="story-panel"><h3>まだ確認できていないこと</h3><p>実際の価格・在庫・注文・船期との連携。複数明細の完全な登録。企業での導入効果や、同じ条件で測った人の作業時間の短縮。</p></div></div>
<details><summary>私が担当したこととAIの支援</summary><p>私は業務の流れと完成条件を見直し、人ならどう処理するかを考え、誤った質問や不自然な表現を指摘しました。どこまで自動化し、何を確認者に残すかも検討しました。</p><p>AIには設計案、コード、文書の作成、テストと原因調査、公開作業の支援を受けました。すべてのコードを自分で書いた作品ではありません。記録を基に人がルール等を修正する仕組みであり、自動学習する機能はありません。</p></details>
</section></article>"""


def render_project_story(st):
    """Render the static story with the host page's light/dark theme tokens."""
    st.markdown(STORY_CSS + STORY_HTML, unsafe_allow_html=True)
