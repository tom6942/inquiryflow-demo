"""Conservative scope checks; route limitations, never invent structured values."""
import re
from datetime import date


def has_complete_item_delivery_dates(message):
    """Recognise explicit dates on every numbered SKU allocation, conservatively.

    This does not invent a single date or create structured line items. Other
    layouts still require manual review; historical dates do not fill gaps.
    """
    active = re.sub(r"---\s*QUOTED EMAIL[^\n]*---.*?---\s*END QUOTE\s*---", "", message or "", flags=re.I | re.S)
    items = [line for line in active.splitlines()
             if re.match(r"\s*\d+[.)、]\s*", line)
             and re.search(r"\bSKU[-_ ]?[A-Z0-9]+\b", line, re.I)]
    if len(items) < 2:
        return False
    for line in items:
        if not re.search(r"到貨|到着|納品|arrival|arriv|delivery", line, re.I):
            return False
        dates = re.findall(r"(20\d{2})(?:年|[-/])(\d{1,2})(?:月|[-/])(\d{1,2})(?:日)?", line)
        if len(dates) != 1:
            return False
        try:
            date(*map(int, dates[0]))
        except ValueError:
            return False
        if re.search(r"未定|不明|尚未|或|または|\b(?:undecided|unknown|not yet|or)\b", line, re.I):
            return False
    return True

def representation_limits(message):
    text=message or ""
    limits=[]
    def add(code,zh,ja):
        limits.append({"code":code,"detail_zh":zh,"detail_ja":ja})
    skus=set(re.findall(r"\bSKU[-_ ]?[A-Z0-9]+\b",text,re.I))
    if len(skus)>1:
        add("MULTIPLE_PRODUCTS","多個商品明細無法用目前單商品欄位完整表示，需人工拆案。","複数の商品明細は現在の単一商品項目では表現できないため、担当者による分割が必要です。")
    # Count delivery destinations, not company origin or a language name.
    destinations=set()
    for code,pattern in {
        'TW':r'台灣|台湾|Taiwan|\bTW\b', 'HK':r'香港|Hong[ -]?Kong|\bHK\b',
        'SG':r'新加坡|シンガポール|Singapore|\bSG\b',
        'US':r'美國|美国|米国|United States|USA',
        'AU':r'澳洲|澳大利亞|オーストラリア|Australia',
        'GB':r'英國|英国|United Kingdom|\bUK\b',
        'CA':r'加拿大|カナダ|Canada',
    }.items():
        destination=re.search(r'(?:\bto\s+|配送|分送|送往|運往|発送先[：:]?\s*)(?:[^;。\n]{0,16}?)(?:'+pattern+r')',text,re.I)
        destination=destination or re.search(r'(?:'+pattern+r')(?:へ|向け|配送|への納品)',text,re.I)
        # Destination-first allocations: "Taiwan 80 bottles; Singapore 60 bottles; ship separately".
        allocation = re.search(r'(?:'+pattern+r')\s*[：:]?\s*\d+\s*(?:瓶|本|箱|ケース|bottles?|cases?)',text,re.I)
        split_delivery = re.search(r'分送|分別.*(?:配送|送|運)|分开.*(?:送|运)|ship\s+separately|separate\s+deliver|別々.*(?:配送|発送)|分納',text,re.I)
        if destination or (allocation and split_delivery):destinations.add(code)
    if len(destinations)>1:
        add("MULTIPLE_DESTINATIONS","不同送貨地要分開處理，不能合成一筆案件。","配送先ごとに分けて扱い、単一案件へまとめません。")
    quantities=re.findall(r'\d+\s*(?:瓶|本|箱|ケース|bottles?|cases?)',text,re.I)
    condition=bool(re.search(r'條件式|条件付き|試飲に合格した場合|試飲[^。\n]{0,30}(?:合格|通過|滿意|满意|問題なければ|問題がなければ|良ければ)|\b(?:only if|conditional|if.{0,45}(?:approved|passes?|successful))\b',text,re.I))
    future=bool(re.search(r'追加|明年|以後|之後|後續|later|future|next year|further|another',text,re.I))
    if condition and future and len(quantities)>1:
        add("CONDITIONAL_ORDER_SCOPE","這次想買的數量和以後才可能追加的數量，要分開處理。","現在の購入希望と条件付きの追加購入を分けて扱います。")
    remedy_deadline=bool(re.search(r'(?:明天|後天|明日|翌日|tomorrow|next day|20\d{2}[-/年]\d{1,2})[^。\n]{0,35}(?:補寄|再送|replace|reship)|(?:補寄|再送|replacement|reship)[^。\n]{0,35}(?:明天|後天|明日|翌日|tomorrow|next day|20\d{2}[-/年]\d{1,2})',text,re.I))
    new_purchase=bool(re.search(r'另.{0,12}(?:買|購|購入)|別途.{0,20}購入|new.{0,20}(?:purchase|order)|(?:buy|purchase)\s+another\s+\d+|追加|サンプル|樣品|samples?',text,re.I))
    if (remedy_deadline and new_purchase) or (condition and future and len(re.findall(r'20\d{2}年|20\d{2}-\d{2}|\b20\d{2}\b',text))>1):
        add("MULTIPLE_TIME_SCOPES","補寄、這次採購或以後追加的日期不同，不能共用一個交貨日。","再送・今回の購入・追加購入の日程を一つの納期へまとめません。")
    cases=re.search(r"(\d+)\s*(?:箱|ケース|cases?)",text,re.I)
    pack=re.search(r"(?:每箱|1ケース当たり|per case)\s*(\d+)\s*(?:瓶|本|bottles?)",text,re.I)
    if not pack:
        pack=re.search(r"(\d+)\s*bottles?\s+per\s+case",text,re.I)
    total=re.search(r"(?:總計|合計|total(?:\s+of)?)\s*(\d+)\s*(?:瓶|本|bottles?)",text,re.I)
    if cases and pack and total and int(cases[1])*int(pack[1])!=int(total[1]):
        add("QUANTITY_CONFLICT","箱數乘入數與聲稱總瓶數矛盾，需確認正確數量。","ケース数×入数と合計本数が一致しないため、正しい数量の確認が必要です。")
    currencies=set(re.findall(r"\b(?:USD|JPY|TWD|HKD|EUR)\b",text,re.I))
    if len(currencies)>1 and re.search(r"單價|1本|per[- ]bottle|unit price",text,re.I) and re.search(r"總預算|総予算|total.*budget|overall.*budget|(?:initial|goods|商品|初回).*budget",text,re.I):
        add("MULTIPLE_MONEY_BASES","總額、單價與多幣別無法完整存入單一預算，需人工拆分金額用途。","総額・単価・複数通貨は単一予算項目で表せないため、用途別の整理が必要です。")
    return limits
