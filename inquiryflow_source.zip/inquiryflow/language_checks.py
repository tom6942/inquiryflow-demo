"""Conservative script checks, not a language detector or a translation service."""
import re
import unicodedata


def latin_words(text):
    # Codes, addresses and currency labels do not establish a natural language.
    text = re.sub(r'https?://\S+|www\.\S+|[\w.+-]+@[\w.-]+', ' ', text)
    text = re.sub(r'(?<!\w)[A-Za-z0-9_-]*\d[A-Za-z0-9_-]*(?!\w)', ' ', text)
    words = re.findall(r'[^\W\d_]+', text, re.UNICODE)
    return [w for w in words if len(w) >= 2
            and all('LATIN' in unicodedata.name(c, '') for c in w)
            and w.upper() not in {'USD', 'JPY', 'TWD', 'EUR', 'GBP', 'SKU'}]


def language_warnings(result, message):
    """Flag likely omissions; Latin script alone does not prove English."""
    codes = {x.code.lower() for x in result.languages}
    warnings = []
    non_latin = {'zh', 'zh-tw', 'zh-cn', 'ja', 'ko', 'ru', 'ar', 'und', 'other'}
    words = latin_words(message)
    if words and codes <= non_latin:
        warnings.append({
            'code': 'UNREPRESENTED_LATIN_TEXT',
            'message': '原文含拉丁字母詞語，但語言清單未列出對應語言；可能漏列英文或其他語言，也可能是專名，請人工核對。',
            'evidence': list(dict.fromkeys(words))[:8],
        })
    if re.search(r'[\u3041-\u3096\u30a1-\u30fa]', message) and 'ja' not in codes:
        warnings.append({'code': 'UNREPRESENTED_KANA', 'message': '原文含日文假名，但語言清單未列日文；請核對是否漏列。', 'evidence': re.findall(r'[\u3041-\u3096\u30a1-\u30fa]+', message)[:8]})
    # A representative Chinese/Japanese quote must isolate its own language.
    for item in result.languages:
        if item.code.lower() in {'zh', 'zh-tw', 'zh-cn', 'ja', 'ko'} and latin_words(item.quote):
            warnings.append({'code': 'MIXED_LANGUAGE_QUOTE', 'message': '語言引句混入拉丁字母詞語；請核對是否把同一句中的不同語言合併計算。', 'evidence': [item.quote]})
            break
        if item.code.lower() not in {'zh', 'zh-tw', 'zh-cn', 'ja', 'ko', 'und', 'other'} and re.search(r'[\u3400-\u9fff\u3041-\u30fa]', item.quote):
            warnings.append({'code': 'MIXED_LANGUAGE_QUOTE', 'message': '拉丁語系的語言引句混入中文／日文文字；請核對是否把不同語言誤列為同一項。', 'evidence': [item.quote]})
            break
    return warnings
