import json
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from openai import OpenAI, AuthenticationError, PermissionDeniedError, RateLimitError, APITimeoutError, APIConnectionError, APIStatusError
from pydantic import ValidationError
from .language_checks import language_warnings
from .retrieval import retrieve
from .decision import decide
from .drafting import DraftPackage, preview_draft
from .schema import Extraction, SCHEMA_VERSION, RULES_VERSION, validate_input, validate_evidence, missing_fields, review_reasons, normalize_extraction, repair_language_quote_whitespace

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL = "gpt-6.1-sol"
PROMPT_VERSION = "extract-v0.15"
PROMPT = (ROOT / "prompts" / "extract-v0.5.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.6.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.7.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.8.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.9.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.10.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.11.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.12.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.13.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.14.txt").read_text() + "\n" + (ROOT / "prompts" / "extract-v0.15.txt").read_text()
MAX_OUTPUT_TOKENS = 2400
DRAFT_PROMPT_VERSION = "draft-v0.13"
DRAFT_PROMPT = (ROOT / "prompts" / "draft-v0.13.txt").read_text()
DRAFT_MAX_OUTPUT_TOKENS = 1800


def client_for(key: str):
    # Explicit destination; never inherit a custom OPENAI_BASE_URL for a pasted key.
    return OpenAI(api_key=key, base_url="https://api.openai.com/v1", timeout=45.0, max_retries=0)


def safe_error(exc):
    if isinstance(exc, AuthenticationError):
        return "AUTH", "金鑰無效或已撤銷，請重新建立並貼入。"
    if isinstance(exc, PermissionDeniedError):
        return "PERMISSION", "此金鑰沒有所需權限，請確認專案及模型權限。"
    if isinstance(exc, RateLimitError):
        return "QUOTA_OR_RATE", "額度不足或請求受限，請確認 API 帳務與用量後再試。"
    if isinstance(exc, APITimeoutError):
        return "TIMEOUT", "等待超過 45 秒，未取得完整結果；可手動重試，先前請求仍可能產生費用。"
    if isinstance(exc, APIConnectionError):
        return "CONNECTION", "無法連線至 OpenAI，請確認網路後再試。"
    if isinstance(exc, APIStatusError):
        return "API_ERROR", "API 未接受請求，請確認模型可用性與設定。"
    return "UNEXPECTED", "分析未完成，請重新整理或查看本機測試結果。"


def check_connection(key, model, client=None):
    if not key.strip():
        return {"ok": False, "message": "請先貼入 API 金鑰。"}
    own = client is None
    client = client or client_for(key.strip())
    try:
        client.models.retrieve(model)
        return {"ok": True, "message": "金鑰與模型查詢成功；尚未執行生成，實際分析仍需可用額度。"}
    except Exception as exc:
        return {"ok": False, "message": safe_error(exc)[1]}
    finally:
        if own:
            client.close()


def redact(value, secret=""):
    if isinstance(value, dict):
        return {k: redact(v, secret) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v, secret) for v in value]
    if isinstance(value, str):
        if secret:
            value = value.replace(secret, "[REDACTED]")
        return re.sub(r"sk-[A-Za-z0-9_-]{8,}", "[REDACTED]", value)
    return value


def analyze(message, key, model=DEFAULT_MODEL, client=None, workflow_id=None):
    validate_input(message)
    if not key.strip():
        raise ValueError("請先設定 API 金鑰。")
    started = time.monotonic()
    record = {
        "run_id": str(uuid.uuid4()), "workflow_id": workflow_id or str(uuid.uuid4()),
        "started_at": datetime.now(timezone.utc).isoformat(),
        "mode": "live_api", "input": message, "requested_model": model,
        "versions": {"app": "day5-0.1", "schema": SCHEMA_VERSION, "rules": RULES_VERSION, "prompt": PROMPT_VERSION},
        "parameters": {"max_output_tokens": MAX_OUTPUT_TOKENS, "max_retries": 0, "store": False},
        "prompt": PROMPT, "status": "FAILED", "output": None, "missing_fields": [],
        "usage": None, "cost": None, "cost_currency": "USD", "raw_output": None,
        "error_code": None, "message": None, "request_id": None, "retrieval": None,
        "decision": None, "draft_preview": None,
    }
    own = client is None
    client = client or client_for(key.strip())
    try:
        response = client.responses.create(
            model=model, store=False, max_output_tokens=MAX_OUTPUT_TOKENS,
            instructions=PROMPT, input=[{"role": "user", "content": message}],
            text={"format": {"type": "json_schema", "name": "inquiry_extraction", "strict": True, "schema": Extraction.model_json_schema()}},
        )
        record["request_id"] = getattr(response, "_request_id", None)
        record["response_id"] = response.id
        record["returned_model"] = response.model
        record["usage"] = response.usage.model_dump() if response.usage else None
        record["raw_output"] = response.output_text
        record["response_status"] = response.status
        refusal = any(getattr(c, "type", None) == "refusal" for item in response.output for c in getattr(item, "content", []))
        if refusal:
            record.update(error_code="REFUSAL", message="模型未提供分析，請由人工處理。")
        elif response.status != "completed":
            record.update(error_code="INCOMPLETE", message="回傳不完整，未當作成功結果；請手動重試或交人工處理。")
        else:
            result = Extraction.model_validate_json(response.output_text)
            record["model_output"] = result.model_dump()
            result, quote_changes = repair_language_quote_whitespace(result, message)
            validate_evidence(result, message)
            result, rule_changes = normalize_extraction(result)
            record["normalizations"] = quote_changes + rule_changes
            # Kept in the saved format for backwards compatibility. Character
            # ratios and Latin-token heuristics are no longer a workflow gate.
            record["quality_warnings"] = []
            record.update(status="NEEDS_REVIEW", output=result.model_dump(), missing_fields=missing_fields(result), review_reasons=review_reasons(result), message="格式與引句檢查通過，內容仍需人工核對。")
            try:
                record["retrieval"] = retrieve(message, result.model_dump())
            except Exception:
                record["retrieval"] = {
                    "status": "ERROR", "reason": "知識檢索未完成；抽取結果仍可人工核對，但不可產生有公司事實的回答。",
                    "hits": [], "excluded_hits": [],
                }
            record["decision"] = decide(result, record["retrieval"])
            if record["decision"]["human_in_loop"]["mode"] == "BLOCKED":
                record.update(status="BLOCKED", missing_fields=[], review_reasons=[], message="已直接阻擋，不需人工處理。")
            record["draft_preview"] = preview_draft(
                message, result.model_dump(), record["retrieval"], record["decision"]
            )
    except (ValidationError, ValueError) as exc:
        # Validation exceptions contain model input. Keep raw_output separately; don't print exception bodies.
        record.update(error_code="VALIDATION", message="欄位格式或原文依據未通過檢查，未建立後續行動。")
    except Exception as exc:
        code, user_message = safe_error(exc)
        record.update(error_code=code, message=user_message, request_id=getattr(exc, "request_id", None))
    finally:
        if own:
            client.close()
        record["latency_ms"] = round((time.monotonic() - started) * 1000)
    cases = [case for filename in ("dev_cases.json", "mixed_language_cases.json", "regression_cases.json", "development_extension_cases.json")
             for case in json.loads((ROOT / "data" / filename).read_text())]
    case = next((c for c in cases if c["input"] == message), None)
    record["case_id"] = case["id"] if case else None
    record["versions"]["dataset"] = case["dataset_version"] if case else None
    record["evaluation"] = None
    if case and record["output"]:
        from .evaluation import score
        record["evaluation"] = score(record["output"], case["expected"])
        record["model_evaluation"] = score(record["model_output"], case["expected"])
    return redact(record, key.strip())


def revalidate_saved_output(record: dict) -> dict:
    """Reprocess a saved raw API response with current local rules, for free."""
    if record.get("error_code") != "VALIDATION" or not record.get("raw_output"):
        raise ValueError("只能重新驗證有原始回傳的格式驗證失敗紀錄。")
    message = record.get("input")
    validate_input(message)
    result = Extraction.model_validate_json(record["raw_output"])
    model_output = result.model_dump()
    result, quote_changes = repair_language_quote_whitespace(result, message)
    validate_evidence(result, message)
    result, rule_changes = normalize_extraction(result)
    updated = dict(record)
    updated["model_output"] = model_output
    updated["normalizations"] = quote_changes + rule_changes
    updated["quality_warnings"] = []
    updated["status"] = "NEEDS_REVIEW"
    updated["error_code"] = None
    updated["output"] = result.model_dump()
    updated["missing_fields"] = missing_fields(result)
    updated["review_reasons"] = review_reasons(result)
    updated["message"] = "已用新版本機規則重新驗證；沒有再次呼叫 API。"
    updated["versions"] = dict(record.get("versions") or {})
    updated["versions"].update(schema=SCHEMA_VERSION, rules=RULES_VERSION, prompt=PROMPT_VERSION)
    updated["revalidated_at"] = datetime.now(timezone.utc).isoformat()
    updated["revalidated_from_error"] = "VALIDATION"
    updated["retrieval"] = retrieve(message, updated["output"])
    updated["decision"] = decide(result, updated["retrieval"])
    if updated["decision"]["human_in_loop"]["mode"] == "BLOCKED":
        updated.update(status="BLOCKED", missing_fields=[], review_reasons=[], message="已直接阻擋，不需人工處理。")
    updated["draft_preview"] = preview_draft(
        message, updated["output"], updated["retrieval"], updated["decision"]
    )
    return updated


def save_run(record, directory=None):
    directory = Path(directory) if directory else ROOT / "outputs" / "runs"
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = directory / f"{uuid.uuid4()}.json"
    with path.open("x", encoding="utf-8") as f:
        import os
        os.chmod(path, 0o600)
        json.dump(redact(record), f, ensure_ascii=False, indent=2)
    return path


def _saved_runs(directory=None):
    """Read valid local run records without accepting arbitrary file paths."""
    directory = Path(directory) if directory else ROOT / "outputs" / "runs"
    if not directory.is_dir():
        return []
    records = []
    for path in directory.glob("*.json"):
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(record, dict) and isinstance(record.get("started_at"), str):
            records.append(record)
    return sorted(records, key=lambda item: item["started_at"], reverse=True)


def load_latest_saved_analysis(directory=None):
    """Restore the newest usable analysis saved by this app; no API call is made."""
    records = list_saved_analyses(limit=1, directory=directory)
    return records[0] if records else None


def list_saved_analyses(limit=10, directory=None):
    """Return recent usable analyses for an explicit, bounded local picker."""
    if limit is not None and (not isinstance(limit, int) or limit < 1):
        raise ValueError("limit 必須是正整數或 None。")
    records = []
    for record in _saved_runs(directory):
        if (
            record.get("mode") == "live_api"
            and record.get("status") in {"NEEDS_REVIEW", "BLOCKED"}
            and isinstance(record.get("input"), str)
            and isinstance(record.get("output"), dict)
            and isinstance(record.get("run_id"), str)
        ):
            records.append(record)
            if limit is not None and len(records) >= limit:
                break
    return records


def draft_matches_analysis(draft, analysis):
    """Only the exact analyzed run and context may supply its current API draft."""
    if not isinstance(draft, dict) or not isinstance(analysis, dict):
        return False
    payload = draft.get("input") or {}
    expected_sources = [
        {"citation": h["citation"], "title": h["title"], "chunk_title": h["chunk_title"], "content": h["excerpt"]}
        for h in (analysis.get("retrieval") or {}).get("hits", [])
    ]
    return (
        draft.get("source_analysis_run_id") == analysis.get("run_id")
        and bool(analysis.get("run_id"))
        and draft.get("versions", {}).get("prompt") == DRAFT_PROMPT_VERSION
        and payload.get("customer_inquiry") == analysis.get("input")
        and payload.get("extraction") == analysis.get("output")
        and payload.get("decision") == analysis.get("decision")
        and payload.get("knowledge_sources") == expected_sources
    )


def load_latest_saved_draft(inquiry, directory=None, *, analysis_record=None):
    """Restore a previously paid draft for this exact inquiry; no API call is made."""
    for record in _saved_runs(directory):
        payload = record.get("input")
        if (
            record.get("mode") == "live_api_draft"
            and record.get("status") == "PENDING_HUMAN_REVIEW"
            and isinstance(payload, dict)
            and payload.get("customer_inquiry") == inquiry
            and isinstance(record.get("output"), dict)
        ):
            if analysis_record is None or draft_matches_analysis(record, analysis_record):
                return record
    return None


def generate_response_draft(message, extraction, retrieval, decision, key, model=DEFAULT_MODEL, client=None, *, source_analysis_run_id=None):
    """Generate one grounded draft in one explicit API call, without retries."""
    if decision.get("external_draft_blocked"):
        raise ValueError("此詢問有安全風險標記，不能產生對外草稿。")
    if not key.strip():
        raise ValueError("請先設定 API 金鑰。")
    allowed_citations = [hit["citation"] for hit in retrieval.get("hits", [])]
    payload = {
        "customer_inquiry": message,
        "extraction": extraction,
        "decision": decision,
        "reply_language": decision.get("reply_language") or (extraction.get("language") if extraction.get("language") in {"zh-TW", "en", "ja"} else "zh-TW"),
        "knowledge_sources": [
            {"citation": hit["citation"], "title": hit["title"], "chunk_title": hit["chunk_title"], "content": hit["excerpt"]}
            for hit in retrieval.get("hits", [])
        ],
    }
    started = time.monotonic()
    record = {
        "run_id": str(uuid.uuid4()), "started_at": datetime.now(timezone.utc).isoformat(),
        "mode": "live_api_draft", "status": "FAILED", "requested_model": model,
        "versions": {"app": "day5-0.1", "prompt": DRAFT_PROMPT_VERSION,
                     "decision_rules": decision.get("rules_version"),
                     "knowledge": retrieval.get("knowledge_version")},
        "parameters": {"max_output_tokens": DRAFT_MAX_OUTPUT_TOKENS, "max_retries": 0, "store": False},
        "input": payload, "prompt": DRAFT_PROMPT, "output": None, "usage": None, "request_id": None,
        "error_code": None, "message": None,
    }
    record["source_analysis_run_id"] = source_analysis_run_id
    own = client is None
    client = client or client_for(key.strip())
    try:
        response = client.responses.create(
            model=model, store=False, max_output_tokens=DRAFT_MAX_OUTPUT_TOKENS,
            instructions=DRAFT_PROMPT,
            input=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
            text={"format": {"type": "json_schema", "name": "inquiry_reply_draft", "strict": True,
                             "schema": DraftPackage.model_json_schema()}},
        )
        record["request_id"] = getattr(response, "_request_id", None)
        record["response_id"] = response.id
        record["returned_model"] = response.model
        record["usage"] = response.usage.model_dump() if response.usage else None
        record["response_status"] = response.status
        record["raw_output"] = response.output_text
        refusal = any(getattr(c, "type", None) == "refusal" for item in response.output for c in getattr(item, "content", []))
        if refusal:
            record.update(error_code="REFUSAL", message="模型未提供草稿，請由人工處理。")
        elif response.status != "completed":
            record.update(error_code="INCOMPLETE", message="草稿回傳不完整，未保存為可審核版本。")
        else:
            draft = DraftPackage.model_validate_json(response.output_text)
            if draft.reply_language != payload["reply_language"]:
                raise ValueError("回覆語言與已核對的主要語言不一致")
            if not set(draft.source_citations) <= set(allowed_citations):
                raise ValueError("草稿引用了本次檢索未提供的來源")
            record.update(status="PENDING_HUMAN_REVIEW", output=draft.model_dump(),
                          message="草稿已建立，尚未核准或寄出。")
    except (ValidationError, ValueError):
        record.update(error_code="VALIDATION", message="草稿格式、語言或來源引用未通過檢查，未建立可核准草稿。")
    except Exception as exc:
        code, user_message = safe_error(exc)
        record.update(error_code=code, message=user_message, request_id=getattr(exc, "request_id", None))
    finally:
        if own:
            client.close()
        record["latency_ms"] = round((time.monotonic() - started) * 1000)
    return redact(record, key.strip())
